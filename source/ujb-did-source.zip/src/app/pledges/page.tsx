import DidNavigation from '../did-navigation';
import PledgeDashboard from './dashboard';
import './pledges.css';
export default function PledgePage(){return <><DidNavigation active="pledges"/><div className="pledge-surface"><PledgeDashboard/></div></>;}
