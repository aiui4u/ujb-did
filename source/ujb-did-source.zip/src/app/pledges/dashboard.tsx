'use client';
import PageHeading from '../page-heading';
import {useEffect,useState} from 'react';
import {allPlans,defaultPlan,type ProjectPlan} from '../../lib/pledges/plan-model';
import {annualBudget,firstTargetYear,matchesPlan,years,type PlanFilter} from '../../lib/pledges/dashboard-model';
import {openProjectWindow,projectWindowUrl} from '../../lib/pledges/project-windows';
import pledges from '../../lib/pledges/pledges.json';
import {ChevronRight,Maximize,Minimize,ArrowUpRight,Building2} from 'lucide-react';
const departments=[...new Set(pledges.map(p=>p.dept))].sort();
const number=(n:number)=>n.toLocaleString('ko-KR',{maximumFractionDigits:3});
export default function PledgeDashboard(){
 const [year,setYear]=useState(2026),[plans]=useState<ProjectPlan[]>(allPlans()),[did,setDid]=useState(false),[clock,setClock]=useState(''),[popupFallback,setPopupFallback]=useState('');
 useEffect(()=>{const tick=()=>setClock(new Date().toLocaleString('ko-KR',{timeZone:'Asia/Seoul',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}));const start=setTimeout(tick,0),timer=setInterval(tick,1000);return()=>{clearTimeout(start);clearInterval(timer)}},[]);
 useEffect(()=>{const change=()=>setDid(Boolean(document.fullscreenElement));document.addEventListener('fullscreenchange',change);return()=>document.removeEventListener('fullscreenchange',change)},[]);
 const rows=[...pledges].sort((a,b)=>a.id-b.id).map(p=>({...p,plan:plans.find(x=>x.id===p.id)??defaultPlan(p.id)}));
 const count=(value:PlanFilter)=>rows.filter(p=>matchesPlan(p.plan,value,year)).length;
 const yearly=years.map(y=>({year:y,count:rows.filter(p=>firstTargetYear(p.plan)===y).length}));
 const targetCount=yearly.find(y=>y.year===year)!.count,budget=annualBudget(plans,year);
 const depts=departments.map(d=>({name:d,count:rows.filter(p=>p.dept===d).length})).sort((a,b)=>b.count-a.count||a.name.localeCompare(b.name,'ko')).slice(0,10);
 function launch(url:string){setPopupFallback(openProjectWindow(url)?'':url);}
 function show(value:PlanFilter,department?:string){launch(projectWindowUrl({filter:value,year,dept:department}));}
 async function fullscreen(){try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen()}catch{setDid(!did)}}
 function counter(value:PlanFilter,label=value){return <button className="counter-value" onClick={()=>show(value)} aria-label={`${label} ${count(value)}건 사업 새 창으로 보기`}><span>{label}</span><strong>{count(value)}<small>건</small></strong></button>}
 return <div className={did?'app did plan-app':'app plan-app'}>
 <PageHeading title="의정부시 공약사항"><div className="headright"><span className="clock">{clock}</span><button onClick={fullscreen}>{did?<Minimize size={17}/>:<Maximize size={17}/>} {did?'DID 종료':'DID 전체화면'}</button></div></PageHeading>
 <main><p className="source-caption">첨부 실천계획서 1~{rows.length}번 기준 · {departments.length}개 주관부서</p>

 {popupFallback&&<div className="popup-notice" role="status">새 창이 차단된 경우 <a href={popupFallback} target="_blank" rel="noopener noreferrer">사업 현황 열기</a>를 눌러 주세요.<button onClick={()=>setPopupFallback('')}>닫기</button></div>}
 <section className="plan-counters" aria-label="공약사업 분류별 카운터"><button className="total-counter" onClick={()=>show('all')}><span>전체 공약사업 <ArrowUpRight size={18}/></span><strong>{rows.length}<small>건</small></strong><small>사업번호순</small></button><article><h2>완료시기</h2><div>{counter('임기 내')}{counter('임기 후')}</div></article><article><h2>추진구분</h2><div>{counter('신규')}{counter('계속')}</div></article><article><h2>예산구분</h2><div>{counter('예산')}{counter('비예산')}</div></article></section>
 <div className="plan-yearbar"><div><b>계획 기준 연도</b><span>연도를 선택하면 목표 달성 계획과 예산이 함께 변경됩니다.</span></div><div role="group" aria-label="계획 연도 선택">{years.map(y=><button key={y} aria-pressed={year===y} className={year===y?'active':''} onClick={()=>setYear(y)}>{y}년</button>)}</div></div>
<section className="plan-main-grid"><article className="panel target-panel"><div className="panel-title"><h2>연도별 공약목표 100% 달성 계획</h2><span>최초 도달연도 기준</span></div><button className="target-total" onClick={()=>show('year')} aria-label={`${year}년 목표 달성 예정 ${targetCount}건 사업 보기`}><span>{year}년 목표 달성 예정</span><strong>{targetCount}<small>건</small></strong><b>해당 사업 보기 <ChevronRight size={17}/></b></button><div className="target-bars">{yearly.map(y=><button key={y.year} className={year===y.year?'active':''} onClick={()=>{setYear(y.year);launch(projectWindowUrl({filter:'year',year:y.year}))}} aria-label={`${y.year}년 선택, ${y.count}건`}><strong>{y.count}<small>건</small></strong><div><i style={{height:`${Math.max(3,y.count/Math.max(...yearly.map(a=>a.count),1)*100)}%`}}/></div><span>{y.year}년</span></button>)}</div><p className="plan-footnote">계획서상 최초 100% 도달연도 기준 · 다년도 통합 목표 제외</p></article>
 <article className="panel budget-panel"><div className="panel-title"><h2>{year}년 소요예산 계획</h2><span>단위: 백만 원</span></div><div className="budget-total"><span>연도별 총 소요예산</span><strong>{number(budget.total)}<small>백만 원</small></strong></div><div className="budget-splits">{([['national','국비'],['provincial','도비'],['municipal','시비 부담'],['other','기타 재원']] as const).map(([key,label])=><button key={key} className={`budget-fund-button ${key}`} onClick={()=>launch(projectWindowUrl({year,funding:key}))} aria-label={`${year}년 ${label} ${number(budget[key])}백만 원 사업 새 창으로 보기`}><span>{label} <ArrowUpRight size={13}/></span><strong>{number(budget[key])}</strong><small>백만 원 · 사업목록 보기</small></button>)}</div><div className="funding-track" aria-label="재원별 예산 구성">{(['national','provincial','municipal','other'] as const).map(key=><i key={key} className={key} style={{width:`${(budget.national+budget.provincial+budget.municipal+budget.other)?budget[key]/(budget.national+budget.provincial+budget.municipal+budget.other)*100:0}%`}}/>)}</div><p className="plan-footnote">원문 계획액 기준 · 연도별 구분 예산만 합산 · 다년도 통합·공통 예산 제외{budget.groupedCount>0&&` 선택 연도에 기간 통합 작성 계획 ${budget.groupedCount}건이 있습니다.`}</p></article></section>
  <section className="panel dept-summary"><div className="panel-title"><h2>주관부서별 공약 규모</h2><div className="department-actions"><span>상위 10개 부서</span><button onClick={()=>launch(projectWindowUrl({view:'departments',year}))}><Building2 size={16}/>전체 부서 <ArrowUpRight size={15}/></button></div></div><div className="dept-bars dept-summary-grid">{depts.map(d=><button key={d.name} onClick={()=>show('all',d.name)} aria-label={`${d.name} ${d.count}건 사업 새 창으로 보기`}><span>{d.name}</span><div className="track"><i style={{width:`${d.count/Math.max(...depts.map(x=>x.count),1)*100}%`}}/></div><b>{d.count}<small>건</small></b></button>)}</div></section>
 <footer><span>의정부시 · 민선9기 공약 실천계획</span><span>첨부 계획서 {rows.length}건 · 원문 사업번호 기준</span></footer></main></div>
}
