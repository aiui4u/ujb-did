import type {ReactNode} from 'react';
export default function PageHeading({title,children}:{title:string;children?:ReactNode}){
 return <header className="did-page-heading"><h1>{title}</h1>{children&&<div className="did-heading-actions">{children}</div>}</header>;
}
