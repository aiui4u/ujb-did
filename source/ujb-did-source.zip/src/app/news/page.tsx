import DidNavigation from '../did-navigation';
import NewsDashboard from '../news-dashboard';
export const dynamic = 'force-dynamic';
export default function Page() { return <><DidNavigation active="news"/><NewsDashboard/></>; }
