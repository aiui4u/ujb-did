'use client';
import { useEffect, useState } from 'react';
import { ArrowUpRight, Newspaper } from 'lucide-react';
import { currentNews, newsTime, useNews } from './news-provider';
export default function NewsTicker({rotate=true}:{rotate?:boolean}={}) {
  const { data } = useNews();
  const [step, setStep] = useState(0), [now, setNow] = useState(0), [paused, setPaused] = useState(false);
  useEffect(() => { setNow(Date.now()); const timer = setInterval(() => { setNow(Date.now()); if (rotate && !paused) setStep(i => i + 1); }, 10000); return () => clearInterval(timer); }, [paused,rotate]);
  const delayed = !!data.error || !!(now && data.collectedAt && now - Date.parse(data.collectedAt) > 75 * 60000);
  const articles = currentNews(data, now), article = articles[rotate ? step % (articles.length || 1) : 0];
  return <aside className="news-ticker" aria-label="의정부시 최신뉴스" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)} onFocus={() => setPaused(true)} onBlur={() => setPaused(false)}>
    <a className="news-ticker-label" href="/ujb-did/news"><Newspaper size={19}/>의정부시 최신뉴스</a>
    <a className="news-ticker-title" href={article?.url ?? "/ujb-did/news"} target={article ? "_blank" : undefined} rel="noopener noreferrer">{article?.title ?? (data.pending ? '최신 뉴스를 수집하고 있습니다.' : data.error ? '뉴스 연결 확인 중 · 마지막 수집 시각을 확인해 주세요.' : '최근 7일간 수집된 뉴스가 없습니다.')}</a>
    <span className="news-ticker-meta">{article ? `${article.source} · ${newsTime(article.publishedAt, true)}` : ''}{delayed && <small>갱신 지연</small>}</span>
    <a className="news-ticker-more" href="/ujb-did/news" aria-label="뉴스 전체 보기"><ArrowUpRight size={20}/></a>
  </aside>;
}
