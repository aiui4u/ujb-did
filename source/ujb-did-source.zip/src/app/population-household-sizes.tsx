import {readJSON as fetch} from '@/json-api';
'use client';
import {useEffect,useState} from 'react';
import {House,RefreshCw} from 'lucide-react';
import {POP_REGIONS} from '@/lib/population';
import type {HouseholdSizeData,HouseholdSizeRow} from '@/lib/household-sizes';
const fmt=(n:number)=>n.toLocaleString('ko-KR');
export default function PopulationHouseholdSizes({id,month,onSelect,onData}:{id:string;month:string;onSelect:(id:string)=>void;onData?:(data:HouseholdSizeData|null)=>void}){
 const [data,setData]=useState<HouseholdSizeData|null>(null),[loading,setLoading]=useState(true),[error,setError]=useState(''),[retry,setRetry]=useState(0);
 useEffect(()=>{let live=true;const controller=new AbortController();setData(null);onData?.(null);setError('');setLoading(true);
 const load=async()=>{try{const r=await fetch(`/api/population/household-sizes?month=${month}`,{cache:'no-store',signal:controller.signal});if(!r.ok)throw Error('세대원수별 자료 조회 지연');const next=await r.json() as HouseholdSizeData;if(next.month!==month||!Array.isArray(next.regions))throw Error('기준월 응답 확인 필요');if(live){setData(next);onData?.(next);setError(next.error??'');}}catch(e){if(live)setError(e instanceof Error&&e.name!=='AbortError'?'세대원수별 자료 연결이 지연되고 있습니다. 잠시 후 다시 조회해 주세요.':'');}finally{if(live)setLoading(false);}};
 void load();const timer=setInterval(()=>{if(document.visibilityState==='visible')void load();},3600000);return()=>{live=false;controller.abort();clearInterval(timer);};},[month,retry,onData]);
 const row=data?.regions.find(r=>r.id===id),name=POP_REGIONS.find(r=>r.id===id)?.name??'선택 지역';const share=(n:number,total:number)=>total?(n/total*100).toFixed(1):'0.0';
 const groups=row?[...row.sizes.slice(0,3).map((count,i)=>({label:`${i+1}인세대`,count})),{label:'4인 이상',count:row.sizes.slice(3).reduce((a,b)=>a+b,0)}]:[];
 return <section className="panel household-sizes" aria-labelledby="household-sizes-title" aria-busy={loading}>
 <div className="section-heading"><h2 id="household-sizes-title"><House size={21}/>세대원수별 주민등록 세대 현황</h2><button className="pop-text-button" disabled={loading} onClick={()=>setRetry(v=>v+1)}><RefreshCw size={14}/> 다시 조회</button></div>
 <p className="pop-caption">{month.slice(0,4)}년 {Number(month.slice(4))}월 · {name}</p>
 {error&&<p className="pop-status" role="status">{error}{data?.stale?' 같은 기준월의 최근 정상 자료를 표시합니다.':''}</p>}
 {row?<><div className="household-size-metrics">{[{label:'전체 세대',value:fmt(row.total),unit:'세대'},{label:'1인세대',value:fmt(row.sizes[0]),unit:'세대'},{label:'1인세대 비율',value:share(row.sizes[0],row.total),unit:'%'},{label:'2인세대',value:fmt(row.sizes[1]),unit:'세대'}].map(v=><article key={v.label}><span>{v.label}</span><strong>{v.value}<small>{v.unit}</small></strong></article>)}</div>
 <div className="household-size-columns"><div><h3>세대 규모별 구성</h3>{groups.map(g=><div className="household-size-bar" key={g.label}><span>{g.label}</span><div><i style={{width:`${share(g.count,row.total)}%`}}/></div><b>{fmt(g.count)}<small>세대 · {share(g.count,row.total)}%</small></b></div>)}<h3>1인~10인 이상 세대수</h3><HouseholdSizeBreakdown row={row}/></div>
 <div><h3>동별 1인세대 현황</h3><HouseholdDongChart rows={data!.regions} selected={id} onSelect={onSelect}/></div></div></>:<p className="pop-empty">{loading?'선택한 기준월의 세대원수별 자료를 불러오고 있습니다.':error?'확인된 자료를 수신하면 현황을 표시합니다.':'선택한 기준월의 자료가 없습니다.'}</p>}
 <p className="pop-caption">주민등록상 세대 기준이며 통계청의 ‘1인가구’와 다릅니다. 1인세대 비율 = 1인세대 ÷ 전체 세대 × 100. 통·반 소계는 동 총계와 중복 합산하지 않습니다.</p>
 <footer className="pop-footer"><a href="https://www.data.go.kr/data/15108081/openapi.do" target="_blank" rel="noreferrer">출처: 행정안전부 세대원수별 주민등록 세대수</a><span>월말 통계{data?.savedAt?` · 수집 ${new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',dateStyle:'short',timeStyle:'short'}).format(new Date(data.savedAt))}`:''}</span></footer>
 </section>;
}

export function HouseholdSizeBreakdown({row}:{row:HouseholdSizeRow}){
 return <div className="household-size-all">{row.sizes.map((v,i)=><p key={i}><span>{i===9?'10인 이상':`${i+1}인`}세대</span><b>{fmt(v)}세대</b></p>)}</div>;
}
export function HouseholdDongChart({rows,selected,onSelect}:{rows:HouseholdSizeRow[];selected:string;onSelect:(id:string)=>void}){
 const dongs=rows.filter(r=>r.id!=='city').slice().sort((a,b)=>b.sizes[0]-a.sizes[0]);
 const max=Math.max(1,...dongs.map(r=>r.sizes[0]));
 return <div className="household-dong-chart" aria-label="동별 1인세대 수 비교 그래프"><p className="household-chart-caption">1인세대 수가 많은 순 · 막대는 세대수, 비율은 해당 동 전체 세대 대비</p><div className="household-chart-head"><span>행정동</span><span>1인세대 수</span><span>동 내 비율</span></div>{dongs.map(r=><button key={r.id} className={`household-dong-row${selected===r.id?' is-selected':''}`} aria-pressed={selected===r.id} aria-label={`${r.name}, 1인세대 ${fmt(r.sizes[0])}세대, 비율 ${r.total?(r.sizes[0]/r.total*100).toFixed(1):'0.0'}%`} onClick={()=>onSelect(r.id)}><span>{r.name}</span><span className="household-dong-track"><i aria-hidden="true" style={{width:`${r.sizes[0]/max*100}%`}}/><b>{fmt(r.sizes[0])}<small>세대</small></b></span><strong>{r.total?(r.sizes[0]/r.total*100).toFixed(1):'0.0'}<small>%</small></strong></button>)}</div>;
}

export function HouseholdDongSizeTable({rows,selected,onSelect}:{rows:HouseholdSizeRow[];selected:string;onSelect:(id:string)=>void}){
 const labels=Array.from({length:10},(_,i)=>i===9?'10인 이상':`${i+1}인세대`);
 return <><p className="pop-caption">단위: 세대, % · 위: 세대수 / 아래: 지역 전체 대비 비율</p>
 <div className="household-dong-size-overview" role="region" aria-label="동별 1인부터 10인 이상 세대수와 비율 상세표">
 <table className="household-dong-size-table"><caption className="sr-only">의정부시 전체 및 동별 세대원수별 세대수와 구성비</caption><thead><tr><th scope="col">행정동</th><th scope="col">전체 세대</th>{labels.map(label=><th scope="col" key={label}>{label}</th>)}</tr></thead><tbody>{rows.map(r=><tr key={r.id} className={selected===r.id?'pop-table-selected':''}><th scope="row"><button onClick={()=>onSelect(r.id)}>{r.name}</button></th><td><b>{fmt(r.total)}</b><small>{r.total?'100.0':'0.0'}%</small></td>{labels.map((label,i)=><td key={label}><b>{fmt(r.sizes[i])}</b><small>{r.total?(r.sizes[i]/r.total*100).toFixed(1):'0.0'}%</small></td>)}</tr>)}</tbody></table></div></>;
}
