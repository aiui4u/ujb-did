import DidNavigation from '../did-navigation';
import ComplaintDashboard from '../complaint-dashboard';
export default function Page(){return <><DidNavigation active="complaints"/><ComplaintDashboard/></>;}
