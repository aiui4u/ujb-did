import {readJSON as fetch} from '@/json-api';
'use client';
import {useRetryPoll} from './use-retry-poll';
import {WARNING_INTERVAL} from '@/lib/refresh-policy';
import {useCallback,useEffect,useRef,useState} from 'react';
import {AlertTriangle} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {Sheet,SheetContent,SheetHeader,SheetTitle,SheetDescription} from '@/components/ui/sheet';
import {Table,TableHeader,TableHead,TableRow,TableBody,TableCell} from '@/components/ui/table';
import {warningCounts,type WarningSnapshot} from '@/lib/warnings';
const time=(s:string|null|undefined)=>s?new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(s)):'확인 중';
export default function WarningPanel({initial,onUpdate}:{initial:WarningSnapshot|undefined;onUpdate?:(data:WarningSnapshot)=>void}){
 const nextCheck=useRef(0),busy=useRef(false);
 const [data,setData]=useState<WarningSnapshot|null>(initial??null),[open,setOpen]=useState(false);
 useEffect(()=>{if(initial)setData(old=>!old?.collectedAt||!initial.collectedAt||initial.collectedAt>=old.collectedAt?initial:old);},[initial]);
 const refresh=useCallback(async()=>{if(busy.current)return;busy.current=true;nextCheck.current=Date.now()+WARNING_INTERVAL;try{const r=await fetch('/api/warnings',{cache:'no-store',signal:AbortSignal.timeout(15000)});if(!r.ok)return;const next=await r.json() as WarningSnapshot;if(Array.isArray(next.cities)){nextCheck.current=Math.max(Date.now()+10000,next.nextCheckAt??Date.now()+WARNING_INTERVAL);setData(next);onUpdate?.(next);}}catch{/* Keep the last DB status visible. */}finally{busy.current=false;}},[onUpdate]);
 useEffect(()=>{
  if(!nextCheck.current||!initial||initial.pending)void refresh();
  let stopped=false,timer:ReturnType<typeof setTimeout>;
  function next(){if(stopped)return;timer=setTimeout(async()=>{if(document.visibilityState==='visible')await refresh();else nextCheck.current=Date.now()+WARNING_INTERVAL;next();},Math.max(1000,nextCheck.current-Date.now()||WARNING_INTERVAL));}
  next();const visible=()=>{if(document.visibilityState==='visible'&&Date.now()>=nextCheck.current)void refresh();};
  document.addEventListener('visibilitychange',visible);return()=>{stopped=true;clearTimeout(timer);document.removeEventListener('visibilitychange',visible);};
 },[refresh]);
 useRetryPoll(!data?.verified||Boolean(data?.pending)||Boolean(data?.error),refresh);
 const counts=warningCounts(data);const stale=data?.collectedAt?Date.now()-Date.parse(data.collectedAt)>2*3600000:false;
 return <><section className="panel warnings-panel"><div className="section-heading"><h2><AlertTriangle size={19}/> 경기도 기상특보</h2><Button variant="ghost" className="detail-link" onClick={()=>setOpen(true)}>31개 시군 현황</Button></div><div className="warning-summary">{[{label:'특보 발효 시군',value:counts?.activeCities,unit:'/ 31'},{label:'주의보',value:counts?.advisories,unit:'건'},{label:'경보',value:counts?.warnings,unit:'건'},{label:'예비특보 시군',value:counts?.preliminaryCities,unit:'곳'}].map(x=><Button variant="ghost" className="warning-count" key={x.label} onClick={()=>setOpen(true)}><span>{x.label}</span><strong>{x.value??'—'}<small>{x.unit}</small></strong></Button>)}</div><p className="warning-status">{data?.error??(stale?'저장 자료 지연':data?.pending?'새 특보 자료 수집 중':data?.verified?'기상청 공식 특보 · DB 저장 현황':'특보 현황 확인 중')} · 저장 {time(data?.collectedAt)}</p><p className="warning-footnote">30분 간격 확인 · 주의보·경보 건수는 시군·종류별 집계 · 세분 구역은 해당 시군에 포함</p></section><Sheet open={open} onOpenChange={setOpen}><SheetContent className="details expanded-details warning-details"><SheetHeader><SheetTitle>경기도 31개 시군 기상특보 현황</SheetTitle><SheetDescription>발표 {time(data?.issuedAt)} · 발효현황 {time(data?.effectiveAt)} · DB 확인 {time(data?.collectedAt)}</SheetDescription></SheetHeader><div className="detail-body"><p>{data?.error??(data?.verified?'기상청의 특보 발효현황과 예비특보를 구분해 표시합니다.':'공식 특보 자료를 확인 중입니다. 미확인 상태는 특보 없음으로 판단하지 않습니다.')}</p><Table><TableHeader><TableRow><TableHead>시군</TableHead><TableHead>발효 중인 특보</TableHead><TableHead>적용 구역</TableHead><TableHead>예비특보·예상 시각</TableHead></TableRow></TableHeader><TableBody>{data?.cities.map(city=><TableRow className={city.name==='의정부시'?'uijeongbu-warning-row':''} key={city.name}><TableCell>{city.name}</TableCell><TableCell>{!data.verified?'확인 중':city.active.length?city.active.map((a,i)=><div key={i} className={`warning-tag ${a.level==='주의보'?'advisory':'alert'}`}>{a.kind} {a.level}</div>):'없음'}</TableCell><TableCell>{city.active.length?[...new Set(city.active.flatMap(a=>a.areas))].join(', '):data.verified?'—':'확인 중'}</TableCell><TableCell>{!data.verified?'확인 중':city.preliminary.length?city.preliminary.map((a,i)=><div key={i}>{a.kind} 예비특보<br/><small>{a.areas.join(', ')}{a.timing?` · ${a.timing}`:''}</small></div>):'없음'}</TableCell></TableRow>)}</TableBody></Table><p>한 시군의 여러 세분 구역에 같은 종류·강도의 특보가 있으면 1건으로 집계합니다. 주의보와 경보가 서로 다른 구역에 있으면 각각 집계합니다. 해상 특보는 육상 31개 시군 집계에서 제외합니다.</p>{data?.parseNotes.map((n,i)=><p key={i}>{n}</p>)}{data?.notes&&<p>기상청 참고사항: {data.notes}</p>}<a href="https://www.weather.go.kr/w/special-report/overall.do" target="_blank" rel="noreferrer">기상청 공식 특보 확인</a></div></SheetContent></Sheet></>;
}
