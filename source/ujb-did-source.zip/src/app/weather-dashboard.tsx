import {readJSON as fetch} from '@/json-api';
'use client';
import PageHeading from './page-heading';
import {useRetryPoll} from './use-retry-poll';
import {useCallback,useEffect,useRef,useState} from 'react';
import {Cloud,CloudSun,Sun,CloudRain,Snowflake,Wind,Droplets,Thermometer,MapPin,Maximize,Minimize,RefreshCw,Info,ShieldCheck,Clock,Radio,AlertTriangle,Activity} from 'lucide-react';
import {Button} from '@/components/ui/button';

import {REGIONS,DEFAULT_REGION,findRegion} from '@/lib/regions';
import {Sheet,SheetContent,SheetHeader,SheetTitle,SheetDescription,SheetTrigger} from '@/components/ui/sheet';
import WeatherDetails from './weather-details';
import WarningPanel from './warning-panel';
import {metricValue,airGrade,gradeLabel} from '@/lib/air';
import {condition,kst,number,stamp,type WeatherData,type Values} from '@/lib/weather';
import {unpackSnapshots,type SnapshotPacket} from '@/lib/snapshot-packet';
import {analyzeLife} from '@/lib/life-analysis';
import type {WarningSnapshot} from '@/lib/warnings';
const fmt=(date:string|null|undefined,full=false)=>{if(!date)return '자료 대기';if(date.includes('시 발표'))return date;const raw=/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(date)?date.replace(' ','T')+':00+09:00':date;const d=new Date(raw);if(!Number.isFinite(d.getTime()))return date;return new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',...(full?{month:'numeric',day:'numeric'}:{}),hour:'2-digit',minute:'2-digit',hour12:false}).format(d);};
const val=(v:unknown,unit='')=>number(v)===null?'—':`${v}${unit}`;
function WeatherIcon({values,className=''}:{values:Values;className?:string}){const p=number(values.PTY),sky=number(values.SKY);const Icon=p&&p!==0?(p===3||p===7?Snowflake:CloudRain):sky===1?Sun:sky===3?CloudSun:Cloud;return <Icon className={className} strokeWidth={1.5}/>;}
function direction(v:unknown){const n=number(v);return n===null?'—':['북','북북동','북동','동북동','동','동남동','남동','남남동','남','남남서','남서','서남서','서','서북서','북서','북북서'][Math.round(n/22.5)%16];}
function grade(v:unknown){return ({'1':'좋음','2':'보통','3':'나쁨','4':'매우 나쁨'} as Record<string,string>)[String(v)]??'등급 대기';}
export default function WeatherDashboard({initialPacket,initialRegion,initialTime}:{initialPacket:SnapshotPacket;initialRegion:string;initialTime:string}){
 const [initialSnapshots]=useState(()=>unpackSnapshots(initialPacket));const initialData=initialSnapshots[initialRegion]??null;
 const [data,setData]=useState<WeatherData|null>(initialData),[selectedRegion,setSelectedRegion]=useState<string>('city'),[now,setNow]=useState<Date|null>(new Date(initialTime)),[loading,setLoading]=useState(!initialData),[error,setError]=useState(''),[collectionPending,setCollectionPending]=useState(Boolean(initialData?.collection?.pending||initialData?.collection?.message)),[fullscreen,setFullscreen]=useState(false),[detail,setDetail]=useState<string|null>(null);
 const snapshots=useRef<Record<string,WeatherData>>(initialSnapshots),firstMount=useRef(true),waitingForCollection=useRef(Boolean(initialData?.collection?.pending));
 const controller=useRef<AbortController|null>(null),requestVersion=useRef(0);
 const region=REGIONS[0];
 const prefetchSnapshots=useCallback(async(signal?:AbortSignal)=>{try{const r=await fetch('/api/snapshots',{cache:'no-store',signal:signal?AbortSignal.any([signal,AbortSignal.timeout(15000)]):AbortSignal.timeout(15000)});if(!r.ok)return;const packet=await r.json() as SnapshotPacket;if(!packet.payloads||!packet.regions)return;const incoming=unpackSnapshots(packet);for(const [id,value] of Object.entries(incoming)){const existing=snapshots.current[id];if(!existing||Date.parse(value.storage?.savedAt??value.fetchedAt)>=Date.parse(existing.storage?.savedAt??existing.fetchedAt))snapshots.current[id]=value;}}catch{/* Per-dong DB refresh remains available. */}},[]);
 const updateWarnings=useCallback((warnings:WarningSnapshot)=>{const time=new Date();for(const [id,value] of Object.entries(snapshots.current))snapshots.current[id]=analyzeLife({...value,warnings},time);setData(old=>old?analyzeLife({...old,warnings},time):old);},[]);
 const refresh=useCallback(async()=>{
  controller.current?.abort();const abort=new AbortController();controller.current=abort;const version=++requestVersion.current;
  setLoading(true);
  try{const r=await fetch(`/api/weather?dong=${encodeURIComponent(selectedRegion)}`,{cache:'no-store',signal:AbortSignal.any([abort.signal,AbortSignal.timeout(10000)])});const raw=await r.text();let json:any;try{json=JSON.parse(raw);}catch{throw new Error('자료 연결을 확인하고 있습니다. 잠시 후 자동으로 다시 확인합니다.');}if(r.status===202&&json.pending){if(version===requestVersion.current){setCollectionPending(true);setError('');}return;}if(!r.ok||!json.sources)throw new Error(json.error??'자료 연결 확인 중');if(version!==requestVersion.current)return;snapshots.current[selectedRegion]=json;if(json.collection?.pending)waitingForCollection.current=true;else if(waitingForCollection.current){waitingForCollection.current=false;void prefetchSnapshots();}setData(json);setCollectionPending(Boolean(json.collection?.pending||json.collection?.message));setError('');}
  catch(e){if(version===requestVersion.current&&!abort.signal.aborted)setError(e instanceof Error?e.message:'자료를 불러오지 못했습니다.');}
  finally{if(version===requestVersion.current)setLoading(false);}
 },[selectedRegion,prefetchSnapshots]);
 useRetryPoll(collectionPending||Boolean(error),refresh);
 useEffect(()=>{if(initialData)return;const abort=new AbortController();void prefetchSnapshots(abort.signal);return()=>abort.abort();},[initialData,prefetchSnapshots]);
 useEffect(()=>{
  setNow(new Date());if(!firstMount.current||!initialData)void refresh();firstMount.current=false;
  const hourMs=3600000;
  let lastHourlySlot=Math.floor(Date.now()/hourMs);
  let hourlyTimer:ReturnType<typeof setTimeout>;
  // KST's whole-hour UTC offset makes epoch hour boundaries align with Korea's HH:00.
  function scheduleNextHour(){clearTimeout(hourlyTimer);hourlyTimer=setTimeout(checkHour,hourMs-Date.now()%hourMs);}
  function checkHour(){const slot=Math.floor(Date.now()/hourMs);if(slot>lastHourlySlot){lastHourlySlot=slot;void refresh();}scheduleNextHour();}
  function onVisible(){if(document.visibilityState==='visible'){setNow(new Date());checkHour();}}
  scheduleNextHour();
  const timer=setInterval(()=>setNow(new Date()),1000);
  const fs=()=>setFullscreen(Boolean(document.fullscreenElement));
  document.addEventListener('fullscreenchange',fs);
  document.addEventListener('visibilitychange',onVisible);
  window.addEventListener('focus',checkHour);
  return()=>{clearInterval(timer);clearTimeout(hourlyTimer);controller.current?.abort();requestVersion.current++;document.removeEventListener('fullscreenchange',fs);document.removeEventListener('visibilitychange',onVisible);window.removeEventListener('focus',checkHour);};
 },[refresh]);
 function selectRegion(id:string){if(id===selectedRegion)return;const cached=snapshots.current[id]??null;setData(cached);setError('');setCollectionPending(Boolean(cached?.collection?.pending||cached?.collection?.message));setLoading(!cached);controller.current?.abort();requestVersion.current++;setSelectedRegion(id);const url=new URL(window.location.href);url.searchParams.set('dong',id);window.history.replaceState(null,'',url);}
 const view=data;
 const currentAge=view?.observedAt&&now?(now.getTime()-Date.parse(view.observedAt))/3600000:null;
 const currentValid=currentAge!==null&&currentAge<2;
 const current=view?.current??{};
 const hours=view?.hours.filter(h=>Date.parse(h.at)>=(now?.getTime()??0)).slice(0,12)??[];
 const currentForecast=view?.hours.find(h=>Math.abs(Date.parse(h.at)-(now?.getTime()??0))<3600000);
 const temp=number(current.T1H),wind=number(current.WSD);
 const chill=temp!==null&&wind!==null&&temp<=10&&wind>1.3?Math.round(13.12+0.6215*temp-11.37*(wind*3.6)**0.16+0.3965*temp*(wind*3.6)**0.16):null;
 const temps=hours.map(h=>number(h.values.T1H??h.values.TMP));const realTemps=temps.filter((v):v is number=>v!==null);const low=realTemps.length?Math.min(...realTemps)-2:0,high=realTemps.length?Math.max(...realTemps)+2:10;
 const points=temps.map((t,i)=>t===null?null:`${(i+.5)*1000/Math.max(hours.length,1)},${125-(t-low)/(high-low)*90}`);
 const air=view?.air??null;
 const airDate=air?.dataTime?Date.parse(air.dataTime.replace(' ','T')+'+09:00'):null;
 const airOld=Boolean(airDate&&now&&now.getTime()-airDate>3*3600000);
 const todayDate=now?`${stamp(kst(now)).slice(0,4)}-${stamp(kst(now)).slice(4,6)}-${stamp(kst(now)).slice(6,8)}`:'';
 const todayAir=data?.airForecasts?.filter(f=>f.date===todayDate)??[];
 const highToday=data?.highForecasts?.find(f=>f.date===todayDate);
 const highNext=data?.highForecasts?.find(f=>f.over50===true)??highToday??data?.highForecasts?.[0];
 const showDetail=(topic:string)=><Button variant="ghost" className="detail-link" onClick={()=>setDetail(topic)}>상세보기</Button>;
 async function toggleFull(){try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{setError('전체화면을 열지 못했습니다. 브라우저에서 F11을 눌러 주세요.');}}
 return <main className={`did weather-did ${fullscreen?'in-fullscreen':''}`}>
 <PageHeading title="의정부시 날씨"><div className="header-right"><div className="clock"><strong>{now?new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',hour:'2-digit',minute:'2-digit',hour12:false}).format(now):'—:—'}</strong><span>{now?new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',year:'numeric',month:'long',day:'numeric',weekday:'long'}).format(now):'대한민국 표준시'}</span></div><div className="controls"><Button variant="ghost" size="icon" aria-label="새로고침" title="새로고침" onClick={refresh} disabled={loading}><RefreshCw className={loading?'spin':''}/></Button><Button variant="ghost" size="icon" aria-label={fullscreen?'전체화면 종료':'전체화면'} title="전체화면" onClick={toggleFull}>{fullscreen?<Minimize/>:<Maximize/>}</Button><Sheet><SheetTrigger asChild><Button variant="ghost" size="icon" aria-label="데이터 연결 및 안내 기준" title="데이터 연결 및 안내 기준"><Info/></Button></SheetTrigger><SheetContent className="details"><SheetHeader><SheetTitle>데이터 연결 및 안내 기준</SheetTitle><SheetDescription>자료 제공 범위와 수집 상태를 확인하세요.</SheetDescription></SheetHeader><div className="detail-body"><h3>저장 및 수집 상태</h3><p>DB 저장 {fmt(data?.storage?.savedAt,true)} · 최근 수집 시도 {fmt(data?.collection?.lastStarted,true)}</p><p>{data?.collection?.pending?'새 자료 수집 중 · 마지막 저장 자료 표시':data?.collection?.message??'저장 자료 조회'}</p><h3>자료별 상태</h3>{(['current','ultra','forecast','air','airForecast','high'] as const).map((k,i)=><div className="source" key={k}><strong>{['초단기실황','초단기예보','단기예보','대기질','대기질 예보','고농도 전망'][i]}</strong><span>{data?.sources[k]?.message??'확인 중'}</span><small>{fmt(data?.sources[k]?.base,true)}</small></div>)}<h3>지역 기준</h3><p>{region.name} 대표격자 (X {region.nx} · Y {region.ny}). 기상청의 약 5km 격자를 기준으로 조회합니다. 의정부시청 대표 격자 자료이며, 실제 지역별 날씨에는 차이가 있습니다.</p><h3>대기질 연결</h3><p>의정부시 대표 측정소 자료를 사용하며, 미수신 시 관내 측정소 자료로 대체합니다. 대기질 및 고농도 초미세먼지 예보는 경기북부 권역 기준입니다.</p><p>미세먼지 등급은 제공기관의 1시간 등급을 그대로 표시합니다. 3시간 이상 지난 자료는 지연 표시하고 최신 안내 분석에서 제외합니다.</p><h3>추가 데이터가 필요한 항목</h3><p>기상특보: 경기도 31개 시군 현황 기준</p><h3>수집된 실황 전체</h3><div className="raw-values">{['T1H','RN1','REH','WSD','VEC','PTY','UUU','VVV'].map(k=><div key={k}><span>{k}</span><b>{view?.current[k]??'—'}</b></div>)}</div><p>수집 지연 시 마지막 정상자료 유지 · 측정·발표시각 기준</p><a href="https://www.data.go.kr/data/15073861/openapi.do" target="_blank" rel="noreferrer">에어코리아 활용신청</a><a href="https://www.weather.go.kr/" target="_blank" rel="noreferrer">기상청 날씨누리</a></div></SheetContent></Sheet></div></div></PageHeading>
 <div className="region-bar"><label><MapPin size={20}/> 의정부시</label><span className="region-description">의정부시청 대표 날씨</span><span className="region-grid">대표격자 X {region.nx} · Y {region.ny}</span></div>
 <div className="statusline"><span><MapPin size={16}/> {region.name} 기준</span><span className={!data?.sources.current.ok||error?'waiting':'connected'}><Radio size={16}/>{loading?'저장 자료 확인 중':error?'갱신 지연':data?.sources.current.ok?(currentValid?'기상청 실황 연결':'실황 자료 지연'):'기상자료 연결 확인 중'}</span><span>실황 {fmt(view?.observedAt,true)} · 예보 발표 {fmt(view?.sources.forecast.base,true)}</span><span className="grid-note">DB 저장 자료 · {data?.collection?.pending?'새 자료 수집 중':data?.collection?.message??'저장된 최신 자료 표시'}</span></div>
 <section className="top-grid weather-current-air">
 <div className="panel weather-now"><div className="section-heading"><h2><Thermometer size={19}/> 지금 {region.name}</h2>{showDetail('weather')}</div><div className="current-main"><div><div className="temperature">{val(current.T1H)}<span>°C</span></div><div className="weather-label">{Object.keys(current).length?condition({...current,SKY:currentForecast?.values.SKY??''}):collectionPending&&!data?'처음 수집한 자료 저장 중':loading?'저장 자료 확인 중':'실황 자료 대기'}</div><div className="feels">{chill!==null?`바람을 고려한 체감온도 ${chill}°C (계산)`:'하늘상태는 해당 시간 예보 기준'}</div></div><WeatherIcon values={{...current,SKY:currentForecast?.values.SKY??''}} className="large-weather"/></div><div className="metrics">{[{icon:Droplets,label:'습도',value:val(current.REH,'%')},{icon:Wind,label:'풍속',value:val(current.WSD,' m/s')},{icon:CloudRain,label:'1시간 강수량',value:val(current.RN1,' mm')},{icon:MapPin,label:'풍향',value:direction(current.VEC)}].map(m=><Button variant="ghost" className="weather-metric" key={m.label} onClick={()=>setDetail('weather')} aria-label={`${m.label} 상세정보`}><m.icon size={20}/><span>{m.label}</span><strong>{m.value}</strong></Button>)}</div></div>
 <div className="weather-air-column"><div className="panel air"><div className="section-heading"><h2><Wind size={19}/> 의정부 대기질</h2>{showDetail('air')}</div><div className="air-measured">{air?`${air.dataTime}${airOld?' · 자료 지연':''}`:data?.sources.air.message??'대기질 자료 확인 중'} · {data?.airStation?.name??'생활권 연계 측정소'} 기준{data?.airStation?.fallbackReason?` · ${data.airStation.fallbackReason}`:null}</div><div className="air-numeric-grid">{[
 {name:'미세먼지',code:'pm10',label:'PM10',unit:'㎍/㎥'},
 {name:'초미세먼지',code:'pm25',label:'PM2.5',unit:'㎍/㎥'},
 {name:'오존',code:'o3',label:'O₃',unit:'ppm'},
 {name:'이산화질소',code:'no2',label:'NO₂',unit:'ppm'},
 {name:'일산화탄소',code:'co',label:'CO',unit:'ppm'},
 {name:'아황산가스',code:'so2',label:'SO₂',unit:'ppm'},
 {name:'통합대기환경지수',code:'khai',label:'CAI',unit:'지수'}
].map(a=>{const value=a.code==='khai'?number(air?.khaiValue):metricValue(air,a.code);const g=a.code==='khai'?number(air?.khaiGrade):airGrade(air,a.code);return <Button variant="ghost" className={`air-number-card ${a.code==='khai'?'air-index-card':''}`} key={a.code} onClick={()=>setDetail(a.code)} aria-label={`${a.name} ${value===null?'자료 없음':value+' '+a.unit} 상세정보`}><span className="air-number-label">{a.name} <small>{a.label}</small></span><strong className="air-number-value">{value===null?(loading?'조회 중':'자료 없음'):value}<small>{value!==null?a.unit:''}</small></strong><span className={`grade grade-${g??''}`}>{value===null?(air?.[a.code+'Flag']??'측정자료 없음'):airOld?'자료 지연':gradeLabel(g)}</span></Button>;})}</div><div className="air-forecast-strip"><Button variant="ghost" className="forecast-preview" onClick={()=>setDetail('airForecast')}><span>경기북부 대기질 예보</span><strong>{todayAir.length?todayAir.map(f=>`${f.code==='PM25'?'초미세먼지':f.code==='PM10'?'미세먼지':'오존'} ${f.grade}`).join(' · '):data?.sources.airForecast?.message??'예보 확인 중'}</strong><small>오늘·내일·모레</small></Button><Button variant="ghost" className="forecast-preview high-preview" onClick={()=>setDetail('high')}><span>고농도 초미세먼지 전망</span><strong>{highNext?`${highNext.date.slice(5)} ${highNext.over50===true?'50㎍/㎥ 초과 예상':highNext.over50===false?'50초과 예상 없음':'판정 자료 없음'}`:data?.sources.high?.message??'전망 확인 중'}</strong><small>경기북부 권역</small></Button></div></div>
 </div>
 <section className="panel hourly"><div className="section-heading"><h2><Clock size={19}/> 앞으로 12시간</h2><div className="legend"><span><i className="line-key"/>기온</span><span><i className="bar-key"/>강수확률</span>{showDetail('hourly')}</div></div>{hours.length?<div className="hour-chart"><svg viewBox="0 0 1000 150" preserveAspectRatio="none" aria-hidden="true" className="plot">{[40,85,130].map(y=><line key={y} x1="0" x2="1000" y1={y} y2={y} stroke="#2b3c55" strokeDasharray="3 6"/>)}{hours.map((h,i)=>{const pop=number(h.values.POP);return pop!==null?<rect key={h.at} x={(i+.25)*1000/hours.length} y={140-pop*.8} width={500/hours.length} height={pop*.8} rx="4" fill="#235b88"/>:null;})}{points.slice(1).map((p,i)=>p&&points[i]?<line key={i} x1={points[i]!.split(',')[0]} y1={points[i]!.split(',')[1]} x2={p.split(',')[0]} y2={p.split(',')[1]} stroke="#f2c660" strokeWidth="2.5"/>:null)}{points.map((p,i)=>p?<circle key={i} cx={p.split(',')[0]} cy={p.split(',')[1]} r="4" fill="#f2c660"/>:null)}</svg><div className="hour-columns" style={{gridTemplateColumns:`repeat(${hours.length},minmax(0,1fr))`}}>{hours.map(h=><Button variant="ghost" className="hour-column hour-button" key={h.at} onClick={()=>setDetail('hourly')} aria-label={`${fmt(h.at,true)} 예보 상세`}><span className="hour-time">{new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',hour:'numeric',hour12:false}).format(new Date(h.at))}</span><WeatherIcon values={h.values}/><b>{val(h.values.T1H??h.values.TMP,'°')}</b><div className="plot-space"/><span className="rain-chance">{val(h.values.POP,'%')}</span><small>{h.values.RN1??h.values.PCP??'강수량 대기'}</small></Button>)}</div></div>:<div className="empty-chart"><Cloud size={42}/><strong>{loading?'시간대별 예보를 확인 중입니다':'시간대별 예보 연결 대기'}</strong><span>{data?.sources.forecast.message??'예보가 연결되면 기온·강수확률·강수량을 표시합니다.'}</span></div>}</section>
 </section>
 <div className="weather-secondary-grid">
 <section className="weather-outlook"><div className="outlook-column"><div className="panel outlook"><div className="section-heading"><h2><CloudSun size={19}/> 며칠간의 날씨</h2>{showDetail('daily')}</div><div className="day-list">{(view?.daily.length?view.daily:[null,null,null,null]).slice(0,4).map((d,i)=>{const date=d?new Date(`${d.date.slice(0,4)}-${d.date.slice(4,6)}-${d.date.slice(6,8)}T12:00:00+09:00`):null;return <Button variant="ghost" className="day day-button" key={i} onClick={()=>setDetail('daily')} aria-label="날짜별 날씨 상세"><span>{d&&now&&d.date===stamp(kst(now))?'오늘':d&&now&&d.date===stamp(new Date(kst(now).getTime()+86400000))?'내일':date?new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',weekday:'short'}).format(date):'—'}</span><small>{date?new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',month:'numeric',day:'numeric'}).format(date):'예보 대기'}</small><div className="day-temps"><b>{val(d?.min)}°</b><i>/</i><strong>{val(d?.max)}°</strong></div><small>강수확률 {val(d?.pop,'%')}</small></Button>;})}</div><p className="footnote">최저·최고는 일 예보값 · 강수확률은 시간대별 최댓값</p></div><WarningPanel initial={data?.warnings} onUpdate={updateWarnings}/></div>
</section>
 </div>
 <WeatherDetails topic={detail} onClose={()=>setDetail(null)} data={data} region={region}/>
 </main>;
}
