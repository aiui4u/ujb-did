import {readJSON as fetch} from '@/json-api';
'use client';
import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import type { NewsSnapshot } from '@/lib/news';
const initial: NewsSnapshot = { articles: [], collectedAt: null, lastAttemptAt: null, error: null };
const NewsContext = createContext({ data: initial, busy: false, refresh: async () => {} });
export function NewsProvider({ children, initialData = initial }: { children: React.ReactNode; initialData?: NewsSnapshot }) {
  const [data, setData] = useState(initialData), [busy, setBusy] = useState(false);
  const lastRefresh = useRef(0);
  const inFlight = useRef(false), alive = useRef(false), retry = useRef<ReturnType<typeof setTimeout> | null>(null), attempts = useRef(0);
  const refresh = useCallback(async () => {
    if (inFlight.current) return;
    inFlight.current = true; setBusy(true);
    if (retry.current) { clearTimeout(retry.current); retry.current = null; }
    try {
      const r = await fetch('/api/news', { cache: 'no-store', signal: AbortSignal.timeout(12000) });
      if (!r.ok) throw Error();
      const next = await r.json() as NewsSnapshot;
      if (!Array.isArray(next.articles)) throw Error();
      if (!alive.current) return;
      setData(next); lastRefresh.current = Date.now();
      if (next.pending && attempts.current++ < 12) retry.current = setTimeout(() => { void refresh(); }, 3000);
      else attempts.current = 0;
    } catch { if (alive.current) setData(d => ({ ...d, error: '뉴스 갱신 연결이 지연되고 있습니다. 마지막 수집 목록을 표시합니다.' })); }
    finally { inFlight.current = false; if (alive.current) setBusy(false); }
  }, []);
  useEffect(() => {
    alive.current = true; void refresh();
    const timer = setInterval(() => { attempts.current = 0; if(document.visibilityState==='visible')void refresh(); }, 300000);
    const visible = () => { if (document.visibilityState === 'visible' && Date.now() - lastRefresh.current >= 300000) void refresh(); };
    document.addEventListener('visibilitychange', visible);
    return () => { alive.current = false; clearInterval(timer); if (retry.current) clearTimeout(retry.current); document.removeEventListener('visibilitychange', visible); };
  }, [refresh]);
  return <NewsContext.Provider value={{ data, busy, refresh }}>{children}</NewsContext.Provider>;
}
export const useNews = () => useContext(NewsContext);
export function newsTime(value: string | null, short = false) {
  if (!value) return '미확인';
  return new Intl.DateTimeFormat('ko-KR', { timeZone: 'Asia/Seoul', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false, ...(short ? {} : { year: 'numeric' }) }).format(new Date(value));
}
export function currentNews(data: NewsSnapshot, now: number) {
  return data.articles.filter(a => Date.parse(a.publishedAt) >= now - 7 * 86400000);
}
