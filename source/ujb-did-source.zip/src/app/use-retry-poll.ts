'use client';
import {useEffect,useRef} from 'react';
// Bounded polling only while visible; normal refresh timers remain independent.
export function useRetryPoll(enabled:boolean,refresh:()=>unknown,key=''){
 const latest=useRef(refresh);latest.current=refresh;
 useEffect(()=>{
  if(!enabled)return;
  const delays=[10000,30000,60000,300000,300000,300000];
  let stopped=false,index=0,timer:ReturnType<typeof setTimeout>;
  const next=()=>{if(stopped||index>=delays.length)return;timer=setTimeout(async()=>{
   if(document.visibilityState==='visible'){index++;try{await latest.current();}catch{/* regular refresh will retry later */}}
   next();
  },delays[index]);};next();return()=>{stopped=true;clearTimeout(timer);};
 },[enabled,key]);
}
