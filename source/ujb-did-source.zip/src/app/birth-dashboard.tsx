import {readJSON as fetch} from '@/json-api';
'use client';
import {useRetryPoll} from './use-retry-poll';
import {useEffect,useState} from 'react';
import {Baby,RefreshCw} from 'lucide-react';
import {birthIndicators,emptyBirths,type BirthData} from '@/lib/births';
import {monthOffset,POP_REGIONS,type PopulationData} from '@/lib/population';
const n=(v:number|null|undefined,d=0)=>v==null?'—':v.toLocaleString('ko-KR',{maximumFractionDigits:d});
const sign=(v:number|null)=>v==null?'비교 자료 대기':`${v>0?'+':''}${n(v)}명`;
export default function BirthDashboard({population,id,month,onSelect,onData}:{population:PopulationData;id:string;month:string;onSelect:(id:string)=>void;onData?:(data:BirthData)=>void}){
 const [data,setData]=useState<BirthData>(emptyBirths()),[error,setError]=useState(''),[rate,setRate]=useState(false),[busy,setBusy]=useState(false);
 async function refresh(){setBusy(true);try{const r=await fetch('/api/births',{cache:'no-store',signal:AbortSignal.timeout(15000)});if(!r.ok)throw Error();const value=await r.json() as BirthData;if(!Array.isArray(value.months))throw Error();setData(value);setError('');}catch{setError('출생등록 조회 지연 · 마지막 성공 자료 유지');}finally{setBusy(false);}}
 useEffect(()=>{void refresh();const timer=setInterval(()=>{if(document.visibilityState==='visible')void refresh();},3600000);return()=>clearInterval(timer);},[]);
 useRetryPoll(data.pending||Boolean(error),refresh);
 useEffect(()=>{onData?.(data);},[data,onData]);
 const d=birthIndicators(data,population,id,month);const name=POP_REGIONS.find(r=>r.id===id)?.name;
 const trend=Array.from({length:12},(_,i)=>{const m=monthOffset(month,i-11);return {month:m,...birthIndicators(data,population,id,m)};});
 const chartMax=Math.max(1,...trend.flatMap(t=>[t.current?.population??0,t.lastYear?.population??0]));
 const chartStep=Math.max(1,Math.ceil(chartMax/4/10)*10),chartTop=chartStep*4;
 const chartX=(i:number)=>55+i*64,chartY=(v:number)=>290-v/chartTop*210;
 const ranks=POP_REGIONS.filter(r=>r.id!=='city').map(r=>({...r,...birthIndicators(data,population,r.id,month)})).sort((a,b)=>(rate?b.rate??-1:b.current?.population??-1)-(rate?a.rate??-1:a.current?.population??-1));
 const metric=(label:string,value:string,note:string)=><article className="birth-metric" key={label}><span>{label}</span><strong>{value}</strong><small>{note}</small></article>;
 const missing=!d.current;
 return <section id="birth-registration" className="birth-section" aria-label="출생등록 현황">
 <div className="section-heading"><div><span className="eyebrow">BIRTH REGISTRATION · {month.slice(0,4)}.{month.slice(4)}</span><h2><Baby size={25}/>출생등록 현황</h2></div><button className="pop-text-button" disabled={busy} onClick={()=>void refresh()}><RefreshCw size={16} className={busy?'spin':''}/>자료 확인</button></div>
 <p className="pop-caption">{name} · 출생등록 · {data.savedAt?`저장 ${new Date(data.savedAt).toLocaleString('ko-KR',{timeZone:'Asia/Seoul'})}`:'최초 자료 수집 대기'}</p>
 {(data.pending||data.error||error||missing)&&<p className="pop-status" role="status">{error||data.error||(data.pending?'출생등록 자료 수집 중 · 확인된 자료부터 표시합니다.':`${month.slice(0,4)}년 ${Number(month.slice(4))}월 출생등록 자료 미확보 · 미확보 수치는 0명으로 표시하지 않습니다.`)}</p>}
 <div className="birth-metrics">
 {metric('선택 월 출생등록',`${n(d.current?.population)}명`,`전월 대비 ${sign(d.change)}`)}
 {metric('전년 동월 대비',sign(d.yoy),d.lastYear?`지난해 같은 달 ${n(d.lastYear.population)}명`:'지난해 같은 달 자료 확인 중')}
 {metric('올해 누적 출생등록',`${n(d.total)}명`,`1~${Number(month.slice(4))}월 · 전년 동기 ${sign(d.cumulativeChange)}`)}
 {metric('남자 / 여자',`${n(d.current?.male)} / ${n(d.current?.female)}명`,d.current?.population?`여자 비중 ${n(d.current.female/d.current.population*100,1)}%`:'성별 출생등록 현황')}
 {metric('인구 1,000명당',`${n(d.rate,2)}명`,'해당 월 출생등록자수 ÷ 같은 월 인구 × 1,000')}
 </div>
 <div className="birth-grid">
 <section className="panel"><div className="section-heading"><h2>최근 12개월 출생등록</h2><span className="birth-line-legend"><span>━ 현년도</span><span>┄ 전년도</span></span></div>
 <div className="birth-line-scroll"><svg className="birth-line-chart" viewBox="0 0 800 355" role="img" aria-label={`${name} 최근 12개월 출생등록 현년도·전년도 비교 꺾은선 그래프`}>
 <title>{`${name} 월별 출생등록 전년 동월 비교`}</title><desc>{trend.map(t=>`${t.month}: 현년도 ${n(t.current?.population)}명, 전년도 같은 달 ${n(t.lastYear?.population)}명`).join('; ')+'. 미확보 월은 선을 연결하지 않습니다.'}</desc>
 <text x="10" y="20" className="birth-line-axis">단위: 명</text>
 {Array.from({length:5},(_,i)=>i*chartStep).map(v=><g key={v}><line x1="55" x2="759" y1={chartY(v)} y2={chartY(v)} className="birth-line-grid"/><text x="45" y={chartY(v)} textAnchor="end" dominantBaseline="central" className="birth-line-axis">{n(v)}</text></g>)}
 {(['lastYear','current'] as const).map(key=><g key={key} className={`birth-line-series ${key==='current'?'current':'prior'}`}>
 {trend.slice(1).map((t,i)=>t[key]&&trend[i][key]?<line key={t.month} x1={chartX(i)} y1={chartY(trend[i][key]!.population)} x2={chartX(i+1)} y2={chartY(t[key]!.population)}/>:null)}
 {trend.map((t,i)=>{const row=t[key];if(!row)return null;const current=key==='current';const ys=[t.current,t.lastYear].flatMap(v=>v?[chartY(v.population)]:[]);const labelY=current?Math.min(...ys)-48:Math.max(...ys)+23;return <g key={t.month}>
 <circle cx={chartX(i)} cy={chartY(row.population)} r="4"><title>{`${t.month} ${current?'해당 월':'전년 동월'} 합계 ${n(row.population)}명 · 남자 ${n(row.male)}명 · 여자 ${n(row.female)}명`}</title></circle>
 <path d={`M ${chartX(i)} ${chartY(row.population)+(current?-7:7)} V ${current?labelY+34:labelY-12}`} className="birth-label-guide"/>
 <text x={chartX(i)} y={labelY} textAnchor="middle" className="birth-line-value">{n(row.population)}명</text>
 {current&&<text x={chartX(i)} y={labelY+15} textAnchor="middle" className="birth-line-sex"><tspan x={chartX(i)}>남 {n(row.male)}명</tspan><tspan x={chartX(i)} dy="14">여 {n(row.female)}명</tspan></text>}
 </g>;})}
 </g>)}
 {trend.map((t,i)=><text key={t.month} x={chartX(i)} y="337" textAnchor="middle" className="birth-line-axis">{t.month.slice(2,4)}.{t.month.slice(4)}</text>)}
 </svg></div><p className="pop-caption">최근 12개월과 전년 동월 비교 · 미확보 월 제외</p></section>
 <section className="panel"><div className="section-heading"><h2>행정동별 출생등록 비교</h2><div className="birth-toggle"><button aria-pressed={!rate} onClick={()=>setRate(false)}>인원</button><button aria-pressed={rate} onClick={()=>setRate(true)}>인구 1천 명당</button></div></div><p className="pop-caption"><button className="pop-text-button" onClick={()=>onSelect('city')} aria-pressed={id==='city'}>의정부시 전체 보기</button></p><div className="birth-ranks">{ranks.map((r,i)=><button type="button" key={r.id} className={id===r.id?'selected':''} aria-pressed={id===r.id} onClick={()=>onSelect(r.id)}><span>{i+1}. {r.name}</span><b>{n(rate?r.rate:r.current?.population,rate?2:0)}명</b></button>)}</div></section>
 </div>
 <p className="pop-caption">출처: 행정안전부 행정동별(통반단위) 성별 출생등록자수 · 출생등록 기준으로 실제 출생일 기준 통계와 다를 수 있습니다.</p>
 </section>;
}
