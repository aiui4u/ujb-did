'use client';
import type {PopulationRow} from '@/lib/population';

export default function PopulationLine({trend,region}:{trend:{month:string;row?:PopulationRow}[];region:string}){
 const values=trend.flatMap(t=>t.row?[t.row.population]:[]);
 if(!values.length)return <p className="pop-empty">수집된 월별 인구 자료가 없습니다.</p>;
 const minimum=Math.min(...values),maximum=Math.max(...values),padding=Math.max((maximum-minimum)*.15,50);
 const step=Math.max(100,Math.ceil((maximum-minimum+padding*2)/4/100)*100);
 const low=Math.max(0,Math.floor((minimum-padding)/step)*step),high=Math.max(low+step,Math.ceil((maximum+padding)/step)*step);
 const y=(n:number)=>210-(n-low)/(high-low)*160;
 const points=trend.map((t,i)=>({...t,x:90+i*115,y:t.row?y(t.row.population):null}));
 const ticks=Array.from({length:Math.round((high-low)/step)+1},(_,i)=>low+i*step);
 return <div className="pop-line-scroll"><svg className="pop-line" viewBox="0 0 640 270" role="img" aria-label={`${region} 최근 5개월 인구 변화 선 그래프`}>
  <title>{`${region} 월말 주민등록 인구`}</title><desc>{points.map(t=>`${t.month.slice(0,4)}년 ${Number(t.month.slice(4))}월 ${t.row?t.row.population.toLocaleString('ko-KR')+'명':'자료 수집 대기'}`).join(', ')+`. 세로축 ${low.toLocaleString('ko-KR')}명부터 ${high.toLocaleString('ko-KR')}명까지.`}</desc>
  <text x="12" y="24" className="pop-line-axis">인구(명)</text>
  {ticks.map(n=><g key={n}><line x1="80" x2="580" y1={y(n)} y2={y(n)} className="pop-line-grid"/><text x="70" y={y(n)} textAnchor="end" dominantBaseline="central" className="pop-line-axis">{n.toLocaleString('ko-KR')}</text></g>)}
  {points.slice(1).map((p,i)=>p.y!==null&&points[i].y!==null?<line key={p.month} x1={points[i].x} y1={points[i].y!} x2={p.x} y2={p.y} className="pop-line-segment"/>:null)}
  {points.map(p=><g key={p.month}>{p.y!==null&&p.row?<><circle cx={p.x} cy={p.y} r="5" className="pop-line-dot"/><text x={p.x} y={p.y-15} textAnchor="middle" className="pop-line-value">{p.row.population.toLocaleString('ko-KR')}</text></>:<text x={p.x} y="130" textAnchor="middle" className="pop-line-axis">수집 대기</text>}<text x={p.x} y="240" textAnchor="middle" className="pop-line-month">{Number(p.month.slice(4))}월</text></g>)}
 </svg><p className="pop-caption">월말 주민등록 인구 · 최근 5개월 · 세로축 {low.toLocaleString('ko-KR')}~{high.toLocaleString('ko-KR')}명으로 확대 표시합니다.</p></div>;
}
