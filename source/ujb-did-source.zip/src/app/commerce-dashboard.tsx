import {readJSON as fetch} from '@/json-api';
'use client';
import PageHeading from './page-heading';
import {useRetryPoll} from './use-retry-poll';
import {useCallback,useEffect,useRef,useState} from 'react';
import {Store as StoreIcon,UtensilsCrossed,ShoppingBag,UsersRound,MapPin,RefreshCw,ArrowUpRight,Info,Maximize,Minimize} from 'lucide-react';
import {COMMERCE_REGIONS,perThousand,specialization,type CommerceData,type CommerceRegion,type CommerceStatus} from '@/lib/commerce';
import CommerceDongDonut from './commerce-dong-donut';
import CommerceIndustryDonut from './commerce-industry-donut';
const nf=(n:number|null|undefined,digits=0)=>n===null||n===undefined?'—':n.toLocaleString('ko-KR',{maximumFractionDigits:digits,minimumFractionDigits:digits});
const time=(s:string|null|undefined)=>s?new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(s)):'수집 대기';
async function responseJson<T>(r:Response):Promise<T>{try{return await r.json() as T;}catch{throw Error('자료 연결을 확인하고 있습니다. 잠시 후 다시 확인해 주세요.');}}
export default function CommerceDashboard({initialData}:{initialData:CommerceData}){
 const [data,setData]=useState(initialData),[regionId,setRegion]=useState('city'),[industry,setIndustry]=useState(''),[collecting,setCollecting]=useState(false),[full,setFull]=useState(false),[help,setHelp]=useState(false);
 const running=useRef(false),alive=useRef(true),timer=useRef<ReturnType<typeof setTimeout>|null>(null);
 const refresh=useCallback(async()=>{const response=await fetch('/api/commerce',{cache:'no-store'});if(!response.ok)throw Error('상권 자료 조회 지연');const next=await responseJson<CommerceData>(response);if(alive.current)setData(next);return next;},[]);
 const collect=useCallback(async(_force=false)=>{if(running.current)return;running.current=true;setCollecting(true);
  try{const r=await fetch('/api/commerce/collect',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}',signal:AbortSignal.timeout(45000)});if(!r.ok)throw Error('상권 수집 연결 확인 중');await refresh();}
  catch(e){if(alive.current)setData(d=>({...d,status:{...d.status,error:e instanceof Error?e.message:'자료 수집 지연'}}));}
  finally{running.current=false;if(alive.current)setCollecting(false);}
 },[refresh]);
 useEffect(()=>{alive.current=true;const hour=setInterval(()=>{if(document.visibilityState==='visible')void refresh().catch(()=>{});},3600000);const fs=()=>setFull(!!document.fullscreenElement);document.addEventListener('fullscreenchange',fs);return()=>{alive.current=false;clearInterval(hour);document.removeEventListener('fullscreenchange',fs);};},[refresh]);
 useRetryPoll(data.status.pending,refresh);

 const snapshot=data.snapshot,city=snapshot?.regions.find(r=>r.id==='city'),region=snapshot?.regions.find(r=>r.id===regionId),population=data.population?.regions.find(r=>r.id===regionId)?.population??null,cityPopulation=data.population?.regions.find(r=>r.id==='city')?.population??null;
 const selectRegion=(id:string)=>{setRegion(id);setIndustry('');};
 async function fullscreen(){if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}
 return <main className="did commerce-did"><PageHeading title="의정부시 상권·생활편의 현황"><div className="commerce-header-actions"><button onClick={()=>setHelp(v=>!v)} aria-expanded={help} aria-label="상권 지표 설명"><Info size={20}/></button><button onClick={()=>void collect(true)} disabled={collecting} aria-label="상권 자료 새로 수집"><RefreshCw size={20} className={collecting?'spin':''}/></button><button onClick={()=>void fullscreen()} aria-label={full?'전체화면 종료':'전체화면'}>{full?<Minimize size={20}/>:<Maximize size={20}/>}</button></div></PageHeading>
 <div className="commerce-selector"><label><MapPin size={19}/> 지역 선택 <select value={regionId} onChange={e=>selectRegion(e.target.value)}>{COMMERCE_REGIONS.map(r=><option key={r.id} value={r.id}>{r.name}</option>)}</select></label><span>상가 수집 {time(snapshot?.collectedAt)}</span><span>인구 기준 {data.population?`${data.population.month.slice(0,4)}년 ${Number(data.population.month.slice(4))}월`:'자료 확인 중'}</span></div>
 {help&&<div className="commerce-help"><h2>표시 지표와 자료 기준</h2><p>업소 수는 소상공인시장진흥공단 API 수록 자료를 업소번호별로 집계합니다. 주민 1,000명당 업소 수 = 업소 수 ÷ 주민등록 인구 × 1,000. 업종 특화도 = 해당 동의 업종 비중 ÷ 의정부시의 같은 업종 비중.</p><p>생활편의 업소는 소분류명으로 편의점·마트 및 식료품·세탁·미용 및 관리·약국·카페·음식점(카페 제외)·교육 및 학원·보건의료·자동차정비 및 세차의 10종으로 분류합니다. 날짜가 다른 인구·상가 자료는 각각의 기준을 표시합니다. 업소의 현재 영업시간·매출·개업·폐업 수치는 별도 자료가 필요합니다.</p><p>제공기관 자료에 있는 행정동과 업종을 사용합니다.{snapshot?.unmapped?` 행정동 확인이 필요한 ${nf(snapshot.unmapped)}개 업소는 전체 합계에 포함됩니다.`:''}</p><a href="https://www.data.go.kr/data/15012005/openapi.do" target="_blank" rel="noreferrer">공식 데이터 안내 <ArrowUpRight size={14}/></a></div>}
 {(collecting||data.status.pending)&&<div className="commerce-progress"><RefreshCw size={17} className={collecting?'spin':''}/><span>상권 자료 수집 중 · {nf(data.status.rows)}{data.status.total!==null?` / ${nf(data.status.total)}`:''}개{data.status.pages?` · ${data.status.page}/${data.status.pages}페이지`:''}</span>{snapshot&&<small>마지막 수집 완료 자료 표시</small>}</div>}
 {data.status.error&&<div className="commerce-error">{data.status.error}<button onClick={()=>void collect(true)} disabled={collecting}>다시 수집</button></div>}
 {!region||!city?<div className="panel commerce-empty"><StoreIcon size={42}/><h2>의정부시 상권 자료를 수집하고 있습니다</h2><p>전체 페이지 수집과 동별·업종별 합계 확인이 끝나면 실제 수치를 표시합니다.</p></div>:<>
 <section className="commerce-metrics" aria-label="핵심 상권 지표">{[{name:'데이터 수록 업소',value:region.count,unit:'개',icon:StoreIcon,note:region.name},{name:'음식점 업소',value:region.food,unit:'개',icon:UtensilsCrossed,note:`전체의 ${(region.food/Math.max(1,region.count)*100).toFixed(1)}%`},{name:'생활편의 업소',value:region.convenience,unit:'개',icon:ShoppingBag,note:'편의점·식료품·음식·교육 등 10종'},{name:'주민 1,000명당 업소',value:perThousand(region.count,population),digits:1,unit:'개',icon:UsersRound,note:`주민등록 인구 ${nf(population)}명`}].map(m=><article key={m.name}><span><m.icon size={20}/>{m.name}</span><strong>{nf(m.value,m.digits??0)}<small>{m.unit}</small></strong><p>{m.note}</p></article>)}</section>
 <section className="commerce-overview"><div className="panel"><div className="section-heading"><h2>15개 동별 업소 비교</h2><span className="commerce-unit">단위: 개</span></div><CommerceDongDonut rows={snapshot?.regions??[]} total={city.count} selected={regionId} onSelect={selectRegion}/></div><div className="panel"><div className="section-heading"><h2>{regionId==='city'?'의정부시':region.name} 업종 구성</h2>{industry&&<button className="commerce-reset" onClick={()=>setIndustry('')}>선택 해제</button>}</div><CommerceIndustryDonut region={region} city={city} selected={industry} onSelect={setIndustry}/></div></section>
 <section className="commerce-details-grid"><div className="panel"><div className="section-heading"><h2>대표 업종 상위 10개</h2><span className="commerce-unit">{region.name}</span></div><table className="commerce-table"><thead><tr><th>업종</th><th>업소 수</th><th>비중</th>{regionId!=='city'&&<th>특화도</th>}</tr></thead><tbody>{region.middle.slice(0,10).map(i=><tr key={i.code}><td>{i.name}</td><td>{nf(i.count)}개</td><td>{(i.count/Math.max(1,region.count)*100).toFixed(1)}%</td>{regionId!=='city'&&<td>{nf(specialization(region,city,i),1)}배</td>}</tr>)}</tbody></table><p className="commerce-caption">중분류 기준{regionId!=='city'?' · 특화도는 해당 업종 비중의 시 전체 평균 대비 배수':''}</p></div><div className="panel"><div className="section-heading"><h2>생활편의 업소와 인구 · 10종</h2><span className="commerce-unit">주민 1,000명당</span></div><table className="commerce-table"><thead><tr><th>생활편의 업종</th><th>업소 수</th><th>{region.name}</th><th>시 전체</th></tr></thead><tbody>{region.services.map(s=><tr key={s.id}><td>{s.name}</td><td>{nf(s.count)}개</td><td>{nf(perThousand(s.count,population),2)}</td><td>{nf(perThousand(city.services.find(c=>c.id===s.id)?.count??0,cityPopulation),2)}</td></tr>)}</tbody></table></div></section>

 </>}
 </main>;
}
