import DidNavigation from './did-navigation';
import HomeDashboard from './home-dashboard';
import {allPlans} from '@/lib/pledges/plan-model';
import {annualBudget,years} from '@/lib/pledges/dashboard-model';
import pledges from '@/lib/pledges/pledges.json';
import './home.css';
export default function HomePage(){
 const departments=[...new Set(pledges.map(p=>p.dept))].map(name=>({name,count:pledges.filter(p=>p.dept===name).length})).sort((a,b)=>b.count-a.count||a.name.localeCompare(b.name,'ko'));
 return <><DidNavigation active="home"/><HomeDashboard pledge={{count:pledges.length,departments,budgets:years.map(year=>({year,...annualBudget(allPlans(),year)}))}}/></>;
}
