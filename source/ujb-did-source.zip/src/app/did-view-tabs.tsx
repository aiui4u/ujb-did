'use client';
import {Children,useId,useRef,useState,type ReactNode} from 'react';

/** Manual views keep data components mounted and retain shared region selection. */
export default function DidViewTabs({labels,children,label}:{labels:string[];children:ReactNode;label:string}){
 const [active,setActive]=useState(0),id=useId(),buttons=useRef<(HTMLButtonElement|null)[]>([]);
 const panels=Children.toArray(children);
 return <div className="did-views"><div className="did-view-tabs" role="tablist" aria-label={label}>{labels.map((name,i)=><button key={name} ref={node=>{buttons.current[i]=node;}} type="button" role="tab" id={`${id}-tab-${i}`} aria-controls={`${id}-panel-${i}`} aria-selected={active===i} tabIndex={active===i?0:-1} onClick={()=>setActive(i)} onKeyDown={e=>{let next:number;if(e.key==='ArrowRight')next=(i+1)%labels.length;else if(e.key==='ArrowLeft')next=(i+labels.length-1)%labels.length;else if(e.key==='Home')next=0;else if(e.key==='End')next=labels.length-1;else return;e.preventDefault();setActive(next);buttons.current[next]?.focus();}}>{name}</button>)}</div>{panels.map((panel,i)=><div key={i} className="did-view-panel" role="tabpanel" id={`${id}-panel-${i}`} aria-labelledby={`${id}-tab-${i}`} hidden={active!==i}>{panel}</div>)}</div>;
}
