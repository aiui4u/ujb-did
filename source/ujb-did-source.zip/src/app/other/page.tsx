import DidNavigation from '../did-navigation';
import OtherDashboard from '../other-dashboard';

export const dynamic='force-dynamic';
export default function Page(){return <><DidNavigation active="other"/><OtherDashboard/></>;}
