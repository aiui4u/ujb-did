import React,{useEffect,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {loadFile} from './json-api';
import {NewsProvider} from './app/news-provider';
import Home from './app/page';
import Pledges from './app/pledges/page';
import Projects from './app/pledges/projects/page';
import News from './app/news/page';
import Navigation from './app/did-navigation';
import WeatherDashboard from './app/weather-dashboard';
import PopulationDashboard from './app/population-dashboard';
import CommerceDashboard from './app/commerce-dashboard';
import TrafficDashboard from './app/traffic-dashboard';
import Other from './app/other/page';
import {emptyPopulation} from './lib/population';
import {emptyCommerce} from './lib/commerce';
import {trafficYears} from './lib/traffic';
import {packSnapshots} from './lib/snapshot-packet';
import './app/globals.css';
import './app/did-navigation.css';
import './app/did-display.css';
import './app/page-heading.css';

function App(){
 const [route,setRoute]=useState(location.pathname),[saved,setSaved]=useState<any>(null),[failed,setFailed]=useState(false);
 useEffect(()=>{let alive=true;loadFile().then(d=>{if(alive)setSaved(d);}).catch(()=>{if(alive)setFailed(true);});return()=>{alive=false;};},[]);
 useEffect(()=>{const onPop=()=>setRoute(location.pathname);const click=(e:MouseEvent)=>{if(e.defaultPrevented||e.button!==0||e.ctrlKey||e.metaKey||e.shiftKey||e.altKey)return;const a=(e.target as Element)?.closest('a');if(!a||a.target==='_blank'||a.hasAttribute('download'))return;const u=new URL(a.href);if(u.origin!==location.origin||!u.pathname.startsWith(import.meta.env.BASE_URL))return;if(/\.(pdf|svg|webp|png|jpg|json)$/.test(u.pathname))return;e.preventDefault();history.pushState(null,'',u.pathname+u.search+u.hash);setRoute(u.pathname);window.scrollTo(0,0);};document.addEventListener('click',click);window.addEventListener('popstate',onPop);return()=>{document.removeEventListener('click',click);window.removeEventListener('popstate',onPop);};},[]);
 if(!saved)return <div role="status" style={{padding:40,color:'#b8e8ff'}}>{failed?'저장자료 연결을 확인해 주세요. 새로고침하면 다시 조회합니다.':'의정부시 통합현황 자료를 불러오고 있습니다.'}</div>;
 const page=route.replace(/^\/ujb-did\/?/,'').replace(/\/$/,'');
 let screen:React.ReactNode;
 switch(page){
  case 'pledges':screen=<Pledges/>;break;
  case 'pledges/projects':screen=<div className="pledge-surface"><Projects/></div>;break;
  case 'news':screen=<News/>;break;
  case 'weather':screen=<><Navigation active="weather"/><WeatherDashboard initialPacket={packSnapshots(saved.weather?{city:saved.weather}:{})} initialRegion="city" initialTime={new Date().toISOString()}/></>;break;
  case 'population':screen=<><Navigation active="population"/><PopulationDashboard initialData={saved.population??emptyPopulation()}/></>;break;
  case 'commerce':screen=<><Navigation active="commerce"/><CommerceDashboard initialData={saved.commerce??emptyCommerce()}/></>;break;
  case 'traffic':screen=<><Navigation active="traffic"/><TrafficDashboard initialData={saved.traffic??{years:trafficYears(),snapshots:[],states:[]}}/></>;break;
  case 'other':screen=<Other/>;break;
  default:screen=<Home/>;
 }
 return <NewsProvider><React.Fragment key={page}>{screen}</React.Fragment></NewsProvider>;
}
createRoot(document.getElementById('root')!).render(<App/>);
