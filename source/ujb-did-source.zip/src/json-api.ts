import {packSnapshots} from './lib/snapshot-packet';
const nativeFetch=globalThis.fetch.bind(globalThis);
const cache=new Map<string,{at:number;value:any}>(),running=new Map<string,Promise<any>>();
export async function loadFile(file='data.json',signal?:AbortSignal){
 const saved=cache.get(file);if(saved&&Date.now()-saved.at<30000)return saved.value;
 if(!running.has(file))running.set(file,(async()=>{try{const r=await nativeFetch(import.meta.env.BASE_URL+file,{cache:'no-store',signal});if(!r.ok)throw Error('저장 JSON 연결 지연');const value=await r.json();cache.set(file,{at:Date.now(),value});return value;}finally{running.delete(file);}})());
 return running.get(file)!;
}
export async function readJSON(input:RequestInfo|URL,options:RequestInit={}){
 const url=new URL(input instanceof Request?input.url:String(input),location.origin);
 if(!url.pathname.startsWith('/api/'))return nativeFetch(input,options);
 const reply=(value:any,status=200)=>new Response(JSON.stringify(value),{status,headers:{'Content-Type':'application/json'}});
 const path=url.pathname,month=url.searchParams.get('month')??'';
 if(path.startsWith('/api/complaints'))return reply({error:'민원 수집은 비활성 상태입니다.',pending:false},403);
 if(options.method&&options.method!=='GET')return reply({started:false,pending:false,message:'자동 수집으로 저장된 JSON을 조회합니다.'});
 try{
  if(path==='/api/news')return reply(await loadFile('news.json',options.signal??undefined));
  const d=await loadFile('data.json',options.signal??undefined);
  if(path==='/api/snapshots')return reply(packSnapshots(d.weather?{city:d.weather}:{}));
  if(path==='/api/weather')return reply(d.weather??{error:'날씨 자료 첫 수신 대기'},d.weather?200:503);
  if(path==='/api/population/household-sizes')return reply(d.monthly?.[month]?.households??{month,regions:[],error:'해당 월 저장자료 수집 대기'});
  if(path==='/api/population/resident-age')return reply(d.monthly?.[month]?.ages??{month,regions:[],error:'해당 월 저장자료 수집 대기'});
  if(path==='/api/population/areas'){const id=url.searchParams.get('dong')??'city';return reply(d.areas?.[`${month}:${id}`]??{id,month,row:null,savedAt:null,pending:false,error:null,note:'지역 상세 저장자료 수집 대기'});}
  if(path==='/api/commerce/stores'){const dong=url.searchParams.get('dong')??'city';return reply({runId:d.commerce?.snapshot?.runId??null,stores:(d.stores??[]).filter((s:any)=>dong==='city'||s.dong===dong)});}
  const field:Record<string,string>={'/api/home':'home','/api/population':'population','/api/births':'births','/api/commerce':'commerce','/api/warnings':'warnings','/api/traffic':'traffic'};
  if(field[path])return reply(d[field[path]]??{error:'저장자료 첫 수신 대기'},d[field[path]]?200:503);
  if(path==='/api/other')return reply(d.other?.[url.searchParams.get('year')??'']??{error:'저장자료 수집 대기'},d.other?.[url.searchParams.get('year')??'']?200:503);
  return reply({error:'지원하지 않는 자료 요청'},404);
 }catch{return reply({error:'저장자료 조회 지연 · 마지막 자료 유지'},503);}
}
