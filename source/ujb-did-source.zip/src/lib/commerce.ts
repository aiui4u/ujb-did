import {POP_REGIONS,type PopulationMonth} from './population';
export const COMMERCE_REGIONS=POP_REGIONS;
export type Store={id:string;name:string;branch:string;dong:string;dongName:string;largeCode:string;large:string;middleCode:string;middle:string;smallCode:string;small:string;address:string;lon:number|null;lat:number|null};
export type Industry={code:string;name:string;count:number};
export const CONVENIENCE=[{id:'convenience',name:'편의점',pattern:'편의점'},{id:'grocery',name:'마트·식료품',pattern:'슈퍼마켓|마트|식료품|청과|채소|과일|정육|육류|수산물'},{id:'laundry',name:'세탁소',pattern:'세탁'},{id:'beauty',name:'미용·관리',pattern:'미용|이용업|이용원|이발|피부 관리|손.*발톱.*관리|네일|메이크업'},{id:'pharmacy',name:'약국',pattern:'약국'},{id:'cafe',name:'카페',pattern:'카페|커피|다방'},{id:'restaurant',name:'음식점(카페 제외)',pattern:''},{id:'education',name:'교육·학원',pattern:''},{id:'health',name:'보건의료',pattern:''},{id:'vehicle',name:'자동차정비·세차',pattern:'자동차.*(정비|수리|세차)|정비소|세차장'}] as const;
export const convenienceKind=(s:Store)=>CONVENIENCE.find(c=>{if(c.id==='restaurant')return isFood(s)&&!/카페|커피|다방/.test(s.small);if(c.id==='education')return s.largeCode==='P1'||/교육/.test(s.large);if(c.id==='health')return s.largeCode==='Q1'||/보건의료/.test(s.large);return new RegExp(c.pattern).test(s.small)&&(c.id!=='cafe'||isFood(s))&&(c.id!=='grocery'||s.largeCode==='G2'||/소매/.test(s.large)||/소매|마트|슈퍼마켓/.test(s.small))&&(!['beauty','laundry'].includes(c.id)||!/소매|도매|제조/.test(s.small));})?.id??null;
export const isFood=(s:Store)=>/음식|식당/.test(s.large)||s.largeCode==='I2'||s.largeCode==='Q';
export type CommerceRegion={id:string;name:string;count:number;food:number;convenience:number;mapped:number;industries:Industry[];middle:Industry[];small:Industry[];services:{id:string;name:string;count:number}[]};
export type CommerceSnapshot={analysisVersion?:number;runId:string;collectedAt:string;sourceTotal:number;count:number;regions:CommerceRegion[];unmapped:number;missingCoordinates:number;history:{date:string;count:number}[]};
export type CommerceStatus={pending:boolean;page:number;pages:number|null;rows:number;total:number|null;error:string|null;startedAt:string|null};
export type CommerceData={snapshot:CommerceSnapshot|null;population:PopulationMonth|null;status:CommerceStatus};
export const emptyCommerce=():CommerceData=>({snapshot:null,population:null,status:{pending:false,page:0,pages:null,rows:0,total:null,error:null,startedAt:null}});
function text(row:Record<string,unknown>,key:string){return String(row[key]??'').trim();}
function coordinate(v:unknown,min:number,max:number){if(v===null||v===undefined||v==='')return null;const n=Number(v);return Number.isFinite(n)&&n>=min&&n<=max?n:null;}
export function normalizeStore(row:Record<string,unknown>):Store{
 const id=text(row,'bizesId');if(!id)throw Error('업소번호 확인 필요');
 if(text(row,'signguCd')!=='41150')throw Error('의정부시 조회 범위 검증 필요');
 const raw=text(row,'adongCd');const code=raw.padEnd(10,'0');const region=COMMERCE_REGIONS.find(r=>r.id===code||r.name===text(row,'adongNm'));
 return {id,name:text(row,'bizesNm')||'상호명 미제공',branch:text(row,'brchNm'),dong:region?.id??code,dongName:region?.name??text(row,'adongNm'),largeCode:text(row,'indsLclsCd'),large:text(row,'indsLclsNm')||'업종 미분류',middleCode:text(row,'indsMclsCd'),middle:text(row,'indsMclsNm')||'업종 미분류',smallCode:text(row,'indsSclsCd'),small:text(row,'indsSclsNm')||'업종 미분류',address:text(row,'rdnmAdr')||text(row,'lnoAdr'),lon:coordinate(row.lon,126,129),lat:coordinate(row.lat,36,39)};
}
function industries(stores:Store[],level:'large'|'middle'|'small'):Industry[]{const groups=new Map<string,Industry>();for(const s of stores){const code=s[`${level}Code`]||'unknown',old=groups.get(code);if(old)old.count++;else groups.set(code,{code,name:s[level],count:1});}return [...groups.values()].sort((a,b)=>b.count-a.count||a.code.localeCompare(b.code));}
export function summarizeCommerce(stores:Store[],runId:string,collectedAt:string,expected:number,previous:CommerceSnapshot|null):CommerceSnapshot{
 const unique=new Set(stores.map(s=>s.id));if(unique.size!==stores.length||stores.length!==expected)throw Error('전체 페이지·업소번호 중복 검증 필요');
 const regions=COMMERCE_REGIONS.map(r=>{const local=r.id==='city'?stores:stores.filter(s=>s.dong===r.id);return {id:r.id,name:r.name,count:local.length,food:local.filter(isFood).length,convenience:local.filter(s=>convenienceKind(s)!==null).length,mapped:local.filter(s=>s.lon!==null&&s.lat!==null).length,industries:industries(local,'large'),middle:industries(local,'middle'),small:industries(local,'small'),services:CONVENIENCE.map(c=>({id:c.id,name:c.name,count:local.filter(s=>convenienceKind(s)===c.id).length}))};});
 const unmapped=stores.filter(s=>!COMMERCE_REGIONS.some(r=>r.id===s.dong)).length;
 if(regions.slice(1).reduce((n,r)=>n+r.count,0)+unmapped!==expected)throw Error('동별 합계 검증 필요');
 for(const r of regions)if(r.industries.reduce((n,i)=>n+i.count,0)!==r.count)throw Error('업종별 합계 검증 필요');
 const date=new Date(new Date(collectedAt).getTime()+9*3600000).toISOString().slice(0,10);const history=[...(previous?.history??[]).filter(h=>h.date!==date),{date,count:expected}].slice(-12);
 return {analysisVersion:3,runId,collectedAt,sourceTotal:expected,count:expected,regions,unmapped,missingCoordinates:stores.filter(s=>s.lon===null||s.lat===null).length,history};
}
export function perThousand(count:number,population:number|null|undefined){return population&&population>0?count/population*1000:null;}
export function specialization(local:CommerceRegion,city:CommerceRegion,industry:Industry){const cityCount=city.middle.find(i=>i.code===industry.code)?.count??0;return local.count&&city.count&&cityCount?(industry.count/local.count)/(cityCount/city.count):null;}
