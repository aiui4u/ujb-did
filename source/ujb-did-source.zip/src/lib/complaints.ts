export type ComplaintRow={name:string;value:number;date?:string;ratio?:number;children?:ComplaintRow[];url?:string;content?:string};
export type ComplaintResult={rows:ComplaintRow[];error:string|null;checkedAt:string|null;latestDate:string|null;empty:boolean;periodFrom?:string;periodTo?:string;savedAt?:string;lastAttemptAt?:string;collectionError?:string|null};
export const complaintKinds=['stats','fields','gender','age','df','tfidf','rising','topics','reports','related','trend','similar'] as const;
export type ComplaintKind=typeof complaintKinds[number];
export const titles:Record<ComplaintKind,string>={stats:'최근 5개월 민원 추이',fields:'의정부시 민원 분야 구성',gender:'성별 민원 분야',age:'연령대별 민원 분야',df:'최다 민원 키워드 TOP 10',tfidf:'핵심 키워드 TOP 10',rising:'급등 키워드',topics:'오늘의 민원 이슈',reports:'민원 분석보고서',related:'연관어 분석',trend:'키워드 추이',similar:'관련 정책 Q&A'};
export function list(v:any):any[]{return v==null?[]:Array.isArray(v)?v:[v];}
export function parseComplaint(kind:ComplaintKind,json:any):ComplaintResult{
 if(json.OpenAPI_ServiceResponse)throw Error('제공기관 요청 조건 확인 중 · 마지막 데이터 날짜 미확인');
 const root=json.response??json,code=root.header?.resultCode;if(code!==undefined&&!['0','00','200','SUCCESS'].includes(String(code)))throw Error('제공기관 응답 오류');
 if(!root.body||!('items'in root.body))throw Error('응답 형식 확인 필요');
 const items=list(root.body.items?.item??root.body.items),rows:ComplaintRow[]=[];
 for(const i of items){if(!i||typeof i!=='object')continue;
  const children=i.classifications?list(i.classifications.classification).map((c:any)=>({name:String(c.label??''),value:Number(c.hits)})).filter((c:ComplaintRow)=>c.name&&Number.isFinite(c.value)&&c.value>=0):undefined;
  if(kind==='fields'){if(!String(i.keyword??'').includes('의정부'))continue;if(children)rows.push(...children);continue;}
  const name=String(i.keyword??i.label??i.term??i.topic??i.rptstNm??i.title??'');
  const value=Number(i.hits??i.df??i.count??i.value??(children?children.reduce((a:number,c:ComplaintRow)=>a+c.value,0):0));
  if(!name||!Number.isFinite(value)||value<0)continue;
  const rawDate=kind==='stats'||kind==='trend'?String(i.label):i.date?String(i.date):i.frstRegDt?String(i.frstRegDt):'';
  const date=/^\d{8,14}$/.test(rawDate)?rawDate.slice(0,8):undefined;
  const url=typeof i.fileUrlPdf==='string'&&/^https:\/\//.test(i.fileUrlPdf)?i.fileUrlPdf:undefined;
  rows.push({name,value,date,children,ratio:Number.isFinite(Number(i.prevRatio))?Number(i.prevRatio):undefined,url,content:kind==='similar'?String(i.content??'').replace(/<[^>]*>/g,'').slice(0,1000):undefined});
 }
 return {rows,error:null,checkedAt:new Date().toISOString(),latestDate:rows.map(r=>r.date).filter(Boolean).sort().at(-1)??null,empty:rows.length===0};
}
