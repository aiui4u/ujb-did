import type {WarningSnapshot} from './warnings';
import type {AirForecast,HighForecast,AirRow} from './air';
export type Values = Record<string, string>;
export type Hour = {at:string; values:Values; source:string};
export type Source = {ok:boolean; message:string; base:string|null};
export type WeatherData = {fetchedAt:string; warnings?:WarningSnapshot; storage?:{savedAt:string;failedSources:string[]}; collection?:{pending:boolean;lastStarted:string|null;lastFinished:string|null;message:string|null}; grid:{nx:number;ny:number;name:string}; current:Values; observedAt:string|null; hours:Hour[]; daily:{date:string;min:number|null;max:number|null;pop:number|null}[]; sources:{current:Source;ultra:Source;forecast:Source;air:Source;airForecast?:Source;high?:Source}; air:Record<string,string>|null; airHistory?:AirRow[]; airForecasts?:AirForecast[]; highForecasts?:HighForecast[]; airStation?:{name:string;address:string;area:string;requestedName?:string;fallbackReason?:string}; analysis?:{generatedAt:string;summary:string;coverage:{label:string;state:'used'|'partial'|'excluded';time:string|null;detail:string}[]}; notices:{title:string;body:string;level:string;action?:string;evidence?:string;priority?:number}[]};
export const kst = (date:Date) => new Date(date.getTime()+9*3600000);
const pad=(n:number)=>String(n).padStart(2,'0');
export function stamp(date:Date){return `${date.getUTCFullYear()}${pad(date.getUTCMonth()+1)}${pad(date.getUTCDate())}`;}
export function baseFor(kind:string,now:Date,back=0){
 const d=kst(now);
 if(kind==='getVilageFcst'){
  d.setUTCMinutes(d.getUTCMinutes()-15);
  const h=[23,20,17,14,11,8,5,2].find(h=>h<=d.getUTCHours());
  if(h===undefined){d.setUTCDate(d.getUTCDate()-1);d.setUTCHours(23,0,0,0);}else d.setUTCHours(h,0,0,0);
  d.setUTCHours(d.getUTCHours()-back*3);
 }else if(kind==='getUltraSrtFcst'){
  d.setUTCMinutes(d.getUTCMinutes()-45);d.setUTCMinutes(30,0,0);d.setUTCHours(d.getUTCHours()-back);
 }else{d.setUTCMinutes(d.getUTCMinutes()-40);d.setUTCMinutes(0,0,0);d.setUTCHours(d.getUTCHours()-back);}
 return {date:stamp(d),time:pad(d.getUTCHours())+pad(d.getUTCMinutes())};
}
export const at=(date:string,time:string)=>`${date.slice(0,4)}-${date.slice(4,6)}-${date.slice(6,8)}T${time.slice(0,2)}:${time.slice(2,4)}:00+09:00`;
export function number(v:unknown):number|null{if(v===undefined||v===null||v===''||v==='-'||!Number.isFinite(Number(v)))return null;return Number(v);}
export function condition(v:Values){const p=number(v.PTY);if(p!==null&&p!==0)return ({1:'비',2:'비·눈',3:'눈',4:'소나기',5:'빗방울',6:'빗방울·눈날림',7:'눈날림'} as Record<number,string>)[p]??'강수';return ({1:'맑음',3:'구름 많음',4:'흐림'} as Record<number,string>)[Number(v.SKY)]??'하늘상태 확인 중';}
export function advice(data:WeatherData,now:Date){
 const notices:WeatherData['notices']=[];
 const freshCurrent=data.observedAt&&now.getTime()-Date.parse(data.observedAt)<2*3600000;
 const current=freshCurrent?data.current:{};
 const hours=data.hours.filter(h=>Date.parse(h.at)>=now.getTime()&&Date.parse(h.at)<now.getTime()+24*3600000);
 const nextRain=hours.find(h=>(number(h.values.PTY)??0)>0||(number(h.values.POP)??0)>=60);
 if(nextRain)notices.push({title:'우산을 준비하세요',body:`${new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',month:'numeric',day:'numeric',hour:'numeric'}).format(new Date(nextRain.at))} ${condition(nextRain.values)} 또는 강수 가능성이 높게 예보되어 있습니다. 외출 전 최신 예보를 확인하세요.`,level:'watch'});
 const temps=hours.map(h=>number(h.values.TMP??h.values.T1H)).filter((v):v is number=>v!==null);
 const today=stamp(kst(now)),day=data.daily.find(d=>d.date===today);
 if(day?.min!==null&&day?.max!==null&&day&&day.max-day.min>=10)notices.push({title:'큰 일교차에 대비하세요',body:`오늘 예보 최저 ${day.min}° · 최고 ${day.max}°. 아침·저녁에는 겉옷을 준비하세요.`,level:'info'});
 const winds=[number(current.WSD),...hours.map(h=>number(h.values.WSD))].filter((v):v is number=>v!==null);
 if(winds.some(v=>v>=9))notices.push({title:'강한 바람에 주의하세요',body:'실황 또는 향후 24시간 예보에서 풍속 9m/s 이상이 확인됩니다. 야외 설치물을 점검하고 바람이 강한 곳에서 주의하세요.',level:'watch'});
 if(temps.some(t=>t>=33)||(number(current.T1H)??-99)>=33)notices.push({title:'더운 시간대 야외활동 주의',body:'기온 33°C 이상인 시간대가 있습니다. 야외활동 시 그늘에서 쉬고 물을 충분히 드세요.',level:'watch'});
 if(temps.some(t=>t<=0)||(number(current.T1H)??99)<=0)notices.push({title:'영하 기온·미끄럼 주의',body:'영하 기온이 관측되거나 예보되어 있습니다. 젖은 도로와 그늘진 보행로가 얼 수 있으니 주의하세요.',level:'watch'});
 if((number(current.RN1)??0)>=10)notices.push({title:'현재 강수량 증가',body:'1시간 강수량이 10mm 이상입니다. 하천변·지하차도 등은 현장 통제 안내를 확인하세요.',level:'watch'});
 if((number(current.REH)??100)<=30)notices.push({title:'건조한 공기·화기 주의',body:'현재 상대습도가 30% 이하입니다. 산 주변에서 화기를 사용하지 말고 불씨를 주의하세요.',level:'info'});
 if(data.air&&Date.parse(data.air.dataTime?.replace(' ','T')+'+09:00')>now.getTime()-3*3600000){
  if(['3','4'].includes(data.air.pm10Grade1h)||['3','4'].includes(data.air.pm25Grade1h))notices.push({title:'미세먼지 나쁨 이상',body:'측정소에서 제공한 현재 미세먼지 등급이 나쁨 이상입니다. 어린이·어르신은 장시간 야외활동을 줄이세요.',level:'watch'});
  if(['3','4'].includes(data.air.o3Grade))notices.push({title:'오존 농도 주의',body:'측정소에서 제공한 오존 등급이 나쁨 이상입니다. 한낮의 장시간 야외활동을 줄이세요.',level:'watch'});
 }
 if(!notices.length)notices.push({title:hours.length?'외출 전 최신 예보 확인':'기상자료 연결 확인 중',body:hours.length?'시간대별 기온과 강수확률을 확인하고 외출을 준비하세요. 지역·시간에 따라 실제 날씨는 달라질 수 있습니다.':'자료가 연결되면 예보에 따른 시민 안내가 자동으로 표시됩니다. 현재 날씨는 기상청 날씨누리를 확인하세요.',level:'info'});
 return notices;
}
