import {POP_REGIONS,numeric,type RawRow} from './population';
export type HouseholdSizeRow={id:string;name:string;total:number;sizes:number[]};
export type HouseholdSizeData={month:string;regions:HouseholdSizeRow[];savedAt?:string;error?:string;stale?:boolean};
const clean=(s:string)=>s.replace(/[\s()·_]/g,'');
export function normalizeHouseholdSizes(rows:RawRow[],month:string,fields:Record<string,string>={}):HouseholdSizeRow[]{
 const result=new Map<string,HouseholdSizeRow>();
 for(const raw of rows){
  const row=Object.fromEntries(Object.entries(raw).map(([k,v])=>[k.trim(),v]));
  const find=(aliases:string[],labels:string[])=>{const described=Object.entries(fields).find(([,v])=>labels.includes(clean(v)))?.[0]?.trim();return described&&described in row?row[described]:row[aliases.find(k=>k in row)??''];};
  const rowMonth=String(find(['statsYm','statsYymm'],['통계년월'])??'').replace(/\D/g,'');if(rowMonth!==month)throw Error('요청 기준월과 세대 자료의 기준월이 다릅니다.');
  const city=String(find(['sggNm'],['시군구명'])??'');if(city&&city!=='의정부시')continue;
  const code=String(find(['admmCd','admmInstCd'],['행정기관코드'])??'');const dong=String(find(['dongNm','admmNm'],['행정동명'])??'');
  const region=POP_REGIONS.find(r=>r.id===code||r.name===dong)||(code==='4115000000'?POP_REGIONS[0]:undefined);if(!region)continue;
  // Query level 3 returns dong totals. Never add tong/ban subtotals to them.
  if(['tong','ban','tongNo','banNo'].some(k=>row[k]!==undefined&&!/^(|0+|계|합계|전체)$/.test(String(row[k]).trim())))throw Error('동 총계 대신 통·반 자료가 수신되어 집계를 보류합니다.');
  const total=numeric(find(['hhCnt','totHhCnt','totalHhCnt'],['전체세대수','총세대수','세대수']));
  const sizes=Array.from({length:10},(_,i)=>{const n=i+1;const aliases=[`hhMbr${n}HhCnt`,`hhMbr${n}Cnt`,`hsmb${n}HhCnt`,`hsmb${n}Cnt`,`hh${n}Cnt`,`${n}psnHhCnt`,`psn${n}HhCnt`,`hhMbr${n}AbvHhCnt`];return numeric(find(aliases,n===10?['10인세대이상','10인이상세대수','10인이상세대','10인세대','10인세대수']: [`${n}인세대`,`${n}인세대수`]));});
  if(total===null||sizes.some(v=>v===null))throw Error('세대원수별 수치 항목을 확인하고 있습니다.');
  const counts=sizes as number[];if(counts.reduce((s,v)=>s+v,0)!==total)throw Error('세대원수별 합계와 전체 세대수가 일치하지 않아 표시를 보류합니다.');
  const value={id:region.id,name:region.name,total,sizes:counts};const prev=result.get(region.id);if(prev&&JSON.stringify(prev)!==JSON.stringify(value))throw Error('동별 세대 자료가 중복되어 집계를 보류합니다.');result.set(region.id,value);
 }
 const dongs=POP_REGIONS.filter(r=>r.id!=='city').map(r=>result.get(r.id));if(dongs.some(r=>!r))throw Error('15개 동의 세대 자료가 모두 수신되지 않았습니다.');
 const total=dongs.reduce((s,r)=>s+r!.total,0),sizes=Array.from({length:10},(_,i)=>dongs.reduce((s,r)=>s+r!.sizes[i],0));const official=result.get('city');if(official&&(official.total!==total||official.sizes.some((v,i)=>v!==sizes[i])))throw Error('시 전체와 동별 세대수 합계가 일치하지 않습니다.');
 return [{id:'city',name:'의정부시 전체',total,sizes},...dongs as HouseholdSizeRow[]];
}
