import {REGIONS} from './regions';
export const POP_REGIONS=[{id:'city',name:'의정부시 전체'},...REGIONS.filter(r=>r.id!=='city')];
export type PopulationRow={id:string;name:string;population:number;households:number;male:number;female:number;tongCount:number;banCount:number;areas:{tong:string;ban:string;population:number;households:number;male:number;female:number}[]};
export type PopulationMonth={month:string;regions:PopulationRow[];complete:boolean;notes:string[]};
export type AgeGroup={label:string;inflow:number;outflow:number};
export type MigrationRegion={id:string;inflow:number;outflow:number;internalIn:number;internalOut:number;maleIn:number;maleOut:number;femaleIn:number;femaleOut:number;ages:AgeGroup[];origins:{name:string;count:number}[];destinations:{name:string;count:number}[]};
export type MigrationMonth={month:string;regions:MigrationRegion[];ageComplete:boolean;complete:boolean};
export type PopulationData={population:PopulationMonth[];migration:MigrationMonth[];collectedAt:string|null;populationSavedAt:string|null;migrationSavedAt:string|null;pending:boolean;errors:string[];progress?:{done:number;total:number;phase:string;rows?:number;totalRows?:number};contract?:{population:string[];migration:string[]}};
export type RawRow=Record<string,unknown>;
export type FieldMap=Record<string,string>;
export const emptyPopulation=():PopulationData=>({population:[],migration:[],collectedAt:null,populationSavedAt:null,migrationSavedAt:null,pending:false,errors:[]});
export function numeric(v:unknown){if(v===null||v===undefined||String(v).trim()===''||String(v)==='-')return null;const n=Number(String(v).replaceAll(',',''));return Number.isFinite(n)&&n>=0?n:null;}
function value(row:RawRow,map:FieldMap,name:string){return row[map[name]??name];}
function str(row:RawRow,map:FieldMap,name:string){return String(value(row,map,name)??'').trim();}
function num(row:RawRow,map:FieldMap,name:string){return numeric(value(row,map,name));}
export function monthOffset(month:string,offset:number){const d=new Date(Date.UTC(Number(month.slice(0,4)),Number(month.slice(4,6))-1+offset,1));return `${d.getUTCFullYear()}${String(d.getUTCMonth()+1).padStart(2,'0')}`;}
export function recentMonths(now=new Date(),count=3){const d=new Date(now.getTime()+9*3600000);const month=`${d.getUTCFullYear()}${String(d.getUTCMonth()+1).padStart(2,'0')}`;return Array.from({length:count},(_,i)=>monthOffset(month,-i-1));}
export function normalizePopulation(rows:RawRow[],map:FieldMap):PopulationMonth[]{
 const months=new Map<string,Map<string,PopulationRow['areas']>>();
 const seen=new Map<string,string>();
 for(const row of rows){const month=str(row,map,'month').replace(/\D/g,'').slice(0,6);if(!/^\d{6}$/.test(month))throw Error('통계 기준월 확인 필요');
  const city=str(row,map,'city');const code=str(row,map,'code');if(city&&city!=='의정부시')continue;
  const name=str(row,map,'dong');const region=POP_REGIONS.find(r=>r.id===code||r.name===name)||(code==='4115000000'||(!name&&city==='의정부시')?POP_REGIONS[0]:undefined);if(!region)continue;
  const population=num(row,map,'population'),households=num(row,map,'households'),male=num(row,map,'male'),female=num(row,map,'female');
  if([population,households,male,female].some(n=>n===null)||male!+female! !==population)throw Error('인구·세대 수치 검증 필요');
  const tong=str(row,map,'tong'),ban=str(row,map,'ban');const key=[month,region.id,tong,ban].join('|');const body=JSON.stringify([population,households,male,female]);if(seen.has(key)){if(seen.get(key)!==body)throw Error('중복 통반 자료 검증 필요');continue;}seen.set(key,body);
  if(!months.has(month))months.set(month,new Map());const group=months.get(month)!;if(!group.has(region.id))group.set(region.id,[]);group.get(region.id)!.push({tong,ban,population:population!,households:households!,male:male!,female:female!});
 }
 return [...months].map(([month,groups])=>{
  const regions:PopulationRow[]=[];for(const [id,areas]of groups){const detailed=areas.filter(a=>a.tong&&!/^(0+|계|합계|전체)$/.test(a.tong));let chosen=areas;
   if(detailed.length){chosen=[];for(const tong of new Set(detailed.map(a=>a.tong))){const rows=detailed.filter(a=>a.tong===tong);const bans=rows.filter(a=>a.ban&&!/^(0+|계|합계|전체)$/.test(a.ban));chosen.push(...(bans.length?bans:rows.slice(0,1)));}}
   else chosen=areas.slice(0,1);
   const sums=chosen.reduce((s,a)=>({population:s.population+a.population,households:s.households+a.households,male:s.male+a.male,female:s.female+a.female}),{population:0,households:0,male:0,female:0});
   regions.push({id,name:POP_REGIONS.find(r=>r.id===id)!.name,...sums,tongCount:new Set(detailed.map(a=>a.tong)).size,banCount:chosen.filter(a=>a.ban&&!/^(0+|계|합계|전체)$/.test(a.ban)).length,areas:chosen});
  }
  const dongs=regions.filter(r=>r.id!=='city');const complete=dongs.length===15;const official=regions.find(r=>r.id==='city');const notes:string[]=[];
  if(!official&&complete){regions.unshift({id:'city',name:'의정부시 전체',...dongs.reduce((s,r)=>({population:s.population+r.population,households:s.households+r.households,male:s.male+r.male,female:s.female+r.female,tongCount:s.tongCount+r.tongCount,banCount:s.banCount+r.banCount}),{population:0,households:0,male:0,female:0,tongCount:0,banCount:0}),areas:[]});}
  if(official&&complete&&dongs.reduce((s,r)=>s+r.population,0)!==official.population)notes.push('시 전체와 동별 합계 차이 확인 필요');
  if(!complete)notes.push(`동별 자료 ${dongs.length}/15개 확보 · 누락 동은 0명으로 표시하지 않음`);
  return {month,regions,complete,notes};
 }).sort((a,b)=>b.month.localeCompare(a.month));
}
export type CompactFlow={month:string;from:string;to:string;fromName:string;toName:string;count:number;male:number;female:number;ages:{label:string;count:number}[];ageComplete:boolean};
export const AGE_GROUPS=[{label:'0–14세',from:0,to:14},{label:'15–19세',from:15,to:19},{label:'20–39세',from:20,to:39},{label:'40–64세',from:40,to:64},{label:'65세 이상',from:65,to:110}];
export function compactFlows(rows:RawRow[],map:FieldMap):CompactFlow[]{return rows.map(row=>{
 const month=str(row,map,'month').replace(/\D/g,'').slice(0,6),from=str(row,map,'fromCode'),to=str(row,map,'toCode');
 const count=num(row,map,'population'),male=num(row,map,'male'),female=num(row,map,'female');if(!/^\d{6}$/.test(month)||!from||!to||[count,male,female].some(n=>n===null)||male!+female! !==count)throw Error('인구이동 수치·행정기관 확인 필요');
 let ageComplete=true;const ages=AGE_GROUPS.map(group=>{let sum=0;for(let age=group.from;age<=group.to;age++)for(const sex of ['m','f']){const n=num(row,map,`age:${sex}:${age}`);if(n===null)ageComplete=false;else sum+=n;}return {label:group.label,count:sum};});
 if(ageComplete&&ages.reduce((s,a)=>s+a.count,0)!==count)ageComplete=false;
 const name=(side:'from'|'to')=>[str(row,map,`${side}Province`),str(row,map,`${side}City`),str(row,map,`${side}Dong`)].filter(Boolean).join(' ');
 return {month,from,to,fromName:name('from')||from,toName:name('to')||to,count:count!,male:male!,female:female!,ages,ageComplete};
});}
export function summarizeFlows(flows:CompactFlow[]):MigrationMonth[]{
 if(!flows.length)throw Error('의정부시 이동 자료 확인 필요 · 마지막 성공 자료 유지');
 const unique=new Map<string,CompactFlow>();for(const f of flows){const key=[f.month,f.from,f.to].join('|');const old=unique.get(key);if(old&&JSON.stringify(old)!==JSON.stringify(f))throw Error('중복 인구이동 자료 검증 필요');unique.set(key,f);}
 const months=[...new Set([...unique.values()].map(f=>f.month))];return months.map(month=>{
  const source=[...unique.values()].filter(f=>f.month===month);const regions=POP_REGIONS.map(region=>{
   const origins=new Map<string,number>(),destinations=new Map<string,number>();const r:MigrationRegion={id:region.id,inflow:0,outflow:0,internalIn:0,internalOut:0,maleIn:0,maleOut:0,femaleIn:0,femaleOut:0,ages:AGE_GROUPS.map(g=>({label:g.label,inflow:0,outflow:0})),origins:[],destinations:[]};
   for(const f of source){const inCity=f.to.startsWith('41150'),fromCity=f.from.startsWith('41150');const incoming=region.id==='city'?inCity&&!fromCity:f.to===region.id&&f.from!==region.id;const outgoing=region.id==='city'?fromCity&&!inCity:f.from===region.id&&f.to!==region.id;
    if(region.id==='city'&&inCity&&fromCity&&f.to!==f.from){r.internalIn+=f.count;r.internalOut+=f.count;}
    if(incoming){r.inflow+=f.count;r.maleIn+=f.male;r.femaleIn+=f.female;if(region.id!=='city'&&fromCity)r.internalIn+=f.count;origins.set(f.fromName,(origins.get(f.fromName)??0)+f.count);f.ages.forEach((a,i)=>r.ages[i].inflow+=a.count);}
    if(outgoing){r.outflow+=f.count;r.maleOut+=f.male;r.femaleOut+=f.female;if(region.id!=='city'&&inCity)r.internalOut+=f.count;destinations.set(f.toName,(destinations.get(f.toName)??0)+f.count);f.ages.forEach((a,i)=>r.ages[i].outflow+=a.count);}
   }
   const rank=(m:Map<string,number>)=>[...m].map(([name,count])=>({name,count})).sort((a,b)=>b.count-a.count).slice(0,8);r.origins=rank(origins);r.destinations=rank(destinations);return r;
  });return {month,regions,ageComplete:source.every(f=>f.ageComplete),complete:true};
 }).sort((a,b)=>b.month.localeCompare(a.month));
}
export function indicators(data:PopulationData,id:string,month:string){
 const current=data.population.find(m=>m.month===month)?.regions.find(r=>r.id===id),previous=data.population.find(m=>m.month===monthOffset(month,-1))?.regions.find(r=>r.id===id),city=data.population.find(m=>m.month===month)?.regions.find(r=>r.id==='city');
 const migration=data.migration.find(m=>m.month===month&&m.complete)?.regions.find(r=>r.id===id);const change=current&&previous?current.population-previous.population:null;const net=migration?migration.inflow-migration.outflow:null;
 return {current,previous,city,migration,change,net,changeRate:change!==null&&previous?.population?change/previous.population*100:null,householdChange:current&&previous?current.households-previous.households:null,perHousehold:current?.households?current.population/current.households:null,femaleShare:current?.population?current.female/current.population*100:null,sexRatio:current?.female?current.male/current.female*100:null,cityShare:current&&city?.population?current.population/city.population*100:null,netPerThousand:net!==null&&current?.population?net/current.population*1000:null,mobilityRate:migration&&current?.population?(migration.inflow+migration.outflow)/current.population*100:null,residual:change!==null&&net!==null?change-net:null};
}
export function populationInsights(data:PopulationData,id:string,month:string){const d=indicators(data,id,month),name=POP_REGIONS.find(r=>r.id===id)?.name??'선택 지역';const notes:{title:string;body:string}[]=[];
 if(d.change!==null)notes.push({title:'이번 달 인구 변화',body:`${name}는 전월보다 ${Math.abs(d.change).toLocaleString('ko-KR')}명 ${d.change>0?'증가':d.change<0?'감소':'변동 없음'}했습니다.${d.changeRate!==null?` 변화율은 ${d.changeRate.toFixed(2)}%입니다.`:''}`});
 if(d.net!==null)notes.push({title:'전입과 전출의 균형',body:`전입 ${d.migration!.inflow.toLocaleString('ko-KR')}명, 전출 ${d.migration!.outflow.toLocaleString('ko-KR')}명으로 ${d.net>0?'순유입':d.net<0?'순유출':'순이동 없음'} ${Math.abs(d.net).toLocaleString('ko-KR')}명입니다.`});
 if(d.current&&d.householdChange!==null&&d.change!==null&&d.householdChange>0&&d.change<=0)notes.push({title:'인구와 세대 변화의 차이',body:`전월 대비 인구는 ${d.change<0?`${Math.abs(d.change).toLocaleString('ko-KR')}명 감소했고`:'같은 수준이며'}, 세대는 ${d.householdChange.toLocaleString('ko-KR')}세대 늘었습니다. 세대 증가에 맞춰 주민 대상 생활정보와 행정서비스 안내를 준비할 수 있습니다.`});
 if(d.perHousehold!==null)notes.push({title:'생활서비스 계획에 참고',body:`세대당 평균 ${d.perHousehold.toFixed(2)}명입니다. 세대 규모와 이동량을 민원 안내·생활정보 전달 계획에 함께 참고할 수 있습니다.`});
 const m=data.migration.find(m=>m.month===month);if(m?.ageComplete&&d.migration){const top=[...d.migration.ages].sort((a,b)=>(b.inflow+b.outflow)-(a.inflow+a.outflow))[0];if(top&&top.inflow+top.outflow>0)notes.push({title:'이동이 활발한 연령대',body:`${top.label}의 이동은 전입 ${top.inflow.toLocaleString('ko-KR')}명·전출 ${top.outflow.toLocaleString('ko-KR')}명입니다. 해당 연령대의 전입 주민에게 교통·주거·복지 등 생활정보를 안내하는 데 활용할 수 있습니다.`});}
 if(d.residual!==null)notes.push({title:'인구 증감과 순이동을 함께 읽기',body:`인구 증감에서 순이동을 뺀 차이는 ${d.residual.toLocaleString('ko-KR')}명입니다.`});
 if(!notes.length)notes.push({title:'확인된 자료로 분석합니다',body:'자료 수집이 완료되면 인구 변화와 이동 흐름을 계산합니다.'});return notes;
}
