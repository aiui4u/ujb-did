import { XMLParser, XMLValidator } from 'fast-xml-parser';

export const NEWS_FEED_URL = 'https://news.google.com/rss/search?q=%EC%9D%98%EC%A0%95%EB%B6%80%EC%8B%9C%20when%3A7d&hl=ko&gl=KR&ceid=KR:ko';
export const PRESS_FEED_URL = 'https://www.ui4u.go.kr/portal/rssservice/RssServiceDetail.do?rssId=10000000000000000003';
export const PRESS_LIST_URL = 'https://www.ui4u.go.kr/portal/bbs/list.do?mId=0301020000&ptIdx=1709';
export const NEWS_REFRESH_MS = 60 * 60 * 1000;
export const NEWS_ARTICLE_LIMIT = 150;
export type NewsFeedKind = 'news' | 'press';
export type NewsArticle = { id: string; title: string; source: string; publishedAt: string; url: string; relatedCount: number };
export type NewsFeedSnapshot = { articles: NewsArticle[]; collectedAt: string | null; lastAttemptAt: string | null; error: string | null; pending?: boolean };
export type NewsSnapshot = NewsFeedSnapshot & { press?: NewsFeedSnapshot };
export const emptyNews = (): NewsSnapshot => ({ articles: [], collectedAt: null, lastAttemptAt: null, error: null });
const DAY = 86400000;
function text(value: unknown): string {
  const s = typeof value === 'object' && value !== null ? String((value as Record<string, unknown>)['#text'] ?? '') : String(value ?? '');
  return s.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/\s+/g, ' ').trim();
}
export function safeNewsUrl(value: unknown): string | null {
  try { const url = new URL(String(value)); return url.protocol === 'https:' && url.hostname === 'news.google.com' && !url.username && !url.password && /^\/(rss\/)?articles\//.test(url.pathname) ? url.href : null; } catch { return null; }
}
export function safePressUrl(value: unknown): string | null {
  try { const url = new URL(String(value), 'https://www.ui4u.go.kr');
    if (!['http:', 'https:'].includes(url.protocol) || !['ui4u.go.kr','www.ui4u.go.kr'].includes(url.hostname) || url.username || url.password || !url.pathname.startsWith('/portal/')) return null;
    url.protocol = 'https:'; return url.href;
  } catch { return null; }
}
function articleId(url: string): string {
  let a = 2166136261, b = 5381;
  for (const c of url) { a = Math.imul(a ^ c.charCodeAt(0), 16777619); b = Math.imul(b, 33) ^ c.charCodeAt(0); }
  return (a >>> 0).toString(16).padStart(8, '0') + (b >>> 0).toString(16).padStart(8, '0');
}
export function recentArticles(articles: NewsArticle[], now = Date.now()) {
  return articles.filter(a => { const date = Date.parse(a.publishedAt); return Number.isFinite(date) && date >= now - 7 * DAY && date <= now + 15 * 60000; }).sort((a, b) => Date.parse(b.publishedAt) - Date.parse(a.publishedAt));
}
export function mergeNewsArticles(incoming: NewsArticle[], saved: NewsArticle[], now = Date.now()) {
  const unique = new Map<string, NewsArticle>();
  for (const article of [...incoming, ...saved]) if (!unique.has(article.url)) unique.set(article.url, article);
  return recentArticles([...unique.values()], now).slice(0, NEWS_ARTICLE_LIMIT);
}
function tokens(title: string) { return new Set(title.toLowerCase().replace(/[^가-힣a-z0-9\s]/g, ' ').split(/\s+/).filter(s => s.length > 1)); }
function similar(a: string, b: string) {
  const normalize = (v: string) => v.replace(/[^가-힣a-zA-Z0-9]/g, '').toLowerCase();
  if (normalize(a) === normalize(b)) return true;
  const x = tokens(a), y = tokens(b);
  if (Math.min(x.size, y.size) < 5) return false;
  const intersection = [...x].filter(t => y.has(t)).length;
  return intersection / (x.size + y.size - intersection) >= .72;
}
export function parseNewsFeed(xml: string, now = Date.now(), kind: NewsFeedKind = 'news'): NewsArticle[] {
  if (XMLValidator.validate(xml) !== true) throw Error('뉴스 응답 형식을 확인하지 못했습니다.');
  const parsed = new XMLParser({ ignoreAttributes: false, trimValues: true, isArray: name => name === 'item' }).parse(xml);
  const channel = parsed?.rss?.channel;
  if (!channel || typeof channel !== 'object') throw Error('뉴스 목록 응답이 아닙니다.');
  const entries = channel.item ?? [];
  if (!Array.isArray(entries)) throw Error('뉴스 목록 형식을 확인하지 못했습니다.');
  const articles: NewsArticle[] = [];
  for (const entry of entries) {
    const source = kind === 'press' ? '의정부시 공식 보도자료' : text(entry.source) || '출처 미표기';
    let title = text(entry.title);
    if (source && title.endsWith(' - ' + source)) title = title.slice(0, -source.length - 3).trim();
    const url = (kind === 'press' ? safePressUrl : safeNewsUrl)(text(entry.link));
    const rawDate = text(entry.pubDate ?? entry['dc:date'] ?? entry.date);
    const dateOnly = rawDate.match(/^(\d{4})[.\/-](\d{1,2})[.\/-](\d{1,2})[.]?$/);
    const published = Date.parse(dateOnly ? `${dateOnly[1]}-${dateOnly[2].padStart(2,'0')}-${dateOnly[3].padStart(2,'0')}T00:00:00+09:00` : rawDate);
    if (!title || !url || !Number.isFinite(published) || (kind === 'news' && !/의정부/.test(title + ' ' + text(entry.description)))) continue;
    articles.push({ id: articleId(url), title, source, publishedAt: new Date(published).toISOString(), url, relatedCount: 0 });
  }
  // A nonempty feed with no readable item is a format failure, not proof of no news.
  if (entries.length && !articles.length) throw Error('뉴스 항목의 제목·날짜·링크 확인이 필요합니다.');
  const grouped: NewsArticle[] = [];
  const seen = new Set<string>();
  for (const article of recentArticles(articles, now)) {
    if (seen.has(article.url)) continue;
    seen.add(article.url);
    const match = kind === 'news' ? grouped.find(a => similar(a.title, article.title)) : undefined;
    if (match) match.relatedCount++; else grouped.push(article);
  }
  return grouped.slice(0, NEWS_ARTICLE_LIMIT);
}

// Today and the two preceding calendar dates in Korea.
export function recentPressArticles(articles: NewsArticle[], now = Date.now()) {
  const koreaDay = Math.floor((now + 9 * 3600000) / DAY);
  const cutoff = (koreaDay - 2) * DAY - 9 * 3600000;
  return recentArticles(articles, now).filter(a => Date.parse(a.publishedAt) >= cutoff);
}
export function parsePressBoard(html: string, now = Date.now()): NewsArticle[] {
  const articles: NewsArticle[] = [];
  for (const row of html.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)) {
    const date = text(row[1]).match(/(20\d{2})[.\/-]\s*(\d{1,2})[.\/-]\s*(\d{1,2})/);
    if (!date) continue;
    for (const anchor of row[1].matchAll(/<a\b[^>]*href\s*=\s*(["'])([\s\S]*?)\1[^>]*>([\s\S]*?)<\/a>/gi)) {
      const url = safePressUrl(text(anchor[2]));
      if (!url || !/\/bbs\/view\.do$/.test(new URL(url).pathname)) continue;
      const title = text(anchor[3]).replace(/\s*(새글|새로운 글|첨부파일)\s*$/g, '').trim();
      if (!title) continue;
      const publishedAt = new Date(`${date[1]}-${date[2].padStart(2,'0')}-${date[3].padStart(2,'0')}T00:00:00+09:00`).toISOString();
      articles.push({id:articleId(url),title,source:'의정부시 공식 보도자료',publishedAt,url,relatedCount:0});
      break;
    }
  }
  if (!articles.length) throw Error('press_board_unrecognized');
  return recentPressArticles([...new Map(articles.map(a => [a.url,a])).values()], now);
}
export async function fetchPressBoard(): Promise<NewsArticle[]> {
  const articles: NewsArticle[] = [];
  for (let page = 1; page <= 5; page++) {
    const url = new URL(PRESS_LIST_URL); url.searchParams.set('page', String(page));
    const response = await fetch(url, {headers:{Accept:'text/html'},signal:AbortSignal.timeout(15000)});
    if (!response.ok) throw Error('press_board_http_' + response.status);
    const html = await response.text();
    if (html.length > 3000000) throw Error('press_board_too_large');
    const batch = parsePressBoard(html);
    articles.push(...batch);
    if (!batch.length) break;
  }
  return [...new Map(articles.map(a => [a.url,a])).values()].sort((a,b)=>Date.parse(b.publishedAt)-Date.parse(a.publishedAt));
}
