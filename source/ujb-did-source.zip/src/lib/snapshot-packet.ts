import type {WeatherData} from './weather';
type RegionMeta={index:number;grid:WeatherData['grid'];fetchedAt:string;storage:WeatherData['storage']};
export type SnapshotPacket={payloads:Omit<WeatherData,'grid'|'fetchedAt'|'storage'>[];regions:Record<string,RegionMeta>};
// Adjacent dongs often share the same weather grid and air station. Transfer the shared body once.
export function packSnapshots(snapshots:Record<string,WeatherData>):SnapshotPacket{
 const packet:SnapshotPacket={payloads:[],regions:{}};const indices=new Map<string,number>();
 for(const [id,data] of Object.entries(snapshots)){const {grid,fetchedAt,storage,...body}=data;const signature=JSON.stringify(body);let index=indices.get(signature);if(index===undefined){index=packet.payloads.length;indices.set(signature,index);packet.payloads.push(body);}packet.regions[id]={index,grid,fetchedAt,storage};}
 return packet;
}
export function unpackSnapshots(packet:SnapshotPacket):Record<string,WeatherData>{return Object.fromEntries(Object.entries(packet.regions).map(([id,{index,...meta}])=>[id,{...packet.payloads[index],...meta}]));}
