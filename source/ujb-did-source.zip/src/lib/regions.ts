// Source: KMA Weather Nuri administrative-dong list, retrieved 2026-10-07.
// https://www.weather.go.kr/w/rest/zone/dong.do?type=DONG&wideCode=4100000000&cityCode=4115000000
export const REGIONS = [
  {
    "id": "city",
    "name": "의정부시",
    "nx": 61,
    "ny": 130
  },
  {
    "id": "4115051000",
    "name": "의정부1동",
    "nx": 61,
    "ny": 131
  },
  {
    "id": "4115052000",
    "name": "의정부2동",
    "nx": 61,
    "ny": 130
  },
  {
    "id": "4115054500",
    "name": "호원1동",
    "nx": 61,
    "ny": 130
  },
  {
    "id": "4115055500",
    "name": "호원2동",
    "nx": 61,
    "ny": 130
  },
  {
    "id": "4115056100",
    "name": "장암동",
    "nx": 61,
    "ny": 130
  },
  {
    "id": "4115056700",
    "name": "신곡1동",
    "nx": 61,
    "ny": 130
  },
  {
    "id": "4115056800",
    "name": "신곡2동",
    "nx": 61,
    "ny": 131
  },
  {
    "id": "4115057300",
    "name": "송산1동",
    "nx": 62,
    "ny": 130
  },
  {
    "id": "4115063000",
    "name": "고산동",
    "nx": 62,
    "ny": 130
  },
  {
    "id": "4115057600",
    "name": "송산2동",
    "nx": 62,
    "ny": 130
  },
  {
    "id": "4115057800",
    "name": "송산3동",
    "nx": 62,
    "ny": 131
  },
  {
    "id": "4115058000",
    "name": "자금동",
    "nx": 61,
    "ny": 131
  },
  {
    "id": "4115059500",
    "name": "가능동",
    "nx": 61,
    "ny": 131
  },
  {
    "id": "4115061500",
    "name": "흥선동",
    "nx": 61,
    "ny": 131
  },
  {
    "id": "4115062000",
    "name": "녹양동",
    "nx": 61,
    "ny": 131
  }
] as const;
export type Region = (typeof REGIONS)[number];
export const DEFAULT_REGION=REGIONS[0];
export function findRegion(id:string){return REGIONS.find(r=>r.id===id);}

// Airkorea station list verified 2026-10-07. These are service-area mappings, not dong measurements.
export const AIR_STATIONS={
 '의정부1동':{address:'의정부시 가능로152번길 14 의정부1동 작은도서관',area:'도심 북부·서부 생활권'},
 '의정부동':{address:'의정부시 범골로 138 경기도도로사업소',area:'도심·남부 생활권'},
 '송산3동':{address:'의정부시 민락로243번길 94 푸른마당 근린공원 인근',area:'송산·고산 생활권'}
} as const;
export function stationForRegion(region:Region):keyof typeof AIR_STATIONS{
 if(['송산1동','송산2동','송산3동','고산동'].includes(region.name))return '송산3동';
 if(['의정부1동','신곡2동','자금동','가능동','흥선동','녹양동'].includes(region.name))return '의정부1동';
 return '의정부동';
}
