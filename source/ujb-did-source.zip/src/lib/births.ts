import {monthOffset,type PopulationMonth,type PopulationData} from './population';
export type BirthData={months:PopulationMonth[];savedAt:string|null;checkedAt:string|null;error:string|null;pending:boolean};
export const emptyBirths=():BirthData=>({months:[],savedAt:null,checkedAt:null,error:null,pending:false});
export function birthIndicators(data:BirthData,population:PopulationData,id:string,month:string){
 const row=(m:string)=>data.months.find(x=>x.month===m)?.regions.find(x=>x.id===id);
 const current=row(month),previous=row(monthOffset(month,-1)),lastYear=row(monthOffset(month,-12));
 const cumulative=(year:number)=>{const list=Array.from({length:Number(month.slice(4))},(_,i)=>row(`${year}${String(i+1).padStart(2,'0')}`));return list.every(Boolean)?list.reduce((n,r)=>n+r!.population,0):null;};
 const total=cumulative(Number(month.slice(0,4))),priorTotal=cumulative(Number(month.slice(0,4))-1);
 const pop=population.population.find(x=>x.month===month)?.regions.find(x=>x.id===id);
 const change=current&&previous?current.population-previous.population:null,yoy=current&&lastYear?current.population-lastYear.population:null;
 return {current,previous,lastYear,change,yoy,total,priorTotal,cumulativeChange:total!==null&&priorTotal!==null?total-priorTotal:null,rate:current&&pop?.population?current.population/pop.population*1000:null,pop};
}
