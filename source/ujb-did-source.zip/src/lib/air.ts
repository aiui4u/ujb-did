import {number,type WeatherData} from './weather';
export type AirRow=Record<string,string>;
export type AirForecast={date:string;issuedAt:string;code:string;grade:string;region:string;overall:string;cause:string;action:string};
export type HighForecast={date:string;issuedAt:string;region:string;over50:boolean|null;grade:string;cause:string};
export function airTimestamp(value:string|undefined){if(!value)return null;const date=Date.parse(value.replace(' ','T')+'+09:00');return Number.isFinite(date)?date:null;}
export function issuedTimestamp(value:string){const m=value.match(/(\d{4}-\d{2}-\d{2})\s+(\d{1,2})(?::(\d{2}))?/);return m?Date.parse(`${m[1]}T${m[2].padStart(2,'0')}:${m[3]??'00'}:00+09:00`):0;}
export function metricValue(row:AirRow|null|undefined,code:string){if(!row||row[code+'Flag'])return null;return number(row[code+'Value']);}
export function airGrade(row:AirRow|null|undefined,code:string){if(metricValue(row,code)===null)return null;const value=row?.[code+(code==='pm10'||code==='pm25'?'Grade1h':'Grade')];return ['1','2','3','4'].includes(String(value))?Number(value):null;}
export const gradeLabel=(grade:unknown)=>({'1':'좋음','2':'보통','3':'나쁨','4':'매우 나쁨'} as Record<string,string>)[String(grade)]??'자료 없음';
function regionalGrade(text:string){const pairs=text.split(/[,，]/).map(s=>s.trim());for(const name of ['경기북부','경기','경기도']){const pair=pairs.find(s=>s.split(':')[0]?.trim()===name);if(pair)return {region:name,grade:pair.slice(pair.indexOf(':')+1).trim()};}return {region:'경기북부',grade:'자료 없음'};}
function forecastDate(row:AirRow){const raw=row.informData??row.fcstDate??row.forecastDate??'';const m=raw.match(/\d{4}-\d{2}-\d{2}/);return m?.[0]??(/^\d{8}$/.test(raw)?`${raw.slice(0,4)}-${raw.slice(4,6)}-${raw.slice(6,8)}`:'');}
export function normalizeForecasts(rows:AirRow[],today:string){const map=new Map<string,AirForecast>();for(const row of rows){const date=forecastDate(row);if(!date||date<today||!['PM10','PM25','O3'].includes(row.informCode))continue;const code=row.informCode,regional=regionalGrade(row.informGrade??'');const entry={date,issuedAt:row.dataTime??'',code,...regional,overall:row.informOverall??row.infornOverall??'',cause:row.informCause??'',action:row.actionKnack??''};const old=map.get(date+code);if(!old||issuedTimestamp(entry.issuedAt)>issuedTimestamp(old.issuedAt))map.set(date+code,entry);}return [...map.values()].sort((a,b)=>a.date.localeCompare(b.date)||a.code.localeCompare(b.code));}
export function normalizeHigh(rows:AirRow[],today:string){const map=new Map<string,HighForecast>();for(const row of rows){const date=forecastDate(row);if(!date||date<today)continue;const flag=(row.gyeonggibuk50Over??'').trim().toUpperCase();const entry:HighForecast={date,issuedAt:row.dataTime??'',region:'경기북부',over50:flag==='O'?true:flag==='X'||(Object.prototype.hasOwnProperty.call(row,'gyeonggibuk50Over')&&row.gyeonggibuk50Over===null)?false:null,grade:row.gyeonggibukGrade??'자료 없음',cause:row.informCause??row.informOverall??''};const old=map.get(date);if(!old||issuedTimestamp(entry.issuedAt)>issuedTimestamp(old.issuedAt))map.set(date,entry);}return [...map.values()].sort((a,b)=>a.date.localeCompare(b.date));}
export function combinedAdvice(data:WeatherData,now:Date){
 const notices:WeatherData['notices']=[];const air=data.air;const airAt=airTimestamp(air?.dataTime);const usable=air&&['pm10','pm25','o3','no2','co','so2'].some(code=>metricValue(air,code)!==null);const fresh=Boolean(usable)&&airAt!==null&&now.getTime()-airAt>=-3600000&&now.getTime()-airAt<3*3600000;
 const weatherFresh=data.observedAt&&now.getTime()-Date.parse(data.observedAt)<2*3600000;
 const high=data.highForecasts?.filter(x=>x.over50===true&&issuedTimestamp(x.issuedAt)>now.getTime()-36*3600000)??[];
 if(high.length)notices.push({title:'고농도 초미세먼지 전망에 대비하세요',body:`${high.map(x=>x.date.slice(5)).join('·')} 경기북부에서 초미세먼지 50㎍/㎥ 초과가 예보되었습니다. 민감군은 장시간 실외활동을 줄이고, 야외 일정은 최신 예보를 확인해 조정하세요. 비상저감조치 발령 여부는 별도 공지를 확인하세요.`,level:'watch'});
 const badNow=fresh&&['pm10','pm25'].some(code=>(airGrade(air,code)??0)>=3);
 const badOzone=fresh&&(airGrade(air,'o3')??0)>=3;
 if(badNow)notices.push({title:'미세먼지·야외활동 주의',body:`${air?.stationName} 측정소의 현재 먼지 등급이 나쁨 이상입니다. 어린이·어르신·호흡기 민감군은 장시간 실외활동을 줄이고, 환기는 최신 농도를 확인해 짧게 하세요.`,level:'watch'});
 if(badOzone)notices.push({title:'오존이 높은 시간대 활동 조정',body:`${air?.stationName} 측정소의 현재 오존 등급이 나쁨 이상입니다. 한낮의 장시간 야외활동을 줄이고 실내에서 쉬세요.`,level:'watch'});
 const badFuture=data.airForecasts?.filter(x=>['나쁨','매우나쁨','매우 나쁨'].includes(x.grade)&&issuedTimestamp(x.issuedAt)>now.getTime()-36*3600000)??[];
 if(badFuture.length)notices.push({title:'앞으로의 대기질을 확인하세요',body:`${badFuture.slice(0,3).map(x=>`${x.date.slice(5)} ${x.code==='PM25'?'초미세먼지':x.code==='PM10'?'미세먼지':'오존'} ${x.grade}`).join(' · ')} (${badFuture[0].region} 권역 예보). 야외 행사·운동 계획은 당일 측정값도 함께 확인하세요.`,level:'watch'});
 if(fresh&&weatherFresh){
  const pm25=metricValue(air,'pm25'),temp=number(data.current.T1H),wind=number(data.current.WSD),rain=number(data.current.RN1);
  const facts=[temp===null?null:`기온 ${temp}°C`,wind===null?null:`풍속 ${wind}m/s`,pm25===null?'초미세먼지 측정자료 없음':`초미세먼지 ${pm25}㎍/㎥`].filter(Boolean).join(' · ');
  const nextRain=data.hours.find(x=>Date.parse(x.at)>=now.getTime()&&Date.parse(x.at)<now.getTime()+12*3600000&&((number(x.values.PTY)??0)>0||(number(x.values.POP)??0)>=60));
  const text=badNow||badOzone?'대기질을 우선 고려해 야외활동 시간을 줄이세요.':rain!==null&&rain>0||nextRain?'대기질과 함께 강수 예보도 확인하고, 우산과 미끄럼에 대비하세요.':wind!==null&&wind>=9?'대기질과 함께 강한 바람에도 대비해 야외 설치물과 이동 경로를 확인하세요.':'외출 전 시간대별 기온·강수와 최신 대기질을 함께 확인하세요.';
  notices.push({title:'날씨·대기질 종합 생활안내',body:`${facts}. ${text} 대기질은 ${air?.stationName} 측정소 기준입니다.`,level:badNow||badOzone?'watch':'info'});
 }
 const pmForecast=data.airForecasts?.find(f=>f.code==='PM25'&&f.date===new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(now)&&issuedTimestamp(f.issuedAt)>now.getTime()-36*3600000);
 if(pmForecast&&!badFuture.length)notices.push({title:'오늘의 날씨·대기질 전망',body:`${pmForecast.region}의 오늘 초미세먼지 예보는 '${pmForecast.grade}'입니다. ${data.notices.find(n=>n.title==='큰 일교차에 대비하세요')?.body??'외출 전 시간대별 기온과 강수확률을 확인하세요.'} 권역 예보와 현재 측정농도는 서로 다를 수 있습니다.`,level:'info'});
 if(!fresh)notices.push({title:'대기질 최신 자료 확인 필요',body:air&&!usable?'측정소의 통신장애·점검 또는 결측으로 현재 대기질 수치를 확인할 수 없습니다. 측정값을 정상·안전으로 판단하지 않고 권역 예보와 날씨를 함께 확인하세요.':air?'대기측정 자료가 3시간 이상 지연되었거나 시각을 확인할 수 없어 최신 생활안내 분석에서 제외했습니다.':'현재 대기측정 자료를 확인하지 못했습니다. 날씨 안내와 함께 에어코리아의 최신 대기질도 확인하세요.',level:'info'});
 // Weather-only advice remains available; remove duplicate older pollution rules.
 notices.push(...data.notices.filter(n=>!['미세먼지 나쁨 이상','오존 농도 주의'].includes(n.title)));
 return notices;
}
