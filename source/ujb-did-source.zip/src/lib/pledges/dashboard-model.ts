import analytics from './plan-analytics.json';
import baseline from './official-plans.json';
import type {ProjectPlan} from './plan-model';
export const years=[2026,2027,2028,2029,2030];
export type PlanFilter='all'|'임기 내'|'임기 후'|'신규'|'계속'|'예산'|'비예산'|'미입력'|'year';
export const sourceFor=(p:ProjectPlan)=>analytics.find(d=>d.filename===p.source.split(' · ')[0]);
export function firstTargetYear(p:ProjectPlan):number|null{
 const doc=sourceFor(p);
 const original=baseline.find(a=>a.id===p.id);
 if(!doc||!original||p.annual.some((a,i)=>a.target!==original.annual[i]?.target))return p.annual.find(a=>a.target===100)?.year??null;
 const candidates=doc.schedule.filter(a=>a.target===100&&a.years.length===1).map(a=>a.years[0]);
 return candidates.length?Math.min(...candidates):null;
}
export const fundingLabels={national:'국비',provincial:'도비',municipal:'시비',other:'기타 재원'} as const;
export type FundingKey=keyof typeof fundingLabels;
export const fundingKeys=Object.keys(fundingLabels) as FundingKey[];
export function projectAnnualBudget(p:ProjectPlan,year:number){
 const result={total:0,national:0,provincial:0,municipal:0,other:0,groupedCount:0};
 const doc=sourceFor(p),original=baseline.find(a=>a.id===p.id);
 const edited=original&&p.annual.some((a,i)=>fundingKeys.some(k=>a[k]!==original.annual[i]?.[k]));
 if(doc&&!edited){
  const rows=doc.schedule.filter(a=>a.years.includes(year));
  if(rows.some(a=>a.years.length>1||a.sharedBudget))result.groupedCount=1;
  for(const a of rows.filter(a=>a.years.length===1&&!a.sharedBudget))for(const k of ['total',...fundingKeys] as const)result[k]+=a[k]??0;
 }else{
  const a=p.annual.find(a=>a.year===year);
  if(a)for(const k of fundingKeys){result[k]=a[k]??0;result.total+=a[k]??0;}
 }
 return result;
}
export function annualBudget(plans:ProjectPlan[],year:number){
 const sources=new Set<string>();const result={total:0,national:0,provincial:0,municipal:0,other:0,groupedCount:0};
 for(const p of plans){
  const key=sourceFor(p)?.filename??`id-${p.id}`;if(sources.has(key))continue;sources.add(key);
  const amount=projectAnnualBudget(p,year);
  for(const k of ['total',...fundingKeys,'groupedCount'] as const)result[k]+=amount[k];
 }
 return result;
}
export function matchesPlan(p:ProjectPlan,filter:PlanFilter,year:number){
 if(filter==='all')return true;if(filter==='year')return firstTargetYear(p)===year;
 if(filter==='미입력')return !p.completion;
 return [p.completion,p.category,p.budgetType].includes(filter);
}
