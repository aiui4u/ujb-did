import type {PlanFilter,FundingKey} from './dashboard-model';
export function projectWindowUrl(options:{filter?:PlanFilter;year?:number;dept?:string;view?:'departments';funding?:FundingKey}){
 const params=new URLSearchParams();if(options.funding)params.set('funding',options.funding);if(options.filter)params.set('filter',options.filter);if(options.year)params.set('year',String(options.year));if(options.dept)params.set('dept',options.dept);if(options.view)params.set('view',options.view);return `/ujb-did/pledges/projects?${params.toString()}`;
}
export function openProjectWindow(url:string){
 const popup=window.open(url,'_blank','popup=yes,width=1220,height=850,resizable=yes,scrollbars=yes');
 if(popup){popup.opener=null;popup.focus();return true;}return false;
}
