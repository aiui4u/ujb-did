import {numeric,POP_REGIONS,type RawRow} from './population';
export type ResidentAge={id:string;total:number;groups:{label:string;male:number;female:number}[];summary:{label:string;count:number}[]|null};
export function normalizeResidentAge(rows:RawRow[],fields:Record<string,string>){
 return rows.map(raw=>{
 const row=Object.fromEntries(Object.entries(raw).map(([k,v])=>[k.trim(),v]));
 const id=String(row.admmCd??'');if(!POP_REGIONS.some(r=>r.id===id)&&id!=='4115000000')return null;
 const cells:{from:number;to:number;sex:string;n:number}[]=[];
 const ageKeys=Object.keys(row).flatMap(k=>{const m=k.match(/(?:male|feml)(\d{1,3})Age/);return m?[Number(m[1])]:[]});
 const decadeKeys=ageKeys.length===22&&ageKeys.every(a=>a%10===0);
 const lastAge=Math.max(100,...Object.keys(row).map(k=>Number(k.match(/(?:male|feml)(\d{1,3})Age/)?.[1]??0)));
 for(const [key,value]of Object.entries(row)){
 const desc=(fields[key]??key).replace(/[\s()]/g,'');
 let sex=/남자|male/i.test(desc)?'m':/여자|feml|female/i.test(desc)?'f':'';
 // Check female first because "female" contains "male".
 if(/여자|feml|female/i.test(desc))sex='f';
 const range=desc.match(/(\d{1,3})(?:세)?[~∼–-](\d{1,3})세/)??key.match(/(?:male|feml)(\d{1,3})(?:To|to|_)(\d{1,3})/);
 const single=desc.match(/(\d{1,3})세/)??key.match(/(?:male|feml)(\d{1,3})Age/);
 if(!sex||(!range&&!single))continue;
 const from=Number((range??single)![1]),to=range?Number(range[2]):/이상|Above|Over/i.test(desc)||from===lastAge?110:decadeKeys?from+9:from;
 const n=numeric(value);if(n===null)throw Error('연령별 인구 누락 항목 확인 필요');cells.push({from,to,sex,n});
 }
 if(!cells.length)throw Error('연령별 인구 제공 항목 확인 필요');
 for(const sex of ['m','f']){const coverage=Array(111).fill(0);cells.filter(c=>c.sex===sex).forEach(c=>{for(let a=c.from;a<=Math.min(c.to,110);a++)coverage[a]++;});if(coverage.some(n=>n!==1))throw Error(`연령 구간의 누락·중복 확인 필요 (${sex}, ${cells.filter(c=>c.sex===sex).length}개 구간, ${coverage.filter(n=>n===0).length}개 연령 누락)`);}
 const total=numeric(row.totNmprCnt??row.totPpltnCnt);if(total===null||cells.reduce((s,c)=>s+c.n,0)!==total)throw Error('연령별 합계와 총인구 확인 필요');
 const groups=Array.from({length:10},(_,i)=>{const from=i*10,to=i===9?110:from+9;const c=cells.filter(c=>c.from>=from&&c.to<=to);return {label:i===9?'90세 이상':`${from}~${to}세`,male:c.filter(c=>c.sex==='m').reduce((s,c)=>s+c.n,0),female:c.filter(c=>c.sex==='f').reduce((s,c)=>s+c.n,0)};});
 if(groups.reduce((s,c)=>s+c.male+c.female,0)!==total)throw Error('10세별 집계 구간 확인 필요');
 const limits=[{label:'유소년 · 0~14세',from:0,to:14},{label:'생산연령 · 15~64세',from:15,to:64},{label:'고령 · 65세 이상',from:65,to:110}];
 const exact=limits.every(g=>!cells.some(c=>c.from<g.from&&c.to>=g.from||c.from<=g.to&&c.to>g.to));
 return {id:id==='4115000000'?'city':id,total,groups,summary:exact?limits.map(g=>({label:g.label,count:cells.filter(c=>c.from>=g.from&&c.to<=g.to).reduce((s,c)=>s+c.n,0)})):null} as ResidentAge;
 }).filter((r):r is ResidentAge=>Boolean(r));
}
