export const TRAFFIC_CITY_CODES=[["가평군","1322"],["고양시","1318"],["과천시","1332"],["광명시","1309"],["광주시","1319"],["구리시","1310"],["군포시","1333"],["김포시","1327"],["남양주시","1334"],["동두천시","1330"],["부천시","1306"],["성남시","1303"],["수원시","1302"],["시흥시","1316"],["안산시","1307"],["안성시","1326"],["안양시","1305"],["양주시","1311"],["양평군","1323"],["여주시","1313"],["연천군","1320"],["오산시","1335"],["용인시","1325"],["의왕시","1336"],["의정부시","1304"],["이천시","1324"],["파주시","1317"],["평택시","1308"],["포천시","1321"],["하남시","1337"],["화성시","1315"]] as const;
export const TRAFFIC_CITIES=TRAFFIC_CITY_CODES.map(([city])=>city);
export const TRAFFIC_CATEGORIES=['전체사고','어린이사고','고령자사고','보행자사고','자전거사고','야간사고','어린이보행사고','스쿨존내어린이사고','고령운전자사고','고령보행자사고','개인형이동수단(PM)사고','뺑소니사고','무면허사고'];
export const VIOLATIONS=[['cnt_027_01','과속'],['cnt_027_02','중앙선 침범'],['cnt_027_03','신호위반'],['cnt_027_04','안전거리 미확보'],['cnt_027_05','안전운전 의무 불이행'],['cnt_027_06','교차로 통행방법 위반'],['cnt_027_07','보행자 보호의무 위반'],['cnt_027_99','기타']] as const;
export const COLLISIONS=[['cnt_014_01','차대사람'],['cnt_014_02','차대차'],['cnt_014_03','차량단독'],['cnt_014_04','철길건널목']] as const;
export type TrafficRow={year:number;city:string;category:string;accidents:number;deaths:number;injuries:number;fatality:number|null;accidentShare:number|null;deathShare:number|null;injuryShare:number|null;nationalAccidents:number|null;nationalDeaths:number|null;nationalInjuries:number|null;perPopulation:number|null;perCar:number|null;details:Record<string,number|null>};
export type TrafficSnapshot={year:number;collectedAt:string;rows:TrafficRow[]};
export type TrafficData={snapshots:TrafficSnapshot[];years:number[];states:{year:number;nextDue:number;error:string|null;collecting:boolean}[]};
export const trafficYears=()=>Array.from({length:5},(_,i)=>Number(new Intl.DateTimeFormat('en',{year:'numeric',timeZone:'Asia/Seoul'}).format(new Date()))-1-i);
function numeric(v:unknown):number|null{if(v===null||v===undefined||String(v).trim()===''||String(v).trim()==='-')return null;const n=Number(String(v).replaceAll(',',''));return Number.isFinite(n)&&n>=0?n:null;}
export function normalizeTraffic(raw:Record<string,unknown>,year:number):TrafficRow|null{
 const city=TRAFFIC_CITIES.find(c=>String(raw.sido_sgg_nm??'').trim().endsWith(c));if(!city)return null;
 if(Number(raw.std_year)!==year)throw Error('교통사고 통계 기준연도 확인 필요');
 let category=String(raw.acc_cl_nm??'').replace(/노인/g,'고령').replace('어린이보호구역내어린이사고','스쿨존내어린이사고').replace('어린이보호구역내 어린이사고','스쿨존내어린이사고');
 if(category==='PM사고')category='개인형이동수단(PM)사고';
 const accidents=numeric(raw.acc_cnt),deaths=numeric(raw.dth_dnv_cnt),injuries=numeric(raw.injpsn_cnt);
 if(!category||accidents===null||deaths===null||injuries===null)throw Error('교통사고 통계 필수 항목 확인 필요');
 return {year,city,category,accidents,deaths,injuries,fatality:numeric(raw.ftlt_rate),accidentShare:numeric(raw.acc_cnt_cmrt),deathShare:numeric(raw.dth_dnv_cnt_cmrt),injuryShare:numeric(raw.injpsn_cnt_cmrt),nationalAccidents:numeric(raw.tot_acc_cnt),nationalDeaths:numeric(raw.tot_dth_dnv_cnt),nationalInjuries:numeric(raw.tot_injpsn_cnt),perPopulation:numeric(raw.pop_100k),perCar:numeric(raw.car_10k),details:Object.fromEntries([...VIOLATIONS,...COLLISIONS].map(([key])=>[key,numeric(raw[key])]))};
}
