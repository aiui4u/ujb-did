import type { NewsArticle } from './news';
export const NEWS_CATEGORIES = ['행정', '교통', '복지', '문화', '경제', '안전', '기타'] as const;
export type NewsCategory = typeof NEWS_CATEGORIES[number];
const rules: [NewsCategory, RegExp][] = [
  ['안전', /재난|안전|화재|소방|범죄|사고|침수|폭우|경찰|대피/],
  ['교통', /교통|철도|지하철|버스|도로|주차|GTX|경전철|보행|통행/i],
  ['복지', /복지|돌봄|어르신|노인|장애|보육|취약|의료|건강|아동|청소년|출산/],
  ['문화', /문화|축제|공연|전시|관광|체육|도서관|예술|음악|콘서트|스포츠/],
  ['경제', /경제|기업|소상공인|상권|일자리|취업|창업|투자|산업|시장경제|지역화폐/],
  ['행정', /시정|행정|의회|조례|예산|정책|공무원|시청|협약|공모|위원회|시장|간담회/],
];
export function newsCategory(title: string): NewsCategory { return rules.find(([, re]) => re.test(title))?.[0] ?? '기타'; }
const stop = new Set(['의정부', '의정부시', '의정부시는', '의정부시의', '경기', '경기도', '위한', '통해', '대한', '관련', '위해', '함께', '개최', '추진', '실시', '운영', '지원', '선정', '진행', '확대', '마련', '한다', '밝혔다', '뉴스']);
export function newsKeywords(articles: NewsArticle[]) {
  const counts = new Map<string, number>();
  for (const a of articles) {
    const words = new Set(a.title.replace(/[^가-힣a-zA-Z0-9\s]/g, ' ').split(/\s+/).filter(w => w.length >= 2 && w.length <= 12 && !stop.has(w) && !/^\d/.test(w)));
    for (const word of words) counts.set(word, (counts.get(word) ?? 0) + 1);
  }
  return [...counts].sort((a,b) => b[1]-a[1] || a[0].localeCompare(b[0], 'ko')).slice(0,20).map(([word,count]) => ({word,count}));
}
export function koreaDate(value: number | string) { return new Intl.DateTimeFormat('sv-SE', {timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(value)); }
