import {build} from 'vite';
import {mkdir,copyFile,readFile,writeFile} from 'node:fs/promises';
const saved=new Map();
for(const file of ['data.json','news.json']){try{saved.set(file,await readFile('web/'+file));}catch{}}
await build();
for(const [file,value]of saved)await writeFile('web/'+file,value);
for(const route of ['weather','population','commerce','traffic','news','pledges','pledges/projects','other']){
 await mkdir(`web/${route}`,{recursive:true});await copyFile('web/index.html',`web/${route}/index.html`);
}
await copyFile('web/index.html','web/404.html');
