import {build} from 'vite';
import {mkdir,copyFile} from 'node:fs/promises';
await build();
for(const route of ['weather','population','commerce','traffic','news','pledges','pledges/projects','other']){
 await mkdir(`web/${route}`,{recursive:true});await copyFile('web/index.html',`web/${route}/index.html`);
}
await copyFile('web/index.html','web/404.html');
