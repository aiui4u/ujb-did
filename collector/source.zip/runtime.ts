import {DatabaseSync} from 'node:sqlite';
import {readFileSync,writeFileSync,renameSync,mkdirSync} from 'node:fs';
import {dirname} from 'node:path';
export const tables:Record<string,string>={
 api_cache:'cache_key TEXT PRIMARY KEY,payload TEXT NOT NULL,expires_at INTEGER NOT NULL',
 weather_snapshots:'region_id TEXT PRIMARY KEY,payload TEXT NOT NULL,saved_at INTEGER NOT NULL',
 collection_state:'id TEXT PRIMARY KEY,next_due INTEGER NOT NULL,lease_until INTEGER NOT NULL,last_started INTEGER NOT NULL,last_finished INTEGER,last_error TEXT',
 warning_snapshot:'id TEXT PRIMARY KEY,payload TEXT NOT NULL,saved_at INTEGER NOT NULL',
 population_snapshot:'id TEXT PRIMARY KEY,payload TEXT NOT NULL,saved_at INTEGER NOT NULL',
 population_jobs:'id TEXT PRIMARY KEY,payload TEXT NOT NULL,saved_at INTEGER NOT NULL',
 commerce_snapshot:'id TEXT PRIMARY KEY,payload TEXT NOT NULL,saved_at INTEGER NOT NULL',
 commerce_pages:'id TEXT PRIMARY KEY,run_id TEXT NOT NULL,page INTEGER NOT NULL,payload TEXT NOT NULL',
 commerce_state:'id TEXT PRIMARY KEY,payload TEXT NOT NULL,saved_at INTEGER NOT NULL'
};
export class JsonDatabase{
 sql=new DatabaseSync(':memory:');
 constructor(){for(const [t,s] of Object.entries(tables))this.sql.exec(`CREATE TABLE ${t} (${s})`);}
 prepare(query:string){const stmt=this.sql.prepare(query);let args:any[]=[];const api={bind(...v:any[]){args=v.map(x=>x===undefined?null:x);return api;},async first(column?:string){const row=stmt.get(...args);return row?(column?row[column]:row):null;},async all(){return {results:stmt.all(...args),success:true};},async run(){const r=stmt.run(...args);return {success:true,meta:{changes:Number(r.changes),last_row_id:Number(r.lastInsertRowid)}};}};return api;}
 async batch(statements:any[]){this.sql.exec('BEGIN');try{const results=[];for(const s of statements)results.push(await s.run());this.sql.exec('COMMIT');return results;}catch(e){this.sql.exec('ROLLBACK');throw e;}}
 restore(data:any){if(data?.version!==1||!data.tables||typeof data.tables!=='object')throw Error('수집 상태 JSON 형식 확인 필요');for(const [t,rows]of Object.entries(data.tables)){if(!(t in tables)||!Array.isArray(rows))continue;for(const row of rows){const keys=Object.keys(row);const allowed=new Set((this.sql.prepare(`PRAGMA table_info(${t})`).all() as any[]).map(x=>x.name));if(!keys.length||keys.some(k=>!allowed.has(k)))throw Error('수집 상태 항목 확인 필요');this.sql.prepare(`INSERT INTO ${t} (${keys.join(',')}) VALUES (${keys.map(()=>'?').join(',')})`).run(...keys.map(k=>(row as any)[k]));}}}
 dump(){return {version:1,tables:Object.fromEntries(Object.keys(tables).map(t=>[t,this.sql.prepare(`SELECT * FROM ${t}`).all()]))};}
}
export const database=new JsonDatabase();
export const env:any={...process.env,DB:database};
const secretNames=['KMA_API_KEY','AIRKOREA_API_KEY','POPULATION_API_KEY','BIRTH_API_KEY','COMMERCE_API_KEY','TRAFFIC_API_KEY','HOUSEHOLD_SIZE_API_KEY'];
export function redact(value:string){for(const k of secretNames){const v=process.env[k];if(!v||v.length<8)continue;let decoded=v;try{decoded=decodeURIComponent(v);}catch{}for(const s of new Set([v,decoded,encodeURIComponent(decoded)]))value=value.split(s).join('[비공개]');}return value.replace(/([?&](?:servicekey|apikey)=)[^&\s"<>]+/gi,'$1[비공개]');}
export function readJSON(path:string,fallback:any=null){try{return JSON.parse(readFileSync(path,'utf8'));}catch(e:any){if(e.code==='ENOENT')return fallback;throw Error('저장 JSON 손상 확인 필요 · 덮어쓰기를 중지합니다.');}}
export function writeJSON(path:string,value:any){mkdirSync(dirname(path),{recursive:true});const temp=path+'.tmp';writeFileSync(temp,redact(JSON.stringify(value)));renameSync(temp,path);}
