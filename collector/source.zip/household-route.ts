import {env} from 'cloudflare:workers';
import {monthlyCached} from '@/lib/shared-refresh';
import {monthlyTtl} from '@/lib/refresh-policy';
import {recentMonths} from '@/lib/population';
import {extractContract,rowsAndCount} from '@/lib/population-store';
import {readApiCache,writeApiCache} from '@/lib/api-cache';
import {normalizeHouseholdSizes,type HouseholdSizeData} from '@/lib/household-sizes';
export const dynamic='force-dynamic';
const active=new Map<string,Promise<HouseholdSizeData>>();
async function collect(month:string):Promise<HouseholdSizeData>{
 const cacheKey=`household-sizes:v1:${month}`;
 return monthlyCached<HouseholdSizeData>(cacheKey,monthlyTtl(month,recentMonths()[0]),async()=>{
  let key=(env as unknown as {HOUSEHOLD_SIZE_API_KEY?:string;POPULATION_API_KEY?:string}).HOUSEHOLD_SIZE_API_KEY||env.POPULATION_API_KEY;if(!key)throw Error('세대원수별 API 연결 설정 확인 필요');try{key=decodeURIComponent(key);}catch{}
  let fields=await readApiCache('household-size-contract:v1') as Record<string,string>|undefined;
  if(!fields){try{const r=await fetch('https://www.data.go.kr/data/15108081/openapi.do',{signal:AbortSignal.timeout(8000)});if(r.ok){const c=extractContract(await r.text());if(c){fields=c.fields;await writeApiCache('household-size-contract:v1',fields,604800);}}}catch{}}
  const rows:Record<string,unknown>[]=[];let expected:number|null=null;
  for(let page=1;page<=20;page++){
   const url=new URL('https://apis.data.go.kr/1741000/admmHsmbHh/selectAdmmHsmbHh');for(const [k,v]of Object.entries({serviceKey:key,type:'json',numOfRows:'100',pageNo:String(page),lv:'3',admmCd:'4115000000',srchFrYm:month,srchToYm:month}))url.searchParams.set(k,v);
   const response=await fetch(url,{signal:AbortSignal.timeout(20000)});if(!response.ok)throw Error('세대원수별 자료 제공기관 연결 지연');let json:unknown;try{json=await response.json();}catch{throw Error('세대원수별 API 응답 형식 확인 필요');}
   const result=rowsAndCount(json);if(result.total!==null)expected=result.total;
   rows.push(...result.rows);if(expected!==null&&rows.length>=expected||result.rows.length<100)break;
  }
  if(!rows.length)throw Error('선택한 기준월의 세대 자료가 아직 제공되지 않습니다.');if(expected!==null&&expected!==rows.length)throw Error('세대 자료의 일부 페이지가 수신되지 않았습니다.');
  let regions;try{regions=normalizeHouseholdSizes(rows,month,fields);}catch(e){console.warn('household-size schema',JSON.stringify({fields:fields??{},sample:rows[0]}));throw e;}
  return {month,regions,savedAt:new Date().toISOString()};
 },{month,regions:[]});
}

export async function GET(request:Request){const month=new URL(request.url).searchParams.get('month')??'';if(!/^20\d{2}(0[1-9]|1[0-2])$/.test(month))return Response.json({error:'통계 기준월 확인 필요'},{status:400});if(!active.has(month))active.set(month,collect(month).finally(()=>active.delete(month)));return Response.json(await active.get(month),{headers:{'Cache-Control':'no-store'}});}
