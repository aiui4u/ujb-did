import {existsSync,mkdirSync,openSync,closeSync,unlinkSync,writeFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import assert from 'node:assert/strict';
import {database as db,env,readJSON,writeJSON,redact,JsonDatabase} from './runtime';
import {collectWarnings,readWarnings} from './lib/warning-store';
import {collectAndSave,readSnapshot} from './lib/weather-store';
import {collectPopulation,readPopulation,collectPopulationAreas,loadPopulationAreas} from './lib/population-store';
import {collectBirths,loadBirths} from './lib/birth-store';
import {collectCommerce,loadCommerce} from './lib/commerce-store';
import {refreshHomeSummary,readHomeSummary} from './lib/home-summary';
import {checkNewTraffic,readTraffic} from './lib/traffic-store';
import {readApiCache,writeApiCache} from './lib/api-cache';
import {recentMonths} from './lib/population';
import {GET as collectAge} from './age-route';
import {GET as collectHouseholds} from './household-route';
import {parseNewsFeed,mergeNewsArticles} from './lib/news';

const root=resolve(process.env.DID_REPO_ROOT??process.cwd());
const paths={data:resolve(root,'web/data.json'),news:resolve(root,'web/news.json'),state:resolve(root,'collector/state.json'),lock:resolve(root,'collector/.collect.lock')};
let original:any;
let previousErrors=new Map<string,string>();
const HOUR=3600000,DAY=24*HOUR;
const nowISO=()=>new Date().toISOString();
const savedTime=(value:any)=>Number.isFinite(Date.parse(value))?Date.parse(value):0;
async function put(table:string,id:string,value:any,time=Date.now(),column='id'){
 if(value===null||value===undefined)return;
 await db.prepare(`INSERT OR IGNORE INTO ${table} (${column},payload,saved_at) VALUES (?,?,?)`).bind(id,JSON.stringify(value),time).run();
}
async function setInitialState(id:string,last:number,interval:number){await db.prepare('INSERT OR IGNORE INTO collection_state(id,next_due,lease_until,last_started,last_finished,last_error) VALUES(?,?,0,?,?,NULL)').bind(id,last?last+interval:0,last,last||null).run();}
async function initialSeed(d:any,n:any){
 const weather=d.weather;
 if(weather?.sources){await put('weather_snapshots','city',weather,savedTime(weather.storage?.savedAt??weather.fetchedAt),'region_id');await setInitialState('weather',savedTime(weather.fetchedAt),HOUR);}
 if(d.warnings){await put('warning_snapshot','gyeonggi',d.warnings,savedTime(d.warnings.collectedAt));await setInitialState('warnings',savedTime(d.warnings.collectedAt),30*60000);}
 if(d.population?.population)await put('population_snapshot','uijeongbu',d.population,savedTime(d.population.collectedAt));
 if(d.births?.months)await put('population_jobs','births:snapshot:v1',d.births,savedTime(d.births.savedAt));
 if(d.commerce?.snapshot)await put('commerce_snapshot','uijeongbu',d.commerce.snapshot,savedTime(d.commerce.snapshot.collectedAt));
 for(const t of d.traffic?.snapshots??[])await writeApiCache(`traffic:${t.year}:last-good`,t,366*86400*10);
 for(const [month,v]of Object.entries(d.monthly??{}) as [string,any][]){for(const [field,prefix]of [['ages','resident-age:v2:'],['households','household-sizes:v1:']]){const data=v[field];if(!data?.regions?.length||data.error)continue;const ttl=month>=recentMonths()[0]?86400:30*86400;await writeApiCache(prefix+month,data,ttl);await writeApiCache(prefix+month+':last-good',data,366*86400);}}
 for(const [key,v]of Object.entries(d.areas??{}) as [string,any][]){if(!v.row)continue;await put('population_jobs','population-areas:'+key,{page:1,done:true,rows:[],summary:v.row,savedAt:v.savedAt,error:v.error??null,note:v.note??null,total:v.row.areas?.length??0});}
 if(d.home){await writeApiCache('home-summary:v2:last-good',d.home,366*86400);}
 await setInitialState('news',savedTime(n?.lastAttemptAt??n?.collectedAt),HOUR);
}
async function state(id:string){return await db.prepare('SELECT * FROM collection_state WHERE id=?').bind(id).first() as any;}
async function due(id:string,maxWait=0){const s=await state(id);if(!s)return true;const now=Date.now();if(s.lease_until>now)return false;const delay=s.next_due-now;if(delay>maxWait)return false;if(delay>0)await new Promise(r=>setTimeout(r,Math.min(5000,delay)));return s.next_due<=Date.now();}
async function checkpoint(){writeJSON(paths.state,db.dump());}
async function errorMap(){
 const errors=new Map<string,string>();const states=await db.prepare('SELECT id,last_error FROM collection_state WHERE last_error IS NOT NULL').all();
 for(const row of states.results as any[])if(row.last_error)errors.set(row.id,row.last_error);
 const commerce=await db.prepare("SELECT payload FROM commerce_state WHERE id='uijeongbu'").first() as any;const message=commerce?JSON.parse(commerce.payload).error:null;if(message)errors.set('commerce',message);
 return errors;
}
async function reportNewErrors(){for(const [id,error]of await errorMap())if(previousErrors.get(id)!==error)console.log('::warning::'+redact(`${id}: ${error}`).replace(/[\r\n]/g,' '));}
const deadline=Date.now()+18*60000;
const remaining=()=>deadline-Date.now();
async function runJob(name:string,fn:()=>Promise<any>){if(remaining()<90000){console.log(name+': 다음 실행으로 이어갑니다.');return;}try{await fn();}catch(e){console.log(name+': '+redact(e instanceof Error?e.message:'수집 지연 · 기존 자료 유지'));}finally{await checkpoint();}}
async function runPopulation(){
 if(!await due('population'))return;
 const end=Math.min(Date.now()+10*60000,deadline-90000);
 for(let n=0;n<120&&Date.now()<end;n++){
  const result=await collectPopulation(false);await checkpoint();
  if(!result.started||!result.pending||result.errors?.length)break;
  const s=await state('population');if(s?.last_error||!await due('population',5000))break;
 }
}
async function runBirths(){for(let n=0;n<12&&remaining()>90000;n++){const s=await state('births');if(n&&s?.last_error||!await due('births',n?5000:0))break;await collectBirths(false);await checkpoint();const data=await loadBirths();if(data.error||!data.pending)break;}}
async function runMonthly(){
 const pop=await readPopulation();const months=[...new Set([...(pop?.population.map(x=>x.month)??[]),...recentMonths(new Date(),6)])].sort().reverse().slice(0,6);
 for(const month of months){if(remaining()<90000)break;for(const fn of [collectHouseholds,collectAge]){if(remaining()<90000)break;const r=await fn(new Request(`https://collector.invalid/?month=${month}`));await r.json();await checkpoint();}}
}
async function runAreas(){
 // Continue only work already queued; no reset or forced creation of new detail jobs.
 const jobs=await db.prepare("SELECT j.id FROM population_jobs j JOIN collection_state s ON s.id=j.id WHERE j.id LIKE 'population-areas:%' AND json_extract(j.payload,'$.done')=0 AND s.next_due<=? AND s.lease_until<=? ORDER BY j.id LIMIT 8").bind(Date.now(),Date.now()).all();
 for(const row of jobs.results as any[]){if(remaining()<90000)break;const [,month,id]=row.id.split(':');await collectPopulationAreas(id,month);await checkpoint();}
}
async function runCommerce(){
 const end=Math.min(Date.now()+5*60000,deadline-90000);
 for(let n=0;n<120&&Date.now()<end;n++){
  if(n){const data=await loadCommerce();if(!data.status.pending||data.status.error)break;const retry=await readApiCache('commerce-retry-v2') as any;if(retry?.due>Date.now())break;}
  const result=await collectCommerce(false);await checkpoint();if(!result.pending||result.error)break;
 }
}
async function collectNews(){
 if(!await due('news'))return;
 const started=Date.now(),old=readJSON(paths.news,{articles:[],collectedAt:null,lastAttemptAt:null,error:null});
 let next:any;
 try{
  const r=await fetch('https://news.google.com/rss/search?q=%EC%9D%98%EC%A0%95%EB%B6%80%EC%8B%9C&hl=ko&gl=KR&ceid=KR:ko',{signal:AbortSignal.timeout(25000)});if(!r.ok)throw Error('Google RSS 응답 지연');
  const xml=await r.text();if(!/<(?:rss|feed)(?:\s|>)/i.test(xml))throw Error('Google RSS 응답 형식 확인 필요');
  const incoming=parseNewsFeed(xml);if(!incoming.length)throw Error('Google RSS 기사 수신 대기');
  next={articles:mergeNewsArticles(incoming,old.articles??[]).slice(0,150),collectedAt:nowISO(),lastAttemptAt:nowISO(),error:null,pending:false};
 }catch{next={articles:(old.articles??[]).slice(0,150),collectedAt:old.collectedAt??null,lastAttemptAt:nowISO(),error:'Google RSS 수집 지연 · 마지막 정상 목록 유지',pending:false};}
 writeJSON(paths.news,next);
 await db.prepare('INSERT INTO collection_state(id,next_due,lease_until,last_started,last_finished,last_error) VALUES(?,?,0,?,?,?) ON CONFLICT(id) DO UPDATE SET next_due=excluded.next_due,lease_until=0,last_started=excluded.last_started,last_finished=excluded.last_finished,last_error=excluded.last_error').bind('news',Date.now()+HOUR,started,Date.now(),next.error).run();
}
async function buildExport(){
 const d={...original};
 const warnings=await readWarnings();if(warnings)d.warnings={...warnings,pending:false,nextCheckAt:(await state('warnings'))?.next_due??null};
 const weather=await readSnapshot('city');if(weather){const s=await state('weather');d.weather={...weather,warnings:d.warnings??weather.warnings,grid:{...weather.grid,name:'의정부시'},collection:{pending:false,lastStarted:s?.last_started?new Date(s.last_started).toISOString():null,lastFinished:s?.last_finished?new Date(s.last_finished).toISOString():null,message:s?.last_error??null}};}
 const pop=await readPopulation();if(pop)d.population=pop;
 d.births=await loadBirths();d.commerce=await loadCommerce();d.traffic=await readTraffic();
 d.home=await readHomeSummary();d.monthly={...(d.monthly??{})};
 const rows=await db.prepare("SELECT cache_key,payload FROM api_cache WHERE cache_key LIKE 'resident-age:v2:%' OR cache_key LIKE 'household-sizes:v1:%'").all();
 for(const r of rows.results as any[]){const match=r.cache_key.match(/^(resident-age:v2|household-sizes:v1):(20\d{4})(:last-good)?$/);if(!match)continue;const v=JSON.parse(r.payload);if(!v.regions?.length)continue;const m=match[2],field=match[1].startsWith('resident')?'ages':'households';d.monthly[m]??={};const previous=d.monthly[m][field];if(!previous||!v.error||!previous.regions?.length)d.monthly[m][field]=v;}
 d.areas={...(d.areas??{})};const areaJobs=await db.prepare("SELECT id FROM population_jobs WHERE id LIKE 'population-areas:%'").all();for(const row of areaJobs.results as any[]){const [,m,id]=row.id.split(':');d.areas[`${m}:${id}`]=await loadPopulationAreas(id,m);}
 d.exportedAt=nowISO();if(!d.weather?.sources||!Array.isArray(d.population?.population)||!Array.isArray(d.traffic?.snapshots))throw Error('JSON 내보내기 검증 실패 · 기존 파일 유지');return d;
}
async function exportData(){
 const d=await buildExport();writeJSON(paths.data,d);
 // Export is checked against what the static application reads.
 const actual=readJSON(paths.data);if(!actual.weather?.sources||!Array.isArray(actual.population?.population)||!Array.isArray(actual.traffic?.snapshots))throw Error('JSON 저장 결과 검증 필요');
 console.log(JSON.stringify({savedAt:d.exportedAt,weatherSavedAt:d.weather?.storage?.savedAt,populationMonths:d.population?.population.map((m:any)=>m.month),birthMonths:d.births.months.map((m:any)=>m.month),commerceSavedAt:d.commerce.snapshot?.collectedAt,trafficYears:d.traffic.snapshots.map((m:any)=>m.year),newsCount:readJSON(paths.news,{articles:[]}).articles.length}));
}
async function selfTest(){
 const x=new JsonDatabase();await x.prepare("INSERT INTO collection_state VALUES('test',9999999999999,9999999999999,1,NULL,NULL)").run();const y=new JsonDatabase();y.restore(x.dump());assert.equal((await y.prepare("SELECT * FROM collection_state WHERE id='test'").first() as any).next_due,9999999999999);
 await assert.rejects(x.batch([x.prepare("INSERT INTO api_cache VALUES('x','{}',1)"),x.prepare("INSERT INTO api_cache VALUES('x','{}',2)")]));assert.equal(await x.prepare("SELECT * FROM api_cache WHERE cache_key='x'").first(),null);
 const fixture=readJSON(paths.data);assert(fixture?.weather?.sources);original=fixture;await initialSeed(fixture,readJSON(paths.news));
 let calls=0;globalThis.fetch=async()=>{calls++;throw Error('test provider unavailable');};
 await db.prepare("UPDATE collection_state SET next_due=0,lease_until=0,last_started=0 WHERE id='warnings'").run();await collectWarnings();const warningCalls=calls;await collectWarnings();assert.equal(calls,warningCalls);assert.equal((await readWarnings())?.issuedAt,fixture.warnings.issuedAt);
 const before=await readSnapshot('city');await db.prepare("UPDATE collection_state SET next_due=0,lease_until=0 WHERE id='weather'").run();await collectAndSave();assert.deepEqual((await readSnapshot('city'))?.current,before?.current);assert.equal((await db.prepare('SELECT region_id FROM weather_snapshots').all()).results.length,1);
 await setInitialState('population',Date.now(),HOUR);assert.equal(await due('population',5000),false);const priorCalls=calls;await runPopulation();assert.equal(calls,priorCalls);
 await db.prepare("UPDATE collection_state SET next_due=0 WHERE id='population'").run();await collectPopulation(false);assert.equal(calls,priorCalls,'완료 인구 월은 재수집하지 않아야 합니다.');
 env.BIRTH_API_KEY='test-key-only';await collectBirths(false);assert.equal(calls,priorCalls,'완료 출생 월은 재수집하지 않아야 합니다.');assert.equal((await loadBirths()).savedAt,fixture.births.savedAt);
 for(const month of Object.keys(fixture.monthly)){await collectAge(new Request(`https://collector.invalid/?month=${month}`));await collectHouseholds(new Request(`https://collector.invalid/?month=${month}`));}assert.equal(calls,priorCalls,'저장 월별 자료는 재사용해야 합니다.');
 await checkNewTraffic();assert.equal(calls,priorCalls,'완료 교통 연도는 강제 재수집하지 않아야 합니다.');
 const article=parseNewsFeed(`<rss version="2.0"><channel><item><title>의정부시 수집 검증</title><link>https://news.google.com/rss/articles/test</link><pubDate>${new Date().toUTCString()}</pubDate><source>테스트</source></item></channel></rss>`);assert.equal(article.length,1);assert.equal(mergeNewsArticles(article,article).length,1);
 assert.doesNotThrow(()=>JSON.parse(JSON.stringify(db.dump())));
 const exported=await buildExport();assert.equal(exported.weather.grid.name,'의정부시');assert.deepEqual(exported.weather.current,fixture.weather.current);assert.equal(exported.population.population[0].regions.length,16);assert.equal(exported.traffic.snapshots.length,fixture.traffic.snapshots.length);assert.equal(exported.monthly[recentMonths()[0]].ages.regions.length,16);
 console.log('검증 통과: JSON 상태 복원, 트랜잭션 복구, 특보 30분 제한, 시청 대표 날씨만 수집, 실패 시 기존 자료 유지, 미래 backoff 준수, 완료 인구·출생 월 재사용, 월별 자료 재사용, 교통 강제수집 방지, Google RSS 파싱·중복제거');
}
async function main(){
 if(process.argv.includes('--self-test')){await selfTest();return;}
 if(!existsSync(paths.data))throw Error('web/data.json이 없습니다. web 폴더부터 올려 주세요.');
 mkdirSync(dirname(paths.lock),{recursive:true});let lock:number;
 try{lock=openSync(paths.lock,'wx');}catch{console.log('다른 수집 작업이 진행 중이므로 중복 실행을 건너뜁니다.');return;}
 try{
  original=readJSON(paths.data);const saved=readJSON(paths.state);if(saved)db.restore(saved);else await initialSeed(original,readJSON(paths.news));previousErrors=await errorMap();
  const nativeFetch=globalThis.fetch.bind(globalThis);globalThis.fetch=(input:any,options:any={})=>nativeFetch(input,{...options,signal:options.signal?AbortSignal.any([options.signal,AbortSignal.timeout(90000)]):AbortSignal.timeout(90000)});
  await runJob('warnings',async()=>{const s=await state('warnings');if(await due('warnings')&&(!s||Date.now()-s.last_started>=30*60000))await collectWarnings();});
  await runJob('weather',async()=>{if(await due('weather'))await collectAndSave();});
  await runJob('population',runPopulation);
  await runJob('births',runBirths);
  await runJob('monthly',runMonthly);
  await runJob('areas',runAreas);
  await runJob('commerce',runCommerce);
  await runJob('home',async()=>{await checkNewTraffic();await refreshHomeSummary();});
  await runJob('news',collectNews);
  await exportData();await checkpoint();await reportNewErrors();
 }finally{closeSync(lock);unlinkSync(paths.lock);}
}
main().catch(e=>{console.error(redact(e instanceof Error?e.message:'수집 실행 환경 확인 필요'));process.exitCode=1;});
