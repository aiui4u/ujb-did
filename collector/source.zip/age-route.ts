import {monthlyCached} from '@/lib/shared-refresh';
import {monthlyTtl} from '@/lib/refresh-policy';
import {recentMonths} from '@/lib/population';
import {contract,providerPage} from '@/lib/population-store';
import {normalizeResidentAge,type ResidentAge} from '@/lib/resident-age';
import {readApiCache,writeApiCache} from '@/lib/api-cache';
export const dynamic='force-dynamic';
const active=new Map<string,Promise<unknown>>();
export async function GET(request:Request){
 const month=new URL(request.url).searchParams.get('month')??'';
 if(!/^20\d{2}(0[1-9]|1[0-2])$/.test(month))return Response.json({error:'통계 기준월 확인 필요'},{status:400});
 const key=`resident-age:v2:${month}`;
 const cached=await readApiCache(key);if(cached)return Response.json(cached);
 if(!active.has(key))active.set(key,monthlyCached<{month:string;regions:ResidentAge[];savedAt?:string;error?:string;stale?:boolean}>(key,monthlyTtl(month,recentMonths()[0]),async()=>{
 const [schema,result]=await Promise.all([contract('residentAge'),providerPage('residentAge',{type:'json',numOfRows:'100',pageNo:'1',lv:'3',admmCd:'4115000000',srchFrYm:month,srchToYm:month})]);
 if(!result.rows.length||result.total!==null&&result.total!==result.rows.length)throw Error('연령별 주민등록 자료 제공 범위 확인 필요');
 let regions:ResidentAge[];try{regions=normalizeResidentAge(result.rows,schema.fields);}catch(e){return {month,regions:[],error:e instanceof Error?e.message:'연령별 자료 확인 필요',sourceFields:Object.keys(result.rows[0]),sourceDescriptions:schema.fields};}const dongs=regions.filter(r=>r.id!=='city');
 if(dongs.length!==15)throw Error('15개 동 연령별 인구 수집 확인 필요');
 if(!regions.some(r=>r.id==='city')){const city:ResidentAge={id:'city',total:dongs.reduce((s,r)=>s+r.total,0),groups:dongs[0].groups.map((g,i)=>({label:g.label,male:dongs.reduce((s,r)=>s+r.groups[i].male,0),female:dongs.reduce((s,r)=>s+r.groups[i].female,0)})),summary:dongs.every(r=>r.summary)?dongs[0].summary!.map((g,i)=>({label:g.label,count:dongs.reduce((s,r)=>s+r.summary![i].count,0)})):null};regions.unshift(city);}
 return {month,regions,savedAt:new Date().toISOString()};
 },{month,regions:[] as ResidentAge[],error:undefined as string|undefined}).finally(()=>active.delete(key)));
 return Response.json(await active.get(key));
}
