import {env} from 'cloudflare:workers';
import {claimRefresh,finishRefresh} from './shared-refresh';
import {writeApiCache} from './api-cache';
import {TRAFFIC_CITY_CODES,normalizeTraffic,trafficYears,type TrafficData,type TrafficSnapshot} from './traffic';
const cacheKey=(year:number)=>`traffic:${year}:last-good`;
function nextQuarter(now=Date.now()){const d=new Date(now+9*3600000);return Date.UTC(d.getUTCFullYear(),Math.floor(d.getUTCMonth()/3)*3+3,1)-9*3600000;}
export async function checkNewTraffic(){
 const data=await readTraffic(),latest=data.snapshots[0],candidate=trafficYears()[0];
 // Existing annual records are reused; only an unpublished newer year needs a provider check.
 if(latest&&latest.year>=candidate)return {pending:false,checked:true,newYear:false,nextCheck:nextQuarter()};
 const id='traffic-new-year-quarterly',started=await claimRefresh(id,45000);if(!started)return {pending:false};
 try{const snapshot=await provider(candidate);await writeApiCache(cacheKey(candidate),snapshot,366*86400*10);await finishRefresh(id,started,nextQuarter());return {pending:false,saved:true,year:candidate};}
 catch{await finishRefresh(id,started,nextQuarter());return {pending:false,newYear:false,message:'신규 연도 통계 미확인 · 다음 분기에 다시 확인'};}
}
export async function readTraffic():Promise<TrafficData>{
 const years=trafficYears();if(!env.DB)return {years,snapshots:[],states:[]};
 const [cache,state]=await Promise.all([env.DB.prepare("SELECT payload FROM api_cache WHERE cache_key LIKE 'traffic:%:last-good'").all<{payload:string}>(),env.DB.prepare("SELECT id,next_due,lease_until,last_error FROM collection_state WHERE id LIKE 'traffic:v5:%'").all<{id:string;next_due:number;lease_until:number;last_error:string|null}>()]);
 return {years,snapshots:cache.results.map(r=>JSON.parse(r.payload) as TrafficSnapshot).sort((a,b)=>b.year-a.year).slice(0,5),states:state.results.map(r=>({year:Number(r.id.split(':')[2]),nextDue:r.next_due,error:r.last_error,collecting:r.lease_until>Date.now()})).filter(s=>years.includes(s.year))};
}
async function providerCity(year:number,city:string,regionCode:string){
 const key=(env as unknown as {TRAFFIC_API_KEY?:string}).TRAFFIC_API_KEY;if(!key)throw Error('교통사고 API 인증 설정 확인 필요');
 let decoded=key;try{decoded=decodeURIComponent(key);}catch{}
 const u=new URL('https://apis.data.go.kr/B552061/lgStat/getRestLgStat');u.search=new URLSearchParams({ServiceKey:decoded,searchYearCd:String(year),siDo:'1300',guGun:regionCode,type:'json',numOfRows:'100',pageNo:'1'}).toString();
 let response:Response;try{response=await fetch(u,{signal:AbortSignal.timeout(20000)});}catch{throw Error('교통사고 제공기관 연결 지연');}
 if(!response.ok)throw Error(`교통사고 제공기관 응답 지연 (${response.status})`);
 let json:any;try{json=await response.json();}catch{throw Error('교통사고 제공기관 응답 형식 확인 필요');}
 const root=json.response??json,code=String(root.header?.resultCode??root.resultCode??'');
 if(!['00','0'].includes(code))throw Error(code==='03'?'해당 연도 통계가 아직 제공되지 않습니다.':`교통사고 API 응답 코드 ${code.replace(/[^A-Za-z0-9_-]/g,'').slice(0,15)||'확인 필요'}`);
 const body=root.body??root;const items=body.items?.item??body.items??[];const raw=Array.isArray(items)?items:[items];
 const total=Number(body.totalCount);if(!Number.isInteger(total)||total!==raw.length||total>1000)throw Error('교통사고 통계 전체 건수 확인 필요');
 const rows=raw.map((r:Record<string,unknown>)=>normalizeTraffic(r,year)).filter((r:ReturnType<typeof normalizeTraffic>)=>r!==null);
 const keys=new Set(rows.map((r:any)=>`${r.city}:${r.category}`));if(keys.size!==rows.length)throw Error('교통사고 통계 중복 항목 확인 필요');
 if(!rows.some((r:any)=>r.city===city&&r.category==='전체사고'))throw Error('의정부시 해당 연도 통계가 아직 제공되지 않습니다.');
 return {year,collectedAt:new Date().toISOString(),rows} as TrafficSnapshot;
}
async function provider(year:number){const results:TrafficSnapshot[]=[];for(let i=0;i<TRAFFIC_CITY_CODES.length;i+=4){results.push(...await Promise.all(TRAFFIC_CITY_CODES.slice(i,i+4).map(([city,code])=>providerCity(year,city,code))));}return {year,collectedAt:new Date().toISOString(),rows:results.flatMap(r=>r.rows)};}
// One due year per call bounds upstream work. A shared lease prevents duplicate browser collectors.
export async function collectTrafficStep(manual=false,requestedYear?:number){
 if(!manual)return checkNewTraffic();
 const target=trafficYears().includes(requestedYear??0)?requestedYear!:trafficYears()[0];const startedManual=await claimRefresh(`traffic-manual:${target}`,45000);if(!startedManual)return {pending:false};
 try{const snapshot=await provider(target);await writeApiCache(cacheKey(target),snapshot,366*86400*10);await finishRefresh(`traffic-manual:${target}`,startedManual,Date.now()+60000);return {saved:true,year:target,pending:false};}catch{await finishRefresh(`traffic-manual:${target}`,startedManual,Date.now()+60000);return {pending:false,error:'수동 수집 지연 · 마지막 정상자료 유지'};}
}
