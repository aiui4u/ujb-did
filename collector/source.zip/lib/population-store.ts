import {env} from 'cloudflare:workers';
import {DAY, monthlyBatch, retryDelay} from './refresh-policy';
import {runInBackground} from './collection-context';
import {readApiCache,writeApiCache} from './api-cache';
import {emptyPopulation,normalizePopulation,compactFlows,summarizeFlows,recentMonths,POP_REGIONS,numeric,type PopulationData,type PopulationRow,type RawRow,type FieldMap,type CompactFlow} from './population';
const definitions={residentAge:{endpoint:'https://apis.data.go.kr/1741000/admmSexdAgePpltn/selectAdmmSexdAgePpltn',portal:'https://www.data.go.kr/data/15108072/openapi.do'},population:{endpoint:'https://apis.data.go.kr/1741000/admmPpltnHhStus/selectAdmmPpltnHhStus',portal:'https://www.data.go.kr/data/15108065/openapi.do'},migration:{endpoint:'https://apis.data.go.kr/1741000/ppltnDataStus/selectPpltnDataStus',portal:'https://www.data.go.kr/data/15108093/openapi.do'}};
type Contract={params:{name:string;description:string;required?:boolean}[];fields:Record<string,string>};
function db(){if(!env.DB)throw Error('인구 DB 연결 확인 필요');return env.DB;}
function walk(value:unknown):Record<string,any>[]{if(!value||typeof value!=='object')return [];if(Array.isArray(value))return value.flatMap(walk);return [value as Record<string,any>,...Object.values(value).flatMap(walk)];}
export function extractContract(html:string):Contract|null{
 const match=html.match(/(?:const|let|var)\s+swaggerJson\s*=\s*`([\s\S]*?)`/);if(!match?.[1])return null;
 let spec:any;try{spec=JSON.parse(match[1]);}catch{return null;}
 const params=walk(spec.paths).filter(v=>v.in==='query'&&typeof v.name==='string').map(v=>({name:v.name,description:String(v.description??''),required:v.required}));
 const fields:Record<string,string>={};for(const v of walk(spec.definitions??spec.components?.schemas))for(const [name,field] of Object.entries(v.properties??{}) as [string,any][]){if(field?.description)fields[name]=String(field.description);}
 return {params,fields};
}
export async function contract(kind:keyof typeof definitions):Promise<Contract>{
 const key=`population-contract:${kind}:v1`;const saved=await readApiCache(key) as Contract|undefined;if(saved)return saved;
 try{const response=await fetch(definitions[kind].portal,{signal:AbortSignal.timeout(8000)});if(response.ok){const html=await response.text();let data=extractContract(html);if(!data){const url=html.match(/swaggerUrl\s*=\s*['"]([^'"]+)['"]/);if(url){const target=new URL(url[1],definitions[kind].portal);if(target.hostname==='www.data.go.kr'||target.hostname==='apis.data.go.kr'){const spec=await fetch(target,{signal:AbortSignal.timeout(5000)});if(spec.ok)data=extractContract('const swaggerJson = `'+JSON.stringify(await spec.json())+'`');}}}
  if(data?.params.length){await writeApiCache(key,data,86400);return data;}
 }}catch{}
 return {params:[],fields:{}};
}
const aliases:Record<string,string[]>={month:['statsYm','statsYymm','stats_ym','statYm'],code:['admmCd','admm_cd','admmInstCd'],city:['sggNm','sgg_nm'],dong:['dongNm','admmNm','admm_nm'],tong:['tong','tongNo'],ban:['ban','banNo'],population:['totNmprCnt','totPpltnCnt','tot_ppltn_cnt','totalPopulation'],households:['hhCnt','hh_cnt'],male:['maleNmprCnt','malePpltnCnt','male_ppltn_cnt'],female:['femlNmprCnt','femlPpltnCnt','feml_ppltn_cnt','femalePpltnCnt'],fromCode:['mvtAdmmCd','mvotAdmmCd','mvot_admm_cd'],toCode:['mvinAdmmCd','mvin_admm_cd'],fromProvince:['mvtCtpvNm','mvotCtpvNm'],fromCity:['mvtSggNm','mvotSggNm'],fromDong:['mvtDongNm','mvotAdmmNm'],toProvince:['mvinCtpvNm'],toCity:['mvinSggNm'],toDong:['mvinDongNm','mvinAdmmNm']};
export function fieldMap(schema:Contract,example:RawRow):FieldMap{
 const fields={...schema.fields};const map:FieldMap={};const clean=(s:string)=>s.replace(/<[^>]*>/g,'').replace(/[\s()·\/]/g,'');
 const labels:Record<string,string[]>={month:['통계년월'],code:['행정기관코드'],city:['시군구명'],dong:['행정동명'],tong:['통'],ban:['반'],population:['총인구수'],households:['세대수'],male:['남자인구수'],female:['여자인구수'],fromCode:['전출행정기관코드'],toCode:['전입행정기관코드'],fromProvince:['전출시도명'],fromCity:['전출시군구명'],fromDong:['전출행정동명'],toProvince:['전입시도명'],toCity:['전입시군구명'],toDong:['전입행정동명']};
 for(const [name,descs]of Object.entries(labels)){const exact=Object.entries(fields).find(([,d])=>descs.includes(clean(d)));const alias=aliases[name]?.find(a=>a in example)??Object.keys(example).find(k=>aliases[name]?.some(a=>a.toLowerCase()===k.toLowerCase()));if(exact)map[name]=Object.keys(example).find(k=>k.trim()===exact[0].trim())??exact[0].trim();else if(alias)map[name]=alias;}
 for(const [name,description]of Object.entries(fields)){const d=clean(description);const age=d.match(/(?:만)?(\d{1,3})세(?:이상)?(남자|여자)/);if(age)map[`age:${age[2]==='남자'?'m':'f'}:${Number(age[1])}`]=Object.keys(example).find(k=>k.trim()===name.trim())??name.trim();}
 for(const name of Object.keys(example)){const age=name.trim().match(/^(male|feml)(\d{1,3})AgeNmprCnt$/);if(age&&Number(age[2])<=110)map[`age:${age[1]==='male'?'m':'f'}:${Number(age[2])}`]=name;}
 return map;
}
export function rowsAndCount(json:unknown){const objects=walk(json);const array=objects.find(o=>Array.isArray(o.row));let rows=array?.row as RawRow[]|undefined;if(!rows){const body=objects.find(o=>o.items?.item);const v=body?.items?.item;rows=Array.isArray(v)?v:v?[v]:[];}
 const count=objects.map(o=>o.totalCount??o.list_total_count??o.total_count).find(v=>v!==undefined);const total=count===undefined?null:Number(count);
 const result=objects.find(o=>o.RESULT)?.RESULT??objects.find(o=>o.resultCode)?.resultCode;const code=typeof result==='object'?result.CODE:result;if(code&&!['INFO-000','00','0'].includes(String(code)))throw Error(`제공기관 응답 코드 ${String(code).slice(0,20)} · ${String(objects.find(o=>o.resultMsg)?.resultMsg??'').replace(/https?:\/\/\S+/g,'').replace(/[A-Za-z0-9+/%=]{40,}/g,'[비공개]').slice(0,140)}`);
 if(!rows?.length)return {rows:[] as RawRow[],total:total??0};return {rows,total};
}
export async function readPopulation(){const row=await db().prepare("SELECT payload FROM population_snapshot WHERE id='uijeongbu'").first<{payload:string}>();return row?JSON.parse(row.payload) as PopulationData:null;}
type PageJob={page:number;done:boolean;items?:CompactFlow[];count?:number;signatures:string[];total:number|null};
const countJob=(j:PageJob|null)=>j?.count??j?.items?.length??0;
async function signatureHash(value:string){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)))].map(n=>n.toString(16).padStart(2,'0')).join('');}
async function migratePageJob(id:string,state:PageJob){if(!state.items)return state;const writes=[];for(let start=0;start<state.items.length;start+=100)writes.push(db().prepare('INSERT INTO population_jobs (id,payload,saved_at) VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,saved_at=excluded.saved_at').bind(`${id}:page:${start/100+1}`,JSON.stringify({items:state.items.slice(start,start+100)}),Date.now()));const result={...state,count:state.items.length,items:undefined,signatures:await Promise.all(state.signatures.map(signatureHash))};writes.push(db().prepare('UPDATE population_jobs SET payload=?,saved_at=? WHERE id=?').bind(JSON.stringify(result),Date.now(),id));await db().batch(writes);return result;}
async function job(id:string){const r=await db().prepare('SELECT payload FROM population_jobs WHERE id=?').bind(id).first<{payload:string}>();return r?JSON.parse(r.payload):null;}
async function saveJob(id:string,payload:unknown){await db().prepare('INSERT INTO population_jobs (id,payload,saved_at) VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,saved_at=excluded.saved_at').bind(id,JSON.stringify(payload),Date.now()).run();}
export async function providerPage(kind:keyof typeof definitions,params:Record<string,string>,timeoutMs=22000){let key=(env as unknown as {POPULATION_API_KEY?:string;KMA_API_KEY?:string}).POPULATION_API_KEY??(env as unknown as {KMA_API_KEY:string}).KMA_API_KEY;try{key=decodeURIComponent(key);}catch{}const url=new URL(definitions[kind].endpoint);for(const [k,v]of Object.entries({...params,serviceKey:key}))url.searchParams.set(k,v);const response=await fetch(url,{signal:AbortSignal.timeout(timeoutMs)});if(!response.ok)throw Error('인구 제공기관 연결 지연');let json:any;try{json=await response.json();}catch{throw Error('인구 제공기관 응답 확인 필요');}const objects=walk(json);const head=objects.find(o=>o.resultCode)??{};if(String(head.resultCode)==='3'&&String(head.resultMsg)==='NODATA_ERROR')return {rows:[] as RawRow[],total:0};return rowsAndCount(json);}
async function provinces(month:string){const saved=await readApiCache('population-provinces:v1') as string[]|undefined;if(saved?.length)return saved;
 // The population API supplies the administrative codes used by migration queries.
 const result=await providerPage('population',{type:'json',numOfRows:'100',pageNo:'1',lv:'1',admmCd:'0000000000',srchFrYm:month,srchToYm:month});const codes=[...new Set(result.rows.map(r=>String(r.admmCd??'')).filter(code=>/^\d{2}0{8}$/.test(code)))];
 if(codes.length<15)throw Error('전국 시도 코드 조회 확인 필요 · 일부 시도를 전체로 집계하지 않음');await writeApiCache('population-provinces:v1',codes,86400);return codes;}
async function migrationStep(c:Contract,batch:string,monthList:string[]){
 const codes=await provinces(monthList[0]);const tasks=codes.flatMap(code=>['in','out'].map(side=>({id:`${batch}:${side}:${code}`,side,code})));const states=await Promise.all(tasks.map(async task=>({task,state:await job(task.id) as PageJob|null})));const pending=states.filter(v=>!v.state?.done).sort((a,b)=>(a.state?.page??1)-(b.state?.page??1));const errors:string[]=[];
 await Promise.all(pending.slice(0,4).map(async({task,state})=>{try{const current:PageJob=state?await migratePageJob(task.id,state):{page:1,done:false,count:0,signatures:[],total:null};const params:Record<string,string>={type:'json',numOfRows:'100',pageNo:String(current.page),lv:'3',mvinAdmmCd:task.side==='in'?'4115000000':task.code,mvtAdmmCd:task.side==='out'?'4115000000':task.code,srchFrYm:monthList[2],srchToYm:monthList[0]};const result=await providerPage('migration',params);if(result.total!==null)current.total=result.total;
  if(result.rows.length){const signature=await signatureHash(JSON.stringify([result.rows[0],result.rows.at(-1)]));if(current.signatures.includes(signature))throw Error('페이지 중복 응답 확인 필요');current.signatures.push(signature);const items=compactFlows(result.rows,fieldMap(c,result.rows[0]));await saveJob(`${task.id}:page:${current.page}`,{items});current.count=(current.count??0)+items.length;current.page++;}
  current.done=current.total!==null?countJob(current)>=current.total:result.rows.length<100;if(!result.rows.length&&!current.done)throw Error('이동 페이지 일부 수집 지연');if(current.page>150)throw Error('이동 페이지 수집 범위 확인 필요');await saveJob(task.id,current);
 }catch{errors.push('인구이동 일부 페이지 수집 지연 · 수집 완료 전에는 합계를 확정하지 않음');}}));
 const finished=await Promise.all(tasks.map(async task=>await job(task.id) as PageJob|null));const done=finished.filter(j=>j?.done).length;return {done,total:tasks.length,rows:finished.reduce((n,j)=>n+(countJob(j)),0),totalRows:finished.reduce((n,j)=>n+(j?.total??0),0),errors:[...new Set(errors)],months:done===tasks.length?summarizeFlows((await Promise.all(finished.map(async(j,i)=>{if(j?.items)return j.items;const pages=await Promise.all(Array.from({length:Math.max(0,(j?.page??1)-1)},(_,page)=>job(`${tasks[i].id}:page:${page+1}`)));return pages.flatMap(page=>page?.items??[]);}))).flat()):null};
}
export async function collectPopulation(force=false){
 const started=Date.now();const lease=await db().prepare("INSERT INTO collection_state (id,next_due,lease_until,last_started,last_finished,last_error) VALUES ('population',0,?,?,NULL,NULL) ON CONFLICT(id) DO UPDATE SET lease_until=excluded.lease_until,last_started=excluded.last_started WHERE collection_state.lease_until<=? AND (collection_state.next_due<=? OR ?=1)").bind(started+45000,started,started,started,force?1:0).run();if(!lease.meta.changes)return {started:false};
 const previous=await readPopulation()??emptyPopulation();
 const data:PopulationData={...previous,pending:false,errors:[],collectedAt:new Date(started).toISOString()};
 let ongoing=false;
 try{
  const populationMonths=recentMonths(new Date(started),5);
  const missing=populationMonths.filter(month=>!data.population.some(row=>row.month===month&&row.complete));
  if(missing.length){
   const schema=await contract('population');
   for(const month of missing.slice(0,2)){
    const result=await providerPage('population',{type:'json',numOfRows:'100',pageNo:'1',lv:'3',admmCd:'4115000000',srchFrYm:month,srchToYm:month});
    if(!result.rows.length){data.errors.push('새 기준월의 인구 자료 공개 대기');continue;}
    if(result.total!==result.rows.length)throw Error('월별 인구 전체 자료 확인 필요');
    const parsed=normalizePopulation(result.rows,fieldMap(schema,result.rows[0]));
    if(parsed.length!==1||parsed[0].month!==month||!parsed[0].complete)throw Error('15개 동 전체 자료 확인 필요');
    data.population=[...data.population.filter(row=>row.month!==month),...parsed].sort((a,b)=>b.month.localeCompare(a.month));
    data.populationSavedAt=new Date().toISOString();
   }
   ongoing=missing.length>2;
  }
  // Each month has a stable job ID. Existing completed snapshots are reused.
  const month=recentMonths(new Date(started)).find(month=>!data.migration.some(row=>row.month===month&&row.complete));
  if(month){
   const schema=await contract('migration');
   const result=await migrationStep(schema,monthlyBatch(month),[month,month,month]);
   data.progress={done:result.done,total:result.total,phase:`${month} 전국 시도별 전입·전출 페이지 수집`,rows:result.rows,totalRows:result.totalRows};
   data.errors.push(...result.errors);
   if(result.months){
    data.migration=[...data.migration.filter(row=>!result.months!.some(next=>next.month===row.month)),...result.months].sort((a,b)=>b.month.localeCompare(a.month));
    data.migrationSavedAt=new Date().toISOString();data.progress=undefined;
    ongoing=ongoing||recentMonths(new Date(started)).some(month=>!data.migration.some(row=>row.month===month&&row.complete));
   }else ongoing=true;
  }else data.progress=undefined;
 }catch(e){data.errors.push(e instanceof Error&&!['AbortError','TimeoutError'].includes(e.name)?e.message:'제공기관 응답 지연 · 기존 성공 자료 유지');}
 finally{
  const finished=Date.now();
  const retryKey='population-retry-v2';
  const retry=await readApiCache(retryKey) as {attempt:number}|undefined;
  const attempt=data.errors.length?(retry?.attempt??0)+1:0;
  await writeApiCache(retryKey,{attempt},7*86400);
  const due=data.errors.length?finished+(data.errors.every(e=>e.includes('공개 대기'))?DAY:retryDelay(attempt-1)):ongoing?finished+1000:finished+DAY;
  data.pending=ongoing&&!data.errors.length;
  await db().batch([
   db().prepare("INSERT INTO population_snapshot (id,payload,saved_at) VALUES ('uijeongbu',?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,saved_at=excluded.saved_at").bind(JSON.stringify(data),finished),
   db().prepare("UPDATE collection_state SET lease_until=0,next_due=?,last_finished=?,last_error=? WHERE id='population' AND last_started=?").bind(due,finished,data.errors.join(' · ')||null,started)
  ]);
  // Prune only obsolete hourly jobs. Never delete unfinished monthly jobs or birth snapshots.
  await db().prepare("DELETE FROM population_jobs WHERE id GLOB 'population-??????-[0-9]*' AND saved_at<?").bind(finished-2*DAY).run();
 }
 return {started:true,pending:data.pending,populationMonths:data.population.map(m=>m.month),migrationMonths:data.migration.map(m=>m.month),progress:data.progress,errors:data.errors};
}
export async function loadPopulation(){const [saved,state]=await Promise.all([readPopulation(),db().prepare("SELECT lease_until,next_due FROM collection_state WHERE id='population'").first<{lease_until:number;next_due:number}>()]);const pending=Boolean(saved?.pending)||Boolean(state&&state.lease_until>Date.now());return {...(saved??emptyPopulation()),pending};}
type AreaJob={page:number;done:boolean;rows:RawRow[];summary:PopulationRow|null;savedAt:string|null;error:string|null;total:number|null;note?:string|null};
export async function collectPopulationAreas(id:string,month:string){if(!POP_REGIONS.some(r=>r.id===id&&id!=='city')||!/^20\d{4}$/.test(month))throw Error('지역과 통계 기준월 확인 필요');const key=`population-areas:${month}:${id}`,started=Date.now();const completed=await job(key) as AreaJob|null;if(completed?.done&&completed.summary)return {started:false};const state=await db().prepare('INSERT INTO collection_state (id,next_due,lease_until,last_started,last_finished,last_error) VALUES (?,0,?,?,NULL,NULL) ON CONFLICT(id) DO UPDATE SET lease_until=excluded.lease_until,last_started=excluded.last_started WHERE collection_state.lease_until<=? AND collection_state.next_due<=?').bind(key,started+85000,started,started,started).run();if(!state.meta.changes)return {started:false};
 const old=completed;const data:AreaJob=old&&!old.done?{...old,error:null}:{page:1,done:false,rows:[],summary:old?.summary??null,savedAt:old?.savedAt??null,error:null,total:null};
 const checkpoint={page:data.page,rows:[...data.rows],total:data.total};
 try{const c=await contract('population');const result=await providerPage('population',{type:'json',numOfRows:'100',pageNo:String(data.page),lv:'4',admmCd:id,srchFrYm:month,srchToYm:month},60000);if(!result.rows.length)throw Error('통·반 자료 확인 필요');data.total=result.total;data.rows.push(...result.rows);data.page++;const read=result.total!==null&&data.rows.length>=result.total;if(read){const fields=fieldMap(c,result.rows[0]);let parsed=normalizePopulation(data.rows,fields).find(m=>m.month===month)?.regions.find(r=>r.id===id);const stock=(await readPopulation())?.population.find(m=>m.month===month)?.regions.find(r=>r.id===id);if(parsed&&stock&&(parsed.population!==stock.population||parsed.households!==stock.households)){const areas=data.rows.map(row=>({tong:String(row[fields.tong]??'').trim(),ban:String(row[fields.ban]??'').trim(),population:numeric(row[fields.population])!,households:numeric(row[fields.households])!,male:numeric(row[fields.male])!,female:numeric(row[fields.female])!}));const sums=areas.reduce((a,r)=>({population:a.population+r.population,households:a.households+r.households,male:a.male+r.male,female:a.female+r.female}),{population:0,households:0,male:0,female:0});if(sums.population===stock.population&&sums.households===stock.households&&sums.male===stock.male&&sums.female===stock.female)parsed={...parsed,...sums,areas};}if(!parsed||!stock)throw Error('통·반 제공 범위 확인 필요');data.note=parsed.population===stock.population&&parsed.households===stock.households?null:`통·반 표의 제공 합계는 ${parsed.population.toLocaleString('ko-KR')}명·${parsed.households.toLocaleString('ko-KR')}세대입니다. 동 전체 ${stock.population.toLocaleString('ko-KR')}명·${stock.households.toLocaleString('ko-KR')}세대와의 차이는 ${stock.population-parsed.population}명·${stock.households-parsed.households}세대입니다. 상세 표의 제공 범위와 집계 차이를 확인해야 하며, 이 값으로 동 전체 수치를 대체하지 않습니다.`;data.summary=parsed;data.savedAt=new Date().toISOString();data.done=true;data.rows=[];}if(data.page>100)throw Error('통·반 수집 범위 확인 필요');}
 catch(e){data.error=e instanceof Error&&!['AbortError','TimeoutError'].includes(e.name)?e.message:'통·반 제공기관 응답 지연';data.page=checkpoint.page;data.rows=checkpoint.rows;data.total=checkpoint.total;}
 await saveJob(key,data);await db().prepare('UPDATE collection_state SET lease_until=0,next_due=?,last_finished=?,last_error=? WHERE id=? AND last_started=?').bind(data.error?Date.now()+15*60000:data.done?Date.now()+30*DAY:Date.now()+1000,Date.now(),data.error,key,started).run();return {started:true};
}
export async function loadPopulationAreas(id:string,month:string){if(!POP_REGIONS.some(r=>r.id===id&&id!=='city')||!/^20\d{4}$/.test(month))throw Error('지역과 통계 기준월 확인 필요');const key=`population-areas:${month}:${id}`;const [data,state]=await Promise.all([job(key) as Promise<AreaJob|null>,db().prepare('SELECT lease_until,next_due FROM collection_state WHERE id=?').bind(key).first<{lease_until:number;next_due:number}>()]);const pending=!data?.done&&(!state||state.lease_until>Date.now()||state.next_due<=Date.now()||Boolean(data&&!data.error));return {id,month,row:data?.summary??null,savedAt:data?.savedAt??null,pending,error:data?.error??null,note:data?.note??null};}
