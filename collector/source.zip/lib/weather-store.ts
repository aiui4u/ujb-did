import {env} from 'cloudflare:workers';
import {readApiCache,writeApiCache} from './api-cache';
import {retryDelay} from './refresh-policy';
import {REGIONS} from './regions';
import {collectWeather} from './weather-collector';
import {mergeSnapshot} from './snapshot-merge';
import type {WeatherData} from './weather';
type State={next_due:number;lease_until:number;last_started:number;last_finished:number|null;last_error:string|null};
function db(){if(!env.DB)throw new Error('자료 저장소 연결을 확인해 주세요.');return env.DB;}
export async function readSnapshot(id:string){const row=await db().prepare('SELECT payload FROM weather_snapshots WHERE region_id = ?').bind(id).first<{payload:string}>();return row?JSON.parse(row.payload) as WeatherData:null;}
export async function readAllSnapshots(){const result=await db().prepare('SELECT region_id,payload FROM weather_snapshots').all<{region_id:string;payload:string}>();return Object.fromEntries(result.results.map(row=>[row.region_id,JSON.parse(row.payload) as WeatherData]));}
export async function readCollectionState(){return db().prepare("SELECT next_due,lease_until,last_started,last_finished,last_error FROM collection_state WHERE id = 'weather'").first<State>();}
export function collectionInfo(state:State|null){const now=Date.now();return {pending:!state||state.lease_until>now||state.next_due<=now,lastStarted:state?.last_started?new Date(state.last_started).toISOString():null,lastFinished:state?.last_finished?new Date(state.last_finished).toISOString():null,message:state?.last_error??null};}
export async function collectAndSave(){
 const started=Date.now();const lease=started+90000;
 const result=await db().prepare("INSERT INTO collection_state (id,next_due,lease_until,last_started,last_finished,last_error) VALUES ('weather',0,?,?,NULL,NULL) ON CONFLICT(id) DO UPDATE SET lease_until=excluded.lease_until,last_started=excluded.last_started WHERE collection_state.lease_until<=? AND collection_state.next_due<=?").bind(lease,started,started,started).run();
 if(!result.meta.changes)return {started:false};
 const failures:string[]=[];
 try{const results=await Promise.allSettled(REGIONS.filter(r=>r.id==='city').map(async region=>{
  const previous=await readSnapshot(region.id);const incoming=await collectWeather(region);const data=mergeSnapshot(previous,incoming,new Date());
  if(!data)throw new Error('사용 가능한 수집 자료 없음');
  if(data.storage?.failedSources.length)failures.push(region.name);
  await db().prepare('INSERT INTO weather_snapshots (region_id,payload,saved_at) VALUES (?,?,?) ON CONFLICT(region_id) DO UPDATE SET payload=excluded.payload,saved_at=excluded.saved_at').bind(region.id,JSON.stringify(data),Date.parse(data.storage?.savedAt??data.fetchedAt)).run();
 }));results.forEach((result,i)=>{if(result.status==='rejected')failures.push('의정부시');});}
 finally{const now=Date.now();const previous=await readApiCache('weather-retry-v2') as {attempt:number}|undefined;const attempt=failures.length?(previous?.attempt??0)+1:0;await writeApiCache('weather-retry-v2',{attempt},86400);const nextDue=failures.length?now+retryDelay(attempt-1):(Math.floor(now/1800000)+1)*1800000;await db().prepare("UPDATE collection_state SET lease_until=0,next_due=?,last_finished=?,last_error=? WHERE id='weather' AND last_started=?").bind(nextDue,now,failures.length?'일부 자료 수집 지연 · 마지막 저장 자료 표시':null,started).run();}
 return {started:true,regions:1,failedRegions:[...new Set(failures)]};
}
