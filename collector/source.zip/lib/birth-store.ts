import {nextDaily} from './schedule';
import {env} from 'cloudflare:workers';
import {DAY} from './refresh-policy';
import {XMLParser} from 'fast-xml-parser';
import {runInBackground} from './collection-context';
import {recentMonths,monthOffset,normalizePopulation,POP_REGIONS,type RawRow} from './population';
import {fieldMap,rowsAndCount} from './population-store';
import {emptyBirths,type BirthData} from './births';
function db(){if(!env.DB)throw Error('출생등록 DB 연결 확인 필요');return env.DB;}
const SNAPSHOT='births:snapshot:v1';
async function read(){const r=await db().prepare('SELECT payload FROM population_jobs WHERE id=?').bind(SNAPSHOT).first<{payload:string}>();return r?JSON.parse(r.payload) as BirthData:emptyBirths();}
export async function collectBirths(force=false){
 const now=Date.now();const lease=await db().prepare("INSERT INTO collection_state(id,next_due,lease_until,last_started) VALUES('births',0,?,?) ON CONFLICT(id) DO UPDATE SET lease_until=excluded.lease_until,last_started=excluded.last_started WHERE collection_state.lease_until<=? AND (collection_state.next_due<=? OR ?=1)").bind(now+120000,now,now,now,force?1:0).run();if(!lease.meta.changes)return;
 const old=await read();const data={...old,pending:false,checkedAt:new Date(now).toISOString(),error:null as string|null};
 try{
 let key=(env as unknown as {BIRTH_API_KEY?:string}).BIRTH_API_KEY;if(!key)throw Error('출생등록 인증키 설정 확인 필요');try{key=decodeURIComponent(key);}catch{}
 const latest=recentMonths()[0],first=`${Number(latest.slice(0,4))-1}01`;
 const wanted:string[]=[];for(let m=latest;m>=first;m=monthOffset(m,-1))wanted.push(m);
 const missing=wanted.filter(m=>!old.months.some(x=>x.month===m));const targets=missing.slice(0,3);
 const groups=await Promise.all(targets.map(async month=>{
 const u=new URL('https://apis.data.go.kr/1741000/admmSexdBrthReg/selectAdmmSexdBrthReg');Object.entries({serviceKey:key!,type:'json',numOfRows:'100',pageNo:'1',lv:'3',admmCd:'4115000000',srchFrYm:month,srchToYm:month}).forEach(([k,v])=>u.searchParams.set(k,v));
 const r=await fetch(u,{signal:AbortSignal.timeout(20000)});if(!r.ok)throw Error(`출생등록 제공기관 응답 오류 (${r.status}) · 기존 자료 유지`);const text=await r.text();let json:unknown;try{json=JSON.parse(text);}catch{try{json=new XMLParser().parse(text);}catch{throw Error('출생등록 응답 형식 확인 필요');}}
 const result=rowsAndCount(json);if(!result.rows.length||result.total!==null&&result.total!==result.rows.length)throw Error('출생등록 월별 전체 자료 확인 필요');
 const rows=result.rows,example=rows[0];const map=fieldMap({params:[],fields:{}},example);
 for(const [target,pattern]of Object.entries({population:/^(tot|total).*(brth|birth|reg).*cnt$/i,male:/^male.*(brth|birth|reg).*cnt$/i,female:/^(feml|female).*(brth|birth|reg).*cnt$/i}))if(!map[target]){const k=Object.keys(example).find(k=>pattern.test(k));if(k)map[target]=k;}
 if(!map.population||!map.male||!map.female)throw Error(`출생등록 응답 항목 확인 필요: ${Object.keys(example).join(', ').slice(0,400)}`);
 const parsed=normalizePopulation(rows.map(r=>({...r,__households:0})),{...map,households:'__households'});
 if(parsed.length!==1||parsed[0].month!==month||parsed.some(m=>!m.complete||m.notes.some(n=>n.includes('차이'))))throw Error('출생등록 15개 동 합계 검증 필요 · 기존 자료 유지');return parsed;
 }));const parsed=groups.flat();
 const merged=new Map(old.months.map(m=>[m.month,m]));parsed.forEach(m=>merged.set(m.month,m));data.months=[...merged.values()].sort((a,b)=>b.month.localeCompare(a.month)).slice(0,36);if(parsed.length)data.savedAt=new Date().toISOString();data.pending=wanted.some(m=>!merged.has(m));
 }catch(e){data.error=e instanceof Error&&e.name!=='TimeoutError'?e.message:'출생등록 제공기관 연결 지연 · 기존 자료 유지';}
 await db().prepare('INSERT INTO population_jobs(id,payload,saved_at) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,saved_at=excluded.saved_at').bind(SNAPSHOT,JSON.stringify(data),Date.now()).run();
 await db().prepare("UPDATE collection_state SET lease_until=0,next_due=?,last_finished=?,last_error=? WHERE id='births' AND last_started=?").bind(data.error?Date.now()+15*60000:data.pending?Date.now()+1000:nextDaily(),Date.now(),data.error,now).run();
}
export async function loadBirths(){const [data,state]=await Promise.all([read(),db().prepare("SELECT lease_until,next_due FROM collection_state WHERE id='births'").first<{lease_until:number;next_due:number}>()]);const pending=Boolean(data.pending&&!data.error)||Boolean(state&&state.lease_until>Date.now());return {...data,pending};}
