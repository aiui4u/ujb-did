import {nextDaily} from './schedule';
export const HOUR = 3_600_000;
export const DAY = 24 * HOUR;
export const WARNING_INTERVAL = 30 * 60_000;
export const HOME_INTERVAL = 5 * 60_000;
export function nextBoundary(now: number, interval: number) {
  return (Math.floor(now / interval) + 1) * interval;
}
export function retryDelay(attempt: number) {
  return [5 * 60_000, 15 * 60_000, HOUR][Math.min(Math.max(0, attempt), 2)];
}
export function monthlyTtl(month: string, latest: string) {
  return month >= latest ? Math.max(60,(nextDaily()-Date.now()) / 1000) : 30 * DAY / 1000;
}
export function monthlyBatch(month: string) { return `population-month-v2:${month}`; }
