import { env } from 'cloudflare:workers';
import { mergeNewsArticles, fetchPressBoard, recentPressArticles, emptyNews, NEWS_FEED_URL, PRESS_FEED_URL, NEWS_REFRESH_MS, parseNewsFeed, recentArticles, type NewsFeedKind, type NewsFeedSnapshot, type NewsSnapshot } from './news';
const db = () => { if (!env.DB) throw Error('뉴스 저장소 연결 확인 필요'); return env.DB; };
const feedKey = (kind: NewsFeedKind) => kind === 'press' ? 'news:press:uijeongbu:v1' : 'news:google:uijeongbu:v1';
const stateKey = (kind: NewsFeedKind) => kind === 'press' ? 'press' : 'news';
type State = { next_due: number; lease_until: number; last_started: number | null; last_error: string | null };
async function readFeed(kind: NewsFeedKind): Promise<NewsFeedSnapshot> {
  const [row, state] = await Promise.all([
    db().prepare('SELECT payload FROM api_cache WHERE cache_key=?').bind(feedKey(kind)).first<{payload: string}>(),
    db().prepare('SELECT next_due,lease_until,last_started,last_error FROM collection_state WHERE id=?').bind(stateKey(kind)).first<State>()
  ]);
  const saved: NewsFeedSnapshot = row ? JSON.parse(row.payload) : emptyNews();
  return { ...saved, articles: kind === 'press' ? recentPressArticles(saved.articles) : recentArticles(saved.articles), lastAttemptAt: state?.last_started ? new Date(state.last_started).toISOString() : null, error: state?.last_error ?? null, pending: !!state && state.lease_until > Date.now() };
}
export async function readNews(): Promise<NewsSnapshot> {
  const [news, press] = await Promise.all([readFeed('news'), readFeed('press')]);
  return { ...news, press };
}
export async function collectFeed(kind: NewsFeedKind, rssXml?: string): Promise<NewsFeedSnapshot> {
  const started = Date.now(), id = stateKey(kind);
  const lease = await db().prepare('INSERT INTO collection_state(id,next_due,lease_until,last_started,last_finished,last_error) VALUES(?,0,?,?,NULL,NULL) ON CONFLICT(id) DO UPDATE SET lease_until=excluded.lease_until,last_started=excluded.last_started WHERE collection_state.lease_until<=? AND (collection_state.next_due<=? OR ?=1)').bind(id, started + 60000, started, started, started, rssXml ? 1 : 0).run();
  if (!lease.meta.changes) return readFeed(kind);
  let error: string | null = null;
  try {
    let xml = rssXml;
    if (kind === 'press') xml = '';
    if (xml === undefined) {
      const response = await fetch(kind === 'press' ? PRESS_FEED_URL : NEWS_FEED_URL, { headers: { Accept: 'application/rss+xml, application/xml, text/xml' }, signal: AbortSignal.timeout(12000) });
      if (!response.ok) throw Error('feed_http_' + response.status);
      xml = await response.text();
    }
    if (xml.length > 3000000) throw Error('feed_too_large');
    const articles = kind === 'press' ? await fetchPressBoard() : parseNewsFeed(xml, Date.now(), kind);
    const retained = kind === 'news' ? mergeNewsArticles(articles, (await readFeed(kind)).articles) : articles;
    const snapshot: NewsFeedSnapshot = { articles: retained, collectedAt: new Date().toISOString(), lastAttemptAt: new Date(started).toISOString(), error: null };
    await db().prepare('INSERT INTO api_cache(cache_key,payload,expires_at) VALUES(?,?,?) ON CONFLICT(cache_key) DO UPDATE SET payload=excluded.payload,expires_at=excluded.expires_at').bind(feedKey(kind), JSON.stringify(snapshot), Date.now() + 30 * 86400000).run();
  } catch (cause) {
    console.warn('News collection failed:', kind, cause instanceof Error ? cause.message : 'unknown_error');
    error = kind === 'press' ? '시청 보도자료 게시판 연결이 지연되고 있습니다. 마지막 정상 자료가 있으면 유지합니다.' : '언론 뉴스 수집이 지연되고 있습니다. 마지막 정상 목록을 유지합니다.';
  } finally {
    await db().prepare('UPDATE collection_state SET lease_until=0,next_due=?,last_finished=?,last_error=? WHERE id=? AND last_started=?').bind(Date.now() + NEWS_REFRESH_MS, Date.now(), error, id, started).run();
  }
  return readFeed(kind);
}
export async function loadNews(): Promise<NewsSnapshot> { return readNews(); }
