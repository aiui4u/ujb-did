import {env} from 'cloudflare:workers';
import {readApiCache,writeApiCache} from './api-cache';
import {parseComplaint,type ComplaintKind,type ComplaintResult} from './complaints';
export function koreaDates(){const now=new Date(Date.now()+9*3600000),to=now.toISOString().slice(0,10).replaceAll('-','');const from=new Date(Date.UTC(now.getUTCFullYear(),now.getUTCMonth()-4,1)).toISOString().slice(0,10).replaceAll('-','');return {from,to,hour:to+String(now.getUTCHours()).padStart(2,'0')};}
export function isComplaintWindow(now=Date.now()){const hour=new Date(now+9*3600000).getUTCHours();return hour>=20||hour<6;}
export async function savedComplaint(kind:ComplaintKind,keyword=''):Promise<ComplaintResult>{
 const key=`complaints:saved:v2:${kind}:${keyword}`;const [saved,attempt]=await Promise.all([readApiCache(key),readApiCache(key+':attempt')]) as [ComplaintResult|undefined,ComplaintResult|undefined];
 return saved?{...saved,lastAttemptAt:attempt?.checkedAt??undefined,collectionError:attempt?.error??null}:{rows:[],error:attempt?.error??'야간 수집 대기 · API 이용시간 20:00~06:00',checkedAt:attempt?.checkedAt??null,latestDate:null,empty:false};
}
export async function complaintData(kind:ComplaintKind,keyword='',collect=false):Promise<ComplaintResult>{
 if(!collect&&!keyword)return savedComplaint(kind,keyword);
 if(!isComplaintWindow())return savedComplaint(kind,keyword);
 const d=koreaDates(),cacheKey=`complaints:v1:${d.to}:${kind}:${keyword}`;const cached=await readApiCache(cacheKey) as ComplaintResult|undefined;if(cached&&(!collect||!cached.error))return savedComplaint(kind,keyword);
 const failure=(error:string):ComplaintResult=>({rows:[],error,checkedAt:new Date().toISOString(),latestDate:null,empty:false});
 if(!env.DB)return failure('저장 자료 연결 확인 중');
 // Durable leases and an endpoint-wide budget protect the 100-call development quota.
 const lease=await env.DB.prepare('INSERT INTO api_cache(cache_key,payload,expires_at) VALUES(?,?,?) ON CONFLICT(cache_key) DO UPDATE SET expires_at=excluded.expires_at WHERE api_cache.expires_at<?').bind(`complaints:lease:${kind}`,'{}',Date.now()+25000,Date.now()).run();if(!lease.meta.changes)return failure('자료 조회 중입니다. 잠시 후 다시 확인해 주세요.');
 const budget=await env.DB.prepare("INSERT INTO api_cache(cache_key,payload,expires_at) VALUES(?,'1',?) ON CONFLICT(cache_key) DO UPDATE SET payload=CAST(CAST(api_cache.payload AS INTEGER)+1 AS TEXT) WHERE CAST(api_cache.payload AS INTEGER)<20").bind(`complaints:budget:${d.to}:${kind}`,Date.now()+172800000).run();if(!budget.meta.changes)return failure('오늘의 조회 한도에 도달했습니다. 저장된 자료는 계속 표시됩니다.');
 const e=env as unknown as {COMPLAINT_API_KEY?:string;COMMERCE_API_KEY?:string};let key=e.COMPLAINT_API_KEY??e.COMMERCE_API_KEY;if(!key)return failure('민원 자료 인증 설정 확인 필요');try{key=decodeURIComponent(key);}catch{}
 const base:Record<string,string>={target:'pttn',dateFrom:d.from,dateTo:d.to,dataType:'json'};let path='',version=5,p={...base};
 switch(kind){
 case 'stats':path='minStaticsInfo5';Object.assign(p,{period:'MONTHLY',sortBy:'NAME',sortOrder:'true',brtcNameAKeyword:'경기도/의정부시'});break;
 case 'fields':case 'gender':case 'age':version=6;path=kind==='fields'?'minAddrClsfDocCnt':kind==='gender'?'minGndrClsfDocCnt':'minAgeClsfDocCnt';p={target:'pttn',dateFrom:d.from,dateTo:d.to};break;
 case 'df':path='minDFTopNKeyword5';p={target:'pttn',period:'MONTHLY',analysisTime:d.hour,rangeCount:'5',maxResult:'10',dataType:'json'};break;
 case 'tfidf':path='minTopNKeyword5';p.resultCount='10';break;
 case 'rising':path='minRisingKeyword5';p={target:'pttn',analysisTime:d.hour,maxResult:'10',brtcNameAKeyword:'경기도/의정부시',dataType:'json'};break;
 case 'topics':path='minTodayTopicInfo5';p={target:'pttn',searchDate:d.to,todayTopicTopN:'5',dataType:'json'};break;
 case 'reports':path='minAnalsRptstInfo5';p={dateFrom:d.from,dateTo:d.to,analsRptstKndCd:'B0020002',dataType:'json'};break;
 case 'related':path='minWdcloudInfo5';Object.assign(p,{searchword:keyword,resultCount:'10'});break;
 case 'trend':path='minTimeSeriseView5';Object.assign(p,{searchword:keyword,period:'MONTHLY',sortBy:'NAME',sortOrder:'true'});break;
 case 'similar':path='minSimilarInfo5';p={target:'qna',searchword:keyword,startPos:'0',retCount:'5',dataType:'json'};break;
 }
 const u=new URL(`https://apis.data.go.kr/1140100/minAnalsInfoView${version}/${path}`);u.searchParams.set('serviceKey',key);for(const[k,v]of Object.entries(p))u.searchParams.set(k,v);
 let result:ComplaintResult;try{const r=await fetch(u,{signal:AbortSignal.timeout(18000)});if(!r.ok){const text=await r.text();throw Error(text.includes('INVALID_REQUEST_PARAMETER')?'제공기관 요청 조건 확인 중 · 마지막 데이터 날짜 미확인':`제공기관 응답 지연 (${r.status})`);}result=parseComplaint(kind,await r.json());}catch(err){result=failure(err instanceof Error&&!/https?:/.test(err.message)?err.message:'민원 자료 연결 확인 중');}
 result.periodFrom=d.from;result.periodTo=d.to;
 const savedKey=`complaints:saved:v2:${kind}:${keyword}`;
 await writeApiCache(savedKey+':attempt',result,315360000);
 if(!result.error&&result.rows.length){result.savedAt=new Date().toISOString();await writeApiCache(savedKey,result,315360000);}
 else if(!result.error){result.error='해당 기간의 응답 자료가 없습니다. 마지막 저장 자료를 유지합니다.';await writeApiCache(savedKey+':attempt',result,315360000);}
 await writeApiCache(cacheKey,result,result.error?1800:43200);await env.DB.prepare('UPDATE api_cache SET expires_at=? WHERE cache_key=?').bind(Date.now(),`complaints:lease:${kind}`).run();return savedComplaint(kind,keyword);
}
