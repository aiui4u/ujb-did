import {env} from 'cloudflare:workers';
export async function readApiCache(key:string):Promise<unknown|undefined>{
 if(!env.DB)return undefined;
 try{const row=await env.DB.prepare('SELECT payload FROM api_cache WHERE cache_key = ? AND expires_at > ?').bind(key,Date.now()).first<{payload:string}>();return row?JSON.parse(row.payload):undefined;}catch{return undefined;}
}
export async function writeApiCache(key:string,value:unknown,ttl:number){
 if(!env.DB)return;
 try{await env.DB.prepare('INSERT INTO api_cache (cache_key,payload,expires_at) VALUES (?,?,?) ON CONFLICT(cache_key) DO UPDATE SET payload=excluded.payload,expires_at=excluded.expires_at').bind(key,JSON.stringify(value),Date.now()+ttl*1000).run();}catch{/* API collection remains available if caching is unavailable. */}
}
