export function runInBackground(task:Promise<unknown>){throw new Error("수집은 GitHub 작업에서만 실행합니다.");}
