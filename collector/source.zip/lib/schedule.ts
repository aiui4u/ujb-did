const HOUR=3600000,DAY=24*HOUR,KST=9*HOUR;
export function dailySlot(now=Date.now()) {const korea=now+KST;const day=Math.floor(korea/DAY)*DAY;const today=day+6*HOUR-KST;return now>=today?today:today-DAY;}
export function nextDaily(now=Date.now()){return dailySlot(now)+DAY;}
export function nextHour(now=Date.now()){return (Math.floor(now/HOUR)+1)*HOUR;}
