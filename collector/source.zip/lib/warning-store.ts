import {env} from 'cloudflare:workers';
import {WARNING_INTERVAL} from './refresh-policy';
import {runInBackground} from './collection-context';
import {emptyWarnings,parseWarningStatus,type WarningSnapshot} from './warnings';
function db(){if(!env.DB)throw new Error('특보 저장소 연결 확인 중');return env.DB;}
export async function readWarnings(){const row=await db().prepare("SELECT payload FROM warning_snapshot WHERE id='gyeonggi'").first<{payload:string}>();return row?JSON.parse(row.payload) as WarningSnapshot:null;}
export async function collectWarnings(){
 const started=Date.now();const r=await db().prepare("INSERT INTO collection_state (id,next_due,lease_until,last_started,last_finished,last_error) VALUES ('warnings',0,?,?,NULL,NULL) ON CONFLICT(id) DO UPDATE SET lease_until=excluded.lease_until,last_started=excluded.last_started WHERE collection_state.lease_until<=? AND collection_state.next_due<=? AND collection_state.last_started<=?").bind(started+60000,started,started,started,started-WARNING_INTERVAL).run();if(!r.meta.changes)return;
 let error:string|null=null;const previous=await readWarnings();let data:WarningSnapshot=emptyWarnings();
 try{const bindings=env as unknown as {KMA_API_KEY?:string};if(!bindings.KMA_API_KEY)throw new Error('기상청 인증키 설정 필요');let key=bindings.KMA_API_KEY;try{key=decodeURIComponent(key);}catch{}
  const url=new URL('https://apis.data.go.kr/1360000/WthrWrnInfoService/getPwnStatus');for(const [k,v] of Object.entries({serviceKey:key,numOfRows:'10',pageNo:'1',dataType:'JSON'}))url.searchParams.set(k,v);
  const response=await fetch(url,{signal:AbortSignal.timeout(8000)});if(!response.ok)throw new Error('기상특보 제공기관 응답 지연');const json=await response.json() as any;const head=json.response?.header;if(!['00','0'].includes(String(head?.resultCode)))throw new Error('기상특보 현황 자료 확인 중');const rows=json.response?.body?.items?.item;const items=Array.isArray(rows)?rows:rows?[rows]:[];items.sort((a:any,b:any)=>String(b.tmFc).localeCompare(String(a.tmFc)));if(!items.length)throw new Error('제공기관의 최근 특보 현황 자료 없음');data=parseWarningStatus(items[0],new Date());if(!data.verified)throw new Error(data.parseNotes.join(' · '));
  if(previous?.issuedAt&&data.issuedAt&&data.issuedAt<previous.issuedAt)data={...previous,collectedAt:new Date().toISOString(),error:null};
 }catch{error='기상특보 수집 지연 · 마지막 저장 현황 표시';data=previous?{...previous,error}:{...data,error};data.error=error;}
 await db().batch([
  db().prepare("INSERT INTO warning_snapshot (id,payload,saved_at) VALUES ('gyeonggi',?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,saved_at=excluded.saved_at").bind(JSON.stringify(data),data.collectedAt?Date.parse(data.collectedAt):0),
  db().prepare("UPDATE collection_state SET lease_until=0,next_due=?,last_finished=?,last_error=? WHERE id='warnings' AND last_started=?").bind(started+WARNING_INTERVAL,Date.now(),error,started)
 ]);
}
export async function loadWarnings(){const [data,state]=await Promise.all([readWarnings(),db().prepare("SELECT lease_until,next_due FROM collection_state WHERE id='warnings'").first<{lease_until:number;next_due:number}>()]);const pending=!state||state.lease_until>Date.now()||state.next_due<=Date.now();if(pending&&(!state||state.lease_until<=Date.now()))runInBackground(collectWarnings());return {...(data??emptyWarnings()),pending,nextCheckAt:state?.next_due??Date.now()};}
