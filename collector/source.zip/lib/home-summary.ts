import {env} from 'cloudflare:workers';
import {readPopulation} from './population-store';
import {readSnapshot} from './weather-store';
import {readApiCache,writeApiCache} from './api-cache';
import {claimRefresh,finishRefresh} from './shared-refresh';
import type {CommerceSnapshot} from './commerce';
export async function refreshHomeSummary(){
 const started=await claimRefresh('home-summary-v2',30000);if(!started)return;
 try{
  if(!env.DB)throw Error('자료 저장소 연결 확인 필요');
  const [pop,row,weather]=await Promise.all([readPopulation(),env.DB.prepare("SELECT payload FROM commerce_snapshot WHERE id='uijeongbu'").first<{payload:string}>(),readSnapshot('city')]);
  const commerce=row?JSON.parse(row.payload) as CommerceSnapshot:null;
  const summary={
   population:pop?{population:pop.population.map(m=>({...m,regions:m.regions.map(({areas,...r})=>r)})),collectedAt:pop.populationSavedAt,pending:pop.pending}:null,
   commerce:commerce?{count:commerce.count,regions:commerce.regions.map(r=>({id:r.id,name:r.name,count:r.count,industries:r.industries})),collectedAt:commerce.collectedAt}:null,
   weather:weather?{current:weather.current,hours:weather.hours,observedAt:weather.observedAt,air:weather.air,fetchedAt:weather.fetchedAt,grid:weather.grid}:null,
   summarySavedAt:new Date().toISOString()
  };
  await writeApiCache('home-summary:v2',summary,300);await writeApiCache('home-summary:v2:last-good',summary,366*86400);
  await finishRefresh('home-summary-v2',started,0);return summary;
 }catch(e){await finishRefresh('home-summary-v2',started,Date.now()+60000,'홈 요약 저장 지연');throw e;}
}
let building:Promise<unknown>|undefined;
export async function readHomeSummary(){
 const saved=await readApiCache('home-summary:v2');if(saved)return saved;
 // This fallback only reads D1. It never contacts a data provider.
 if(!building)building=(async()=>await refreshHomeSummary()??await readApiCache('home-summary:v2:last-good')??{population:null,commerce:null,weather:null})().finally(()=>{building=undefined;});
 return building;
}
