import { env } from 'cloudflare:workers';
import { advice, at, baseFor, kst, number, stamp, type Values, type WeatherData, type Hour, type Source } from '@/lib/weather';
import { stationForRegion, AIR_STATIONS, type Region } from '@/lib/regions';
import {normalizeForecasts,normalizeHigh,combinedAdvice,issuedTimestamp,metricValue,airTimestamp,type AirRow} from '@/lib/air';
import {readApiCache,writeApiCache} from '@/lib/api-cache';
const memo=new Map<string,{until:number;value:unknown}>();
const inflight=new Map<string,Promise<unknown>>();
function key(raw:string){try{return decodeURIComponent(raw);}catch{return raw;}}
async function getJSON(url:URL,cacheKey:string,ttl:number,allowEmpty=false){
 const cached=memo.get(cacheKey);if(cached&&cached.until>Date.now())return cached.value;
 if(inflight.has(cacheKey))return inflight.get(cacheKey);
 const work=(async()=>{
  const stored=await readApiCache(cacheKey);if(stored!==undefined)return stored;
  // Some hosted Workers disallow Cache API access; cache availability must not block data collection.
  let cache:Cache|undefined;
  try{cache=typeof caches!=='undefined'?(caches as unknown as {default:Cache}).default:undefined;}catch{cache=undefined;}
  const request=new Request('https://weather-cache.invalid/'+cacheKey);
  if(cache){try{const r=await cache.match(request);if(r)return await r.json();}catch{cache=undefined;}}
  let r:Response;
  try{r=await fetch(url,{signal:AbortSignal.timeout(6000)});}catch{throw new Error('기상자료 제공기관에 연결할 수 없습니다.');}
  if(!r.ok)throw new Error('자료 제공기관 응답 지연');
  const text=await r.text();let parsed:any;
  try{parsed=JSON.parse(text);}catch{const code=text.match(/<returnReasonCode>([^<]*)</)?.[1];throw new Error(code==='30'?'API 활용승인 또는 인증키를 확인해 주세요.':'제공기관이 자료를 반환하지 않았습니다. 잠시 후 다시 확인합니다.');}
  const header=parsed.response?.header;if(!header||!['00','0'].includes(String(header.resultCode)))throw new Error(['30','31','32'].includes(String(header?.resultCode))?'API 활용승인 또는 인증키를 확인해 주세요.':`제공기관 자료 준비 중 (${header?.resultCode??'응답 오류'})`);
  const rawItems=parsed.response?.body?.items?.item??parsed.response?.body?.items;
  const items=Array.isArray(rawItems)?rawItems:rawItems&&typeof rawItems==='object'?[rawItems]:[];
  if(!allowEmpty&&!items.length)throw new Error('해당 발표시각의 자료가 아직 없습니다.');
  await writeApiCache(cacheKey,items,ttl);
  memo.set(cacheKey,{until:Date.now()+ttl*1000,value:items});
  if(cache){try{await cache.put(request,new Response(JSON.stringify(items),{headers:{'Content-Type':'application/json','Cache-Control':`public, max-age=${ttl}`}}));}catch{/* In-memory cache remains available. */}}
  return items;
 })();inflight.set(cacheKey,work);try{return await work;}finally{inflight.delete(cacheKey);}
}
async function weather(kind:string,now:Date,raw:string,grid:Region){
 let message='자료 연결 확인 중';
 if(!raw)return {items:[],source:{ok:false,message:'기상청 인증키 설정이 필요합니다.',base:null} as Source};
 for(let back=0;back<2;back++){
  const base=baseFor(kind,now,back);
  const url=new URL('https://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/'+kind);
  for(const [k,v] of Object.entries({serviceKey:key(raw),pageNo:'1',numOfRows:kind==='getVilageFcst'?'1500':'1000',dataType:'JSON',base_date:base.date,base_time:base.time,nx:String(grid.nx),ny:String(grid.ny)}))url.searchParams.set(k,v);
  try{const items=await getJSON(url,`${kind}-${base.date}-${base.time}-${grid.nx}-${grid.ny}`,86400) as any[];return {items,source:{ok:true,message:'연결됨',base:at(base.date,base.time)} as Source};}catch(e){message=e instanceof Error?e.message:message;if(message.includes('인증키'))break;}
 }
 return {items:[],source:{ok:false,message,base:null} as Source};
}
export async function collectWeather(grid:Region):Promise<WeatherData>{
 const now=new Date();const bindings=env as unknown as {KMA_API_KEY?:string;AIRKOREA_API_KEY?:string;AIRKOREA_STATION?:string};
 const day=stamp(kst(now)),searchDate=`${day.slice(0,4)}-${day.slice(4,6)}-${day.slice(6,8)}`;
 const station=stationForRegion(grid);
 const airKey=bindings.AIRKOREA_API_KEY??'';
 const ttl=Math.max(60,Math.ceil((3600000-Date.now()%3600000)/1000));
 async function airCall(path:string,params:Record<string,string>,cacheKey:string){
  if(!airKey)return {items:[] as AirRow[],source:{ok:false,message:'대기질 인증키 설정 필요',base:null} as Source};
  try{const url=new URL('https://apis.data.go.kr/B552584/'+path);for(const [k,v]of Object.entries({serviceKey:key(airKey),returnType:'json',pageNo:'1',numOfRows:'100',...params}))url.searchParams.set(k,v);
   const items=await getJSON(url,cacheKey,path.includes('getMsrstnAcctoRltmMesureDnsty')?1200:ttl,true) as AirRow[];
   const base=items.map(x=>x.dataTime??'').sort((a,b)=>issuedTimestamp(b)-issuedTimestamp(a))[0]??null;
   return {items,source:{ok:true,message:items.length?'연결됨':'해당 날짜의 발표 자료 없음',base} as Source};
  }catch(e){return {items:[] as AirRow[],source:{ok:false,message:e instanceof Error?e.message:'대기질 연결 확인 중',base:null} as Source};}
 }
 const [current,ultra,forecast,airResult,airForecastResult,highResult]=await Promise.all([
  weather('getUltraSrtNcst',now,bindings.KMA_API_KEY??'',grid),weather('getUltraSrtFcst',now,bindings.KMA_API_KEY??'',grid),weather('getVilageFcst',now,bindings.KMA_API_KEY??'',grid),
  airCall('ArpltnInforInqireSvc/getMsrstnAcctoRltmMesureDnsty',{stationName:station,dataTerm:'DAILY',ver:'1.3',numOfRows:'24'},`air-current-${encodeURIComponent(station)}`),
  airCall('ArpltnInforInqireSvc/getMinuDustFrcstDspth',{searchDate},`air-forecast-${searchDate}`),
  airCall('MinuDustFrcstDspthSvc/getMinuDustFrcstDspth50Over',{searchDate,informCode:'PM25'},`air-high-${searchDate}`)
 ]);
 let activeStation=station;let activeAirResult=airResult;let fallbackReason='';
 const records=(rows:AirRow[],name:string):AirRow[]=>rows.slice().sort((a,b)=>String(b.dataTime).localeCompare(String(a.dataTime))).map(x=>({...x,stationName:name}));
 const usable=(rows:AirRow[])=>{const row=rows[0];const date=airTimestamp(row?.dataTime);return date!==null&&now.getTime()-date<3*3600000&&['pm10','pm25'].some(code=>metricValue(row,code)!==null);};
 if(!usable(records(airResult.items,station))&&airKey){
  const alternatives=(['의정부1동','의정부동','송산3동'] as const).filter(s=>s!==station);
  const candidates=await Promise.all(alternatives.map(async name=>({name,result:await airCall('ArpltnInforInqireSvc/getMsrstnAcctoRltmMesureDnsty',{stationName:name,dataTerm:'DAILY',ver:'1.3',numOfRows:'24'},`air-current-${encodeURIComponent(name)}`)})));
  const found=candidates.find(x=>usable(records(x.result.items,x.name)));
  if(found){activeStation=found.name;activeAirResult=found.result;fallbackReason=`${station} 측정자료 없음 → ${activeStation} 대체`;activeAirResult.source.message=`연결됨 · ${fallbackReason}`;}
 }
 const airHistory=records(activeAirResult.items,activeStation);
 if(!airHistory.length&&activeAirResult.source.ok){activeAirResult.source.ok=false;activeAirResult.source.message='측정소 자료 없음';}
 if(airHistory.length)activeAirResult.source.base=airHistory[0].dataTime;
 // A later issuance may omit this morning's daily minimum; use today's 02:00 issuance.
 const today=stamp(kst(now));let dailyItems=forecast.items;
 if(forecast.source.ok&&!forecast.items.some(x=>x.fcstDate===today&&x.category==='TMN')&&kst(now).getUTCHours()>=3){
  const dawn=await weather('getVilageFcst',new Date(at(today,'0230')),bindings.KMA_API_KEY??'',grid);
  if(dawn.source.ok)dailyItems=[...dawn.items.filter(x=>x.fcstDate===today&&['TMN','TMX'].includes(x.category)&&!forecast.items.some(v=>v.fcstDate===today&&v.category===x.category)),...forecast.items];
 }
 const values:Values={};for(const x of current.items)values[x.category]=String(x.obsrValue);
 const grouped=new Map<string,Hour>();
 for(const [items,source] of [[forecast.items,'단기예보'],[ultra.items,'초단기예보']] as [any[],string][]){for(const x of items){const time=at(x.fcstDate,x.fcstTime);const h=grouped.get(time)??{at:time,values:{},source};h.values[x.category]=String(x.fcstValue);h.source=source;grouped.set(time,h);}}
 const all=[...grouped.values()].sort((a,b)=>a.at.localeCompare(b.at));
 const daily:WeatherData['daily']=[];
 for(const date of [...new Set(dailyItems.map(x=>x.fcstDate))].sort()){
  const rows=dailyItems.filter(x=>x.fcstDate===date);const select=(c:string)=>rows.filter(x=>x.category===c).map(x=>number(x.fcstValue)).filter((v):v is number=>v!==null);
  const mins=select('TMN'),maxs=select('TMX'),pops=select('POP');daily.push({date,min:mins.length?Math.min(...mins):null,max:maxs.length?Math.max(...maxs):null,pop:pops.length?Math.max(...pops):null});
 }
 const data:WeatherData={fetchedAt:now.toISOString(),grid,current:values,observedAt:current.source.base,hours:all.filter(h=>Date.parse(h.at)>=now.getTime()-3600000),daily:daily.filter(d=>d.date>=stamp(kst(now))),sources:{current:current.source,ultra:ultra.source,forecast:forecast.source,air:activeAirResult.source,airForecast:airForecastResult.source,high:highResult.source},air:airHistory[0]??null,airHistory,airForecasts:normalizeForecasts(airForecastResult.items,searchDate),highForecasts:normalizeHigh(highResult.items,searchDate),airStation:{name:activeStation,...AIR_STATIONS[activeStation],requestedName:station,fallbackReason},notices:[]};
 data.notices=advice(data,now);data.notices=combinedAdvice(data,now);
 return data;
}
