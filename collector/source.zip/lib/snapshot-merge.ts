import {advice,type WeatherData,type Source} from './weather';
import {combinedAdvice,issuedTimestamp,metricValue} from './air';
const timestamp=(value:string)=>Number.isFinite(Date.parse(value))?Date.parse(value):issuedTimestamp(value);
const keys=['current','ultra','forecast','air','airForecast','high'] as const;
export function mergeSnapshot(previous:WeatherData|null,incoming:WeatherData,now:Date):WeatherData|null{
 if(incoming.sources.air.ok&&!['pm10','pm25','o3','no2','co','so2'].some(code=>metricValue(incoming.air,code)!==null))incoming.sources.air={...incoming.sources.air,ok:false,message:'측정자료 없음 · 마지막 저장 자료 보존'};
 if(!previous&&!keys.some(k=>incoming.sources[k]?.ok))return null;
 const data:WeatherData=previous?structuredClone(previous):structuredClone(incoming);
 const replace=(k:typeof keys[number])=>{const next=incoming.sources[k];const old=previous?.sources[k];return Boolean(next?.ok&&(!old?.base||!next.base||timestamp(next.base)>=timestamp(old.base)));};
 if(replace('current')){data.current=incoming.current;data.observedAt=incoming.observedAt;}
 if(replace('forecast'))data.daily=incoming.daily;
 if(previous){const hours=new Map(previous.hours.map(h=>[h.at,structuredClone(h)]));for(const h of incoming.hours){const old=hours.get(h.at)??{...h,values:{}};for(const [code,value] of Object.entries(h.values)){const source=['T1H','RN1','REH','PTY','WSD','VEC','UUU','VVV','SKY'].includes(code)&&incoming.sources.ultra.ok?'ultra':'forecast';if(replace(source))old.values[code]=value;}hours.set(h.at,old);}data.hours=[...hours.values()].filter(h=>Date.parse(h.at)>=now.getTime()-3600000).sort((a,b)=>a.at.localeCompare(b.at));}
 if(replace('air')&&incoming.air){data.air=incoming.air;data.airHistory=incoming.airHistory;data.airStation=incoming.airStation;}
 if(replace('airForecast')&&incoming.airForecasts?.length)data.airForecasts=incoming.airForecasts;
 if(replace('high')&&incoming.highForecasts?.length)data.highForecasts=incoming.highForecasts;
 for(const k of keys)if(replace(k))data.sources[k]=incoming.sources[k] as Source;
 data.fetchedAt=keys.some(replace)?incoming.fetchedAt:(previous?.fetchedAt??incoming.fetchedAt);
 data.storage={savedAt:keys.some(replace)?now.toISOString():(previous?.storage?.savedAt??data.fetchedAt),failedSources:keys.filter(k=>!incoming.sources[k]?.ok)};
 data.notices=advice(data,now);data.notices=combinedAdvice(data,now);return data;
}
