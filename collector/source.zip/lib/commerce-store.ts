import {dailySlot} from './schedule';
import {env} from 'cloudflare:workers';
import {readApiCache,writeApiCache} from './api-cache';
import {retryDelay} from './refresh-policy';
import {readPopulation} from './population-store';
import {emptyCommerce,normalizeStore,summarizeCommerce,type CommerceData,type CommerceSnapshot,type Store,type CommerceStatus} from './commerce';
type Job={runId:string;nextPage:number;total:number|null;rows:number;status:'pending'|'complete';startedAt:string;leaseUntil:number;error:string|null};
const DAY=86400000;
function db(){if(!env.DB)throw Error('상권 DB 연결 확인 필요');return env.DB;}
async function readJob(){const r=await db().prepare("SELECT payload FROM commerce_state WHERE id='uijeongbu'").first<{payload:string}>();return r?JSON.parse(r.payload) as Job:null;}
async function saveJob(j:Job){await db().prepare("INSERT INTO commerce_state(id,payload,saved_at) VALUES('uijeongbu',?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,saved_at=excluded.saved_at").bind(JSON.stringify(j),Date.now()).run();}
async function readSnapshot(){const r=await db().prepare("SELECT payload FROM commerce_snapshot WHERE id='uijeongbu'").first<{payload:string}>();return r?JSON.parse(r.payload) as CommerceSnapshot:null;}
function status(j:Job|null):CommerceStatus{return {pending:j?.status==='pending',page:j?j.nextPage-1:0,pages:j?.total!==null&&j?.total!==undefined?Math.ceil(j.total/1000):null,rows:j?.rows??0,total:j?.total??null,error:j?.error??null,startedAt:j?.startedAt??null};}
export async function loadCommerce():Promise<CommerceData>{let [snapshot,j,pop]=await Promise.all([readSnapshot(),readJob(),readPopulation().catch(()=>null)]);if(snapshot&&snapshot.analysisVersion!==3){const pages=await db().prepare('SELECT payload FROM commerce_pages WHERE run_id=? ORDER BY page').bind(snapshot.runId).all<{payload:string}>();const stores=pages.results.flatMap(p=>JSON.parse(p.payload) as Store[]);const revised=summarizeCommerce(stores,snapshot.runId,snapshot.collectedAt,snapshot.sourceTotal,snapshot);const result=await db().prepare("UPDATE commerce_snapshot SET payload=? WHERE id='uijeongbu' AND json_extract(payload,'$.runId')=?").bind(JSON.stringify(revised),snapshot.runId).run();snapshot=result.meta.changes?revised:await readSnapshot();}return {snapshot,status:status(j),population:pop?.population.find(m=>m.complete)??null};}
export async function loadCommerceStores(dong='city'){const snapshot=await readSnapshot();if(!snapshot)return {runId:null,stores:[] as Store[]};const pages=await db().prepare('SELECT payload FROM commerce_pages WHERE run_id=? ORDER BY page').bind(snapshot.runId).all<{payload:string}>();const stores=pages.results.flatMap(p=>JSON.parse(p.payload) as Store[]).filter(s=>dong==='city'||s.dong===dong);return {runId:snapshot.runId,stores};}
async function provider(page:number){const key=(env as unknown as {COMMERCE_API_KEY?:string}).COMMERCE_API_KEY;if(!key)throw Error('상권 API 인증 설정 확인 필요');const u=new URL('https://apis.data.go.kr/B553077/api/open/sdsc2/storeListInDong');let decoded=key;try{decoded=decodeURIComponent(key);}catch{}for(const [k,v]of Object.entries({serviceKey:decoded,divId:'signguCd',key:'41150',numOfRows:'1000',pageNo:String(page),type:'json'}))u.searchParams.set(k,v);
 const r=await fetch(u,{signal:AbortSignal.timeout(18000)});if(!r.ok)throw Error('상권 제공기관 응답 지연');let json:any;try{json=await r.json();}catch{throw Error('상권 제공기관 응답 형식 확인 필요');}const root=json.response??json;const code=String(root.header?.resultCode??root.header?.resultcode??'');if(!['00','0',''].includes(code))throw Error(`상권 제공기관 응답 코드 ${code.replace(/[^A-Za-z0-9_-]/g,'').slice(0,20)}`);const body=root.body;if(!body)throw Error('상권 응답 본문 확인 필요');const total=Number(body.totalCount);if(!Number.isInteger(total)||total<0)throw Error('전체 업소 수 확인 필요');const rows=Array.isArray(body.items)?body.items:body.items?.item?Array.isArray(body.items.item)?body.items.item:[body.items.item]:[];return {total,stores:rows.map(normalizeStore) as Store[]};
}
export async function collectCommerce(force=false){
 const now=Date.now(),previous=await readSnapshot();let j=await readJob();
 if(j?.leaseUntil&&j.leaseUntil>now)return status(j);
 const retry=await readApiCache('commerce-retry-v2') as {attempt:number;due:number}|undefined;if(retry&&retry.due>now)return status(j);
 if(force&&j?.error)j=null;
 if(j?.status!=='pending'){
  if(!force&&previous&&Date.parse(previous.collectedAt)>=dailySlot(now))return status(j);
  j={runId:crypto.randomUUID(),nextPage:1,total:null,rows:0,status:'pending',startedAt:new Date(now).toISOString(),leaseUntil:0,error:null};
  // Claim new work with one conditional write, preserving another collector's lease.
  const result=await db().prepare("INSERT INTO commerce_state(id,payload,saved_at) VALUES('uijeongbu',?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,saved_at=excluded.saved_at WHERE CAST(json_extract(commerce_state.payload,'$.leaseUntil') AS INTEGER)<=?").bind(JSON.stringify({...j,leaseUntil:now+50000}),now,now).run();if(!result.meta.changes)return status(await readJob());
 }else{
  const result=await db().prepare("UPDATE commerce_state SET payload=?,saved_at=? WHERE id='uijeongbu' AND CAST(json_extract(payload,'$.leaseUntil') AS INTEGER)<=?").bind(JSON.stringify({...j,leaseUntil:now+50000}),now,now).run();if(!result.meta.changes)return status(await readJob());
 }
 j.leaseUntil=now+50000;j.error=null;
 try{
  for(let n=0;n<2;n++){
   const page=await provider(j.nextPage);if(j.total!==null&&j.total!==page.total)throw Error('수집 중 제공기관 전체 건수 변경 · 재수집 확인 필요');j.total=page.total;
   const expected=Math.min(1000,Math.max(0,page.total-(j.nextPage-1)*1000));if(page.stores.length!==expected)throw Error('페이지 수집 건수 확인 필요');
   await db().prepare('INSERT INTO commerce_pages(id,run_id,page,payload) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload').bind(`${j.runId}:${j.nextPage}`,j.runId,j.nextPage,JSON.stringify(page.stores)).run();j.rows+=page.stores.length;j.nextPage++;
   if(j.rows===j.total){
    const pages=await db().prepare('SELECT payload FROM commerce_pages WHERE run_id=? ORDER BY page').bind(j.runId).all<{payload:string}>();const all=pages.results.flatMap(p=>JSON.parse(p.payload) as Store[]);const snapshot=summarizeCommerce(all,j.runId,new Date().toISOString(),j.total,previous);
    await db().prepare("INSERT INTO commerce_snapshot(id,payload,saved_at) VALUES('uijeongbu',?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,saved_at=excluded.saved_at").bind(JSON.stringify(snapshot),Date.now()).run();j.status='complete';await db().prepare('DELETE FROM commerce_pages WHERE run_id NOT IN (?,?)').bind(j.runId,previous?.runId??j.runId).run();break;
   }
  }
 }catch(e){j.error=e instanceof Error?e.message:'상권 자료 수집 지연';}
 if(j.error){const attempt=retry?.attempt??0;await writeApiCache('commerce-retry-v2',{attempt:attempt+1,due:Date.now()+retryDelay(attempt)},86400);}else await writeApiCache('commerce-retry-v2',{attempt:0,due:0},86400);
 j.leaseUntil=0;await saveJob(j);return status(j);
}
