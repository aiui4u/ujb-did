import {env} from 'cloudflare:workers';
import {readApiCache,writeApiCache} from './api-cache';
import {retryDelay} from './refresh-policy';
// D1 leases serialize collectors across all browsers and Worker instances.
export async function claimRefresh(id:string,leaseMs=120000){
 if(!env.DB)throw Error('자료 저장소 연결 확인 필요');
 const now=Date.now();
 const result=await env.DB.prepare('INSERT INTO collection_state(id,next_due,lease_until,last_started) VALUES(?,0,?,?) ON CONFLICT(id) DO UPDATE SET lease_until=excluded.lease_until,last_started=excluded.last_started WHERE collection_state.lease_until<=? AND collection_state.next_due<=?').bind(id,now+leaseMs,now,now,now).run();
 return result.meta.changes?now:null;
}
export async function finishRefresh(id:string,started:number,due:number,error:string|null=null){
 if(!env.DB)throw Error('자료 저장소 연결 확인 필요');
 await env.DB.prepare('UPDATE collection_state SET lease_until=0,next_due=?,last_finished=?,last_error=? WHERE id=? AND last_started=?').bind(due,Date.now(),error,id,started).run();
}
export async function monthlyCached<T extends {error?:string;stale?:boolean}>(key:string,ttl:number,load:()=>Promise<T>,empty:T):Promise<T>{
 const cached=await readApiCache(key) as T|undefined;if(cached)return cached;
 const started=await claimRefresh(`cache:${key}`,450000);
 const good=await readApiCache(`${key}:last-good`) as T|undefined;
 if(!started)return good?{...good,stale:true}:{...empty,error:'자료 수집 중 또는 재시도 대기 · 저장자료 유지'};
 try{
  const value=await load();if(value.error)throw Error(value.error);
  await writeApiCache(key,value,ttl);await writeApiCache(`${key}:last-good`,value,366*86400);
  await writeApiCache(`${key}:retry`,{attempt:0},7*86400);
  await finishRefresh(`cache:${key}`,started,Date.now()+ttl*1000);return value;
 }catch(e){
  const previous=await readApiCache(`${key}:retry`) as {attempt:number}|undefined;
  const attempt=previous?.attempt??0,delay=retryDelay(attempt);
  const error=e instanceof Error?e.message:'자료 제공기관 연결 지연';
  const value={...(good??empty),error,stale:!!good};
  await writeApiCache(`${key}:retry`,{attempt:attempt+1},7*86400);
  await writeApiCache(key,value,delay/1000);await finishRefresh(`cache:${key}`,started,Date.now()+delay,error);return value;
 }
}
