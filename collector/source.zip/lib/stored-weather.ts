import {loadWarnings} from './warning-store';
import {readSnapshot,readAllSnapshots,readCollectionState,collectionInfo,collectAndSave} from './weather-store';
import {runInBackground} from './collection-context';
import type {WeatherData} from './weather';
import {analyzeLife} from './life-analysis';
export function prepareStoredWeather(data:WeatherData,collection:WeatherData['collection'],now:Date){
 // Apply the display name to previously saved snapshots as well as new collects.
 if(data.grid.name==='의정부시청')data.grid={...data.grid,name:'의정부시'};
 data.collection=collection;return analyzeLife(data,now);
}
export async function loadStoredWeather(id:string){
 const [data,state,warnings]=await Promise.all([readSnapshot(id),readCollectionState(),loadWarnings()]);const collection=collectionInfo(state);
 if(collection.pending&&(!state||state.lease_until<=Date.now()))runInBackground(collectAndSave());
 if(data)data.warnings=warnings;
 return {data:data?prepareStoredWeather(data,collection,new Date()):null,collection};
}

export async function loadStoredSnapshots(){
 const [snapshots,state,warnings]=await Promise.all([readAllSnapshots(),readCollectionState(),loadWarnings()]);const collection=collectionInfo(state);const now=new Date();
 if(collection.pending&&(!state||state.lease_until<=now.getTime()))runInBackground(collectAndSave());
 for(const value of Object.values(snapshots)){value.warnings=warnings;prepareStoredWeather(value,collection,now);}
 return snapshots;
}
