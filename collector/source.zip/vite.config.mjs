import {defineConfig} from 'vite';
import path from 'node:path';
export default defineConfig({resolve:{alias:{'@':path.resolve('.'),'cloudflare:workers':path.resolve('runtime.ts')}},ssr:{noExternal:true},build:{ssr:'collect.ts',target:'node24',outDir:'..',emptyOutDir:false,minify:false,rollupOptions:{output:{entryFileNames:'collect.mjs'}}}});
